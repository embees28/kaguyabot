const cheerio = require('cheerio');
const axios = require('axios');
const request = require('request');
const fs = require('fs');
const qs = require('qs')
const yt = require('ytdl-core');
const yts = require('yt-search');
const WebSocket = require('ws');
const { JSDOM } = require('jsdom');
const formData = require('form-data')
const fetch = require('node-fetch');

const JOOX_BASE_URL = 'https://api.joox.com';
const JOOX_API_KEY = '2a5d97d05dc8fe238150184eaf3519ad';

async function joox(query) {
    try {
        const time = Math.floor(new Date() / 1000);
        const response = await axios.get(`${JOOX_BASE_URL}/web-fcgi-bin/web_search?lang=id&country=id&type=0&search_input=${query}&pn=1&sin=0&ein=29&_= ${time}`);
        const data = response.data;

        const ids = data.itemlist.map(result => result.songid);
        const promises = ids.map(async (id) => {
            const songInfo = await fetchJooxSongInfo(id);
            return {
                song: songInfo.msong,
                album: songInfo.malbum,
                artist: songInfo.msinger,
                publish: songInfo.public_time,
                image: songInfo.imgSrc,
                mp3: songInfo.mp3Url
            };
        });

        const results = await Promise.all(promises);
        return {
            creator: "DannTeam",
            status: true,
            data: results,
        };
    } catch (error) {
        throw error;
    }
}

async function fetchJooxSongInfo(id) {
    try {
        const response = await axios.get(`${JOOX_BASE_URL}/web-fcgi-bin/web_get_songinfo?songid=${id}`, {
            headers: {
                Cookie: `wmid=142420656; user_type=1; country=id; session_key=${JOOX_API_KEY}`
            }
        });
        return JSON.parse(response.data.replace('MusicInfoCallback(', '').replace('\n)', ''));
    } catch (error) {
        throw error;
    }
}

async function jooxdl(url) {
    try {
        const songId = url.replace('https://www.joox.com/id/single/', '');
        const songInfo = await fetchJooxSongInfo(songId);
        const result = {
            song: songInfo.msong,
            album: songInfo.malbum,
            artist: songInfo.msinger,
            publish: songInfo.public_time,
            image: songInfo.imgSrc,
            mp3: songInfo.mp3Url
        };
        return result;
    } catch (error) {
        throw error;
    }
}

async function rexdl(query) {
    try {
        const response = await axios.get(`https://rexdl.com/?s=${query}`);
        const $ = cheerio.load(response.data);

        const results = [];
        $('div > div.post-content').each(function (index, element) {
            const judul = $(element).find('h2.post-title > a').attr('title');
            const jenis = $(element).find('p.post-category').text();
            const date = $(element).find('p.post-date').text();
            const desc = $(element).find('div.entry.excerpt').text();
            const link = $(element).find('h2.post-title > a').attr('href');
            results.push({
                creator: 'DannTeam',
                judul,
                kategori: jenis,
                upload_date: date,
                deskripsi: desc,
                link,
            });
        });

        return results;
    } catch (error) {
        throw error;
    }
}

async function nomorhoki(nomor) {
    try {
        const response = await axios.post('https://www.primbon.com/no_hoki_bagua_shuzi.php', new URLSearchParams({
            nomer: nomor,
            submit: 'Submit!'
        }));

        const fetchText = cheerio.load(response.data)('#body').text().trim();
        let result;

        if (fetchText.includes('No. HP :')) {
            result = {
                nomor_hp: fetchText.split('No. HP : ')[1].split('\n')[0],
                angka_bagua_shuzi: fetchText.split('Angka Bagua Shuzi : ')[1].split('\n')[0],
                energi_positif: {
                        kekayaan: fetchText.split('Kekayaan = ')[1].split('\n')[0],
                        kesehatan: fetchText.split('Kesehatan = ')[1].split('\n')[0],
                        cinta: fetchText.split('Cinta/Relasi = ')[1].split('\n')[0],
                        kestabilan: fetchText.split('Kestabilan = ')[1].split('\n')[0],
                        persentase: fetchText.split('Kestabilan = ')[1].split('% = ')[1].split('ENERGI NEGATIF')[0]
                    },
                    energi_negatif: {
                        perselisihan: fetchText.split('Perselisihan = ')[1].split('\n')[0],
                        kehilangan: fetchText.split('Kehilangan = ')[1].split('\n')[0],
                        malapetaka: fetchText.split('Malapetaka = ')[1].split('\n')[0],
                        kehancuran: fetchText.split('Kehancuran = ')[1].split('\n')[0],
                        persentase: fetchText.split('Kehancuran = ')[1].split('% = ')[1].split("\n")[0]
                    },
                    notes: fetchText.split('* ')[1].split('Masukan Nomor HP Anda')[0]
            };
        } else {
            result = `Nomor "${nomor}" tidak valid`;
        }

        return result;
    } catch (error) {
        throw error;
    }
}

async function blackbox(text) {
    try {
        const response = await axios.post('https://www.useblackbox.io/chat-request-v4', {
            text: text,
            allMessages: [{ user: text }],
            stream: '',
            clickedContinue: false
        }, {
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux x86_64) Gecko/20130401 Firefox/71.3',
            }
        });

        return response.data;
    } catch (error) {
        throw error;
    }
}

async function tiktokslide(url) {
    try {
        const response = await axios.post("https://ezsave.app/api/tiktok/slide-downloader", { url });
        return response.data;
    } catch (error) {
        throw error;
    }
}

async function capcut(url) {
    try {
        const response = await axios.post("https://api.teknogram.id/v1/capcut", { url });
        return response.data;
    } catch (error) {
        throw error;
    }
}

// Rifza
async function photo2anime(url) {
  return new Promise(async(resolve, reject) => {
    let { data } = await axios({
      url: "https://tools.revesery.com/image-anime/convert.php",
      method: "POST",
      data: new URLSearchParams(Object.entries({
        "image-url": url
      })),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    })
    console.log(data)
    resolve(data)
  })
}

async function tiktoks(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/feed/search',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: {
          keywords: query,
          count: 10,
          cursor: 0,
          HD: 1
        }
      });
      const videos = response.data.data.videos;
      if (videos.length === 0) {
        reject("Tidak ada video ditemukan.");
      } else {
        const gywee = Math.floor(Math.random() * videos.length);
        const videorndm = videos[gywee]; 

        const result = {
          title: videorndm.title,
          cover: videorndm.cover,
          origin_cover: videorndm.origin_cover,
          no_watermark: videorndm.play,
          watermark: videorndm.wmplay,
          music: videorndm.music
        };
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
}

const models = {
  'gpt-3.5-turbo': { id: 'gpt-3.5-turbo', name: 'GPT-3.5' },
  'gpt-3.5-turbo-0613': { id: 'gpt-3.5-turbo-0613', name: 'GPT-3.5-0613' },
  'gpt-3.5-turbo-16k': { id: 'gpt-3.5-turbo-16k', name: 'GPT-3.5-16K' },
  'gpt-3.5-turbo-16k-0613': { id: 'gpt-3.5-turbo-16k-0613', name: 'GPT-3.5-16K-0613' },
  'gpt-4': { id: 'gpt-4', name: 'GPT-4' },
  'gpt-4-0613': { id: 'gpt-4-0613', name: 'GPT-4-0613' },
  'gpt-4-32k': { id: 'gpt-4-32k', name: 'GPT-4-32K' },
  'gpt-4-32k-0613': { id: 'gpt-4-32k-0613', name: 'GPT-4-32K-0613' },
};

async function aivvm(query) {
  return new Promise(async (resolve, reject) => {
   axios("https://chat.aivvm.com/api/chat", {
  headers: {
    "content-type": "application/json",
    "cookie": "cf_clearance=ZNVwKFf6WIgJFLiqbABeL5cecB7JXKVNf96thFIfbpc-1697475122-0-1-d7837a.abde80aa.82e2b913-0.2.1697475122",
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
  },
  data: {
  "model": {
    "id": "gpt-4",
    "name": "GPT-4"
  },
  "messages": [
    {
      "role": "user",
      "content": query 
    }
  ],
  "key": "",
  "prompt": "Anda adalah ChatGPT, model bahasa besar yang dilatih oleh Danz. Ikuti instruksi pengguna dengan hati-hati. Balas menggunakan markdown.",
  "temperature": 1
},
  "method": "POST"
}).then(danz => {
     resolve(danz.data);
      });
    });
};

async function cai(query, character) {
  try {
    const response = await axios.post('https://boredhumans.com/api_celeb_chat.php', `message=${query}&intro=${character}&name=${character}`, {
      headers: {
        'User-Agent': 'Googlebot-News',
      }
    });
    return response.data;
  } catch (error) {
    throw error;
  }
}

async function aiodl(url) {
  try {
    const response = await axios.post("https://aiovd.com/wp-json/aio-dl/video-data", {
      url: url
    }, 
    {
      headers: {
        'Accept': '*/*',
        'Content-Type': 'application/json'
      }
    });

    const res = response.data;
    const result = {
      data: res.medias
    };
    
    return result;
  } catch (e) {
    console.log(e);
  }
}

async function bard(text) {
	return new Promise(async(resolve,reject) => {
axios("https://bard.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?bl=boq_assistant-bard-web-server_20231017.06_p1&f.sid=5081654630287087960&hl=id&_reqid=1903560&rt=c", {
  "headers": {
    "content-type": "application/x-www-form-urlencoded;charset=UTF-8",
    "sec-ch-ua-mobile": "?1",
    "sec-ch-ua-wow64": "?0",
    "sec-fetch-site": "same-origin",
    "x-client-data": "COqOywE=",
    "x-same-domain": "1",
    "cookie": "_ga=GA1.1.1488021965.1692178722; __Secure-ENID=15.SE=lhYzIFHRgJIraVWogGeJUOL8Iclkn8ywWKZvQO0zUXk9ZiCWVOQjjbftu-yjTnuBTXuLvL_weR2yMwP8CzDT9bRfi0qAbzxzMC2uKeBFeklPCYNfSPowgofAZn8ghyLKTk1rZpasEYyODDeoZHWdvM8y2kGdcILXRL_VzQYUnHg; SID=bwizRxqfAYDEke2rMYKm-2RR4CHg42Llb3EArGZVl8K_mPPgVSFF_hyT5kqNXnNfa_3mTg.; __Secure-1PSID=bwizRxqfAYDEke2rMYKm-2RR4CHg42Llb3EArGZVl8K_mPPgEw0GRLFJSJM7-yuaBFsWUw.; __Secure-3PSID=bwizRxqfAYDEke2rMYKm-2RR4CHg42Llb3EArGZVl8K_mPPgaaFQP6MIO2lK9irjwX1y0w.; HSID=AfR18lr2iDdUAbf3O; SSID=A2Gh8NYMQWbAY36ac; APISID=KHhaybLppVp6qHyo/ArQ9ZCS02zfCFhEt6; SAPISID=bI8uS3ZAPQ4AZaFl/APhM7JMVnz1g3Zvn3; __Secure-1PAPISID=bI8uS3ZAPQ4AZaFl/APhM7JMVnz1g3Zvn3; __Secure-3PAPISID=bI8uS3ZAPQ4AZaFl/APhM7JMVnz1g3Zvn3; NID=511=Q6ZIBQsHOHePe4k1eztC4gIXf7PTNhJla7ADiUvAt8pO3Xg5JGTs7SfEO1ah1gKcKRKsFzHraxCeGkfPsrDYbZpLN2FShgJo3Pc7c-NutmVzEGxvRtw7sU7LFZS12GMPt0iOyO3apWnlE1BjJzZCiScYZyjlb-RLnZhbi0Y2PyZxPtbAw2-WM7ItsqvhZQIDltCEYwE98tpXQAbNwPghVlNf-2Pf5uRDera6iM656YcmYy9qQK_4EPdypx6EeURUNEgQsX-lCiT3ticZVdtUXjzcRlL73N8y-8pfrXzgwWzP0CH94ffqyalpr5oIUAaBs1XGHwBTb90VirZ16IUeVXM; SIDCC=ACA-OxNi7OEajB_EzdTwz77a53C7hGHUAFOWy5OwGtiaDgEZk4R2gFgO1i06BKUFR1ne3EqdDzQ; __Secure-1PSIDCC=ACA-OxP_TAKQX_gHP8nVPBZPK189Q8xhYLd9L72lypNMODVYSCUynQF7v__QRYJexT4oVylpR2s; __Secure-3PSIDCC=ACA-OxO6cyVOzn923mHVhv6pp0YWczR5rmVoPMVGPYvVlMq95Wc4PRcPb_8KWW7EukoZ5SJAYiQ; _ga_WC57KJ50ZZ=GS1.1.1697824766.8.1.1697824780.0.0.0",
    "Referer": "https://bard.google.com/",
    "Referrer-Policy": "origin"
  },
  "data": "f.req=%5Bnull%2C%22%5B%5B%5C%22" + text + "%20%5C%22%2C0%2Cnull%2C%5B%5D%2Cnull%2Cnull%2C0%5D%2C%5B%5C%22id%5C%22%5D%2C%5B%5C%22%5C%22%2C%5C%22%5C%22%2C%5C%22%5C%22%2Cnull%2Cnull%2C%5B%5D%5D%2C%5C%22!iomlidHNAAYRMHX6MTBCkitMy_7Q7v87ADQBEArZ1J3q8vHpcD_fLB2oT4rGtTpMHUYcxZC-eugirr_r5LX2vuJ1zaHPVLxML57wUzUaAgAAAhdSAAACQmgBB5kDMZ0iYOGFH1GZ847Atl4Ns5k4IpB52BmB4Uj0OmUyb1iqUzKdmUAr-hBn5BAUp4OaszBTCQ44AreO3EDMruHFTy3gEdjznQZcfMNkc1re0MUYmF2RX8zTLTi2QBtWd8KFMqJRtrBMce3t8lhaTnbzTMimfiAN9subFKfwZeW203-Kx2-zlEU43KtkAypaXnxzoqTH9QhvbcgoIvXADxGiZdsa0pab-Ym0BlSVfVG7etG2xjJYb4KmdSbjEuzZxt9OK-0KcZbn4WduHSjmx9YjOltLxbOL-tJK8lUuZM0GFeSNduujlzNbgRGru_Venzk6utV8G4SMsZq_sEVPMwLn8b4zULe7kT2yFaoVrcpwbE982hH3CDNpSTDV4fIWptpZuHe_x-eqj8QnyrUZ5kRNt8OeHzdjQIrMS83nKkMqQS3mDrXnwmQWJGPamP4oCjfkjp911FIA5awOCmJ7em4kGNOfJB_kiLHiIjjjmmTb4dBO1jjQrh2Wtp9SWks7QSQyI66bq6L_6nZQBM6NVX5wiqiq52TCorEXkarJIU8-gpI-NkYPhez2tksYcRbLMif3sNR7BZrBVlm1bfMuqp-cRRGInEzt3iYXzd1_NrVYvYNxEtVio5U5sGqB_FGnn2f8vHjJmcbtVNkW3JhRi4h7qfPH_qgDN96VYNQAEd_ZkzweSMxk_Mm32H2sev0gD-C4BuUvNE0ppSJVNCbUrVdxiThgqEn19I3rR66knln2ra1jdkSlkztEwv5PJU5o2dajKGY6h_KdZ_jKN3pDx20NIrGk8itnJGcAz7tIwM3JfnbFuKOvJE6_OrHqTW17PCjMSDvbSVEMsiFIZWU0s3y7c7KueTemrdaCH4cK6MFLTe7fzIqbTPBN9D4f2twDouuNK_X44VZ5oGXUoXRiTEl9lo3kN1xU3T6_trZ4AskeG4N4gs6CGcp2ZYAQQ8uKf5EHe1GtNMLPJYUHCVkm0pkl1tV0FXzShZEARTZ8yjH5u1g5un1R8WzKtzvqdJhziTLuaNcB1ZVEf3oW7KBjlN2HmTp0CcV6-QKqw5Is78LxxvdngoctzfxhbpgEYGHoleM94So%5C%22%2C%5C%22667fcb35e9ad2b2be63fe5b34f2813dc%5C%22%2Cnull%2C%5B1%5D%2C0%2C%5B%5D%2C%5B%5D%2C1%2C0%5D%22%5D&at=AOTFbH4c7USaSzXSoOAifrmWxI25%3A1697824756141&",
  "method": "POST"
}).then(res => { 
let data = res.data.replace(/\\/g, '\\'.slice(1)).split('",[\"')[1].split('"]')[0].replace(/"rc_9df8b312d145653b\\\\\\\",\\[\\\"(.*?)(?<!\\\\)\\\"\\]/g, '').replace(/null/g, '').replace('nn**', '\n *').replace('nn*', '\n').replace('**nn*', '\n').replace(/\\\\\\/g, '').replace(/\\\\n/g, '\n').replace(/\\\\/g, '').replace(/rnrn/g, '').replace(/"\\"/g, '').replace(/rn/g, '\n').replace(/\\n*/g, '')
const extra = {
    msg: JSON.stringify(data)
   }
   resolve(extra)
  })
 })
}

async function gptpic(query) {
    const playod = { 
        captionInput: query, 
        captionModel: 'default',
    };
    try {
        const response = await axios.post('https://chat-gpt.pictures/api/generateImage', playod, {
            headers: {
                Accept: '*/*',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
            }
        });
        const data = response.data;
        const result = {
            data: data,
        };

        console.log(result);
        return result;
    } catch (error) {
        console.error(error);
        return error.message;
    }
}

async function aigpt(prompt) {
  try {
   const response = await axios.get("https://tools.revesery.com/ai/ai.php?query=" + prompt, {
     headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36'
      }
    });
    const res = response.data
    const result = res.result
    return result
  } catch (error) {
  console.error(error)
  }
}

async function WattPad(judul) { 
   return new Promise(async (resolve, reject) => { 
     try { 
       const { data } = await axios.get('https://www.wattpad.com/search/' + judul, { 
         headers: { 
           cookie: 'wp_id=d92aecaa-7822-4f56-b189-f8c4cc32825c; sn__time=j%3Anull; fs__exp=1; adMetrics=0; _pbkvid05_=0; _pbeb_=0; _nrta50_=0; lang=20; locale=id_ID; ff=1; dpr=1; tz=-8; te_session_id=1681636962513; _ga_FNDTZ0MZDQ=GS1.1.1681636962.1.1.1681637905.0.0.0; _ga=GA1.1.1642362362.1681636963; signupFrom=search; g_state={"i_p":1681644176441,"i_l":1}; RT=r=https%3A%2F%2Fwww.wattpad.com%2Fsearch%2Fanime&ul=1681637915624', 
           'suer-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0' 
         } 
       }), 
         $ = cheerio.load(data), 
         limk = 'https://www.wattpad.com', 
         _data = []; 
       $('.story-card-container > ul.list-group.new-list-group > li.list-group-item').each(function (i, u) { 
         let link = limk + $(u).find('a').attr('href') 
         let judul = $(u).find('a > div > div.story-info > div.title').text().trim() 
         let img = $(u).find('a > div > div.cover > img').attr('src') 
         let desc = $(u).find('a > div > div.story-info > .description').text().replace(/\s+/g, ' ') 
         let _doto = [] 
         $(u).find('a > div > div.story-info > .new-story-stats > .stats-item').each((u, i) => { 
           _doto.push($(i).find('.icon-container > .tool-tip > .sr-only').text()) 
         }) 
         _data.push({ 
           title: judul, 
           thumb: img, 
           desc: desc, 
           reads: _doto[0], 
           vote: _doto[1], 
           chapter: _doto[2], 
           link: link, 
         }) 
       }) 
  
       resolve(_data) 
     } catch (err) { 
       console.error(err) 
     } 
   }) 
 }

async function kodepos(kota) {
  return new Promise((resolve, reject) => {
    let postalcode = 'https://carikodepos.com/';
    let url = postalcode + '?s=' + kota;
    
    request.get({
      headers: {
        'Accept': 'application/json, text/javascript, */*;',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4209.3 Mobile Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'Origin': postalcode,
        'Referer': postalcode
      },
      url: url
    }, function(error, response, body) {
      if (error) return reject(error);
      
      let $ = cheerio.load(body);
      var search = $('tr');
      
      if (!search.length) return reject('No result could be found');
      
      var results = [];
      
      search.each(function(i) {
        if (i != 0) {
          var td = $(this).find('td');
          var result = {};
          
          td.each(function(i) {
            var value = $(this).find('a').html();
            var key = (i == 0) ? 'province' : (i == 1) ? 'city' : (i == 2) ? 'subdistrict' : (i == 3) ? 'urban' : 'postalcode';
            result[key] = value;
          });
          
          results.push(result);
        }
      });
      
      console.log(results);
      return resolve(results);
    });
  });
}

//@rifza.p.p
let baseUrl = "https://anichin.top"
async function anichinSearch(query) {
	return new Promise(async (resolve, reject) => {
		let res = {
			results_found: 0,
			data: []
		}
		let search = await axios.get(baseUrl, {
			params: {
				s: query
			}
		})
		const $ = cheerio.load(search.data)
		$('.listupd .bs').each((index, element) => {
			res.results_found = res.results_found + 1
			let data = {}
			data.title = $(element).find('.bsx a').attr('title')
			data.status = $(element).find('.bt .epx').text()
			data.type = $(element).find('.limit .typez').text()
			data.url = $(element).find('.bsx a').attr('href')
			data.imgUrl = $(element).find('img').attr('src')
			res.data.push(data)
		})
		resolve(res)
		 
	})
}

async function anichinEps(url) {
	return new Promise(async (resolve, reject) => {
		let res = {}
		let get = await axios.get(url)
		const $ = cheerio.load(get.data)
		res.author = Buffer.from("QHJpZnphLnAucA==", "base64").toString("ascii")
		res.title = $('.entry-title').text().trim()
		res.imageUrl = $('.ime img').attr('data-lazy-src').trim()
		res.status = $('span:contains("Status:")').text().replace('Status:', '').trim()
		res.rating = $('.rating strong').text().trim()
		res.dirilis = $('span:contains("Dirilis:")').text().replace('Dirilis:', '').trim()
		res.durasi = $('span:contains("Durasi:")').text().replace('Durasi:', '').trim()
		res.studio = $('span:contains("Studio:") a').text().trim()
		res.network = $('span:contains("Network:") a').text().trim()
		res.negara = $('span:contains("Negara:") a').text().trim()
		res.tipe = $('span:contains("Tipe:")').text().replace('Tipe:', '').trim()
		res.episode = $('span:contains("Episode:")').text().replace('Episode:', '').trim()
		res.fansub = $('span:contains("Fansub:")').text().replace('Fansub:', '').trim()
		res.posted_by = $('span:contains("Diposting oleh:")').text().replace('Diposting oleh:', '').trim()
		res.add = $('span:contains("Ditambahkan:")').text().replace('Ditambahkan:', '').trim()
		res.edited = $('span:contains("Terakhir diedit:")').text().replace('Terakhir diedit:', '').trim()
		let genres = []
		$('.genxed a[rel="tag"]').each((index, element) => {
			genres.push($(element).text().trim())
		})
		res.genres = genres.join(', ')
		res.sinopsis = $('.entry-content p').eq(0).text().trim()
		res.note = $('.entry-content p').eq(1).text().trim()
		const episodes = []

		$('.eplister li').each((index, element) => {

			const episode = {}
			const link = $(element).find('a')
			episode.url = link.attr('href')
			episode.number = link.find('.epl-num').text().trim()
			episode.name = link.find('.epl-title').text().trim()
			episode.date = link.find('.epl-date').text().trim()

			episodes.push(episode)

		})
	  	res.episodes = episodes
		
		resolve(res)
		//  fs.writeFileSync('anichin.html', get.data)
	})
}
//https://ok.ru/video/6078460529330
//https://ok.ru/videoembed/6078460529330
//anichinSearch('tang').then(a => console.log(a))
//anichinGetEps('https://anichin.top/soul-land-2-the-unrivaled-tang-sect/').then(a => console.log(a)

//axios.get('https://anichin.top/soul-land-2-the-unrivaled-tang-sect-episode-01-subtitle-indonesia/').then(a => fs.writeFileSync('./anichin.html', a.data))

async function mediafire(url) {
	let res = await axios.get(url)
	let get = cheerio.load(res.data)
	let urlFile = get('a#downloadButton').attr('href')
	let sizeFile = get('a#downloadButton').text().replace('Download', '').replace('(', '').replace(')', '').replace('\n', '').replace('\n', '').replace('', '')
	let split = urlFile.split('/')
	let nameFile = split[5]
	mime = nameFile.split('.')
	mime = mime[1]
	let result = {
		title: nameFile,
		size: sizeFile,
		url: urlFile
	}
	return result
}

function soundcloud (url)  {
    return new Promise((resolve, reject) => {
        axios.get('https://soundcloudmp3.org/id').then((data) => {
            let a = cheerio.load(data.data)
            let token = a('form#conversionForm > input[type=hidden]').attr('value')
            const options = {
                method: 'POST',
                url: `https://soundcloudmp3.org/converter`,
                headers: {
                    "content-type": "application/x-www-form-urlencoded;",
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
                    "Cookie": data["headers"]["set-cookie"],
                },
                formData: {
                    _token: token,
                    url: url
                }
            };
            request(options, async function(error, response, body) {
                if (error) return reject()
                $get = cheerio.load(body)
                const result = {
                    title: $get('#preview > div:nth-child(3) > p:nth-child(2)').text().replace('Title:',''),
                    duration: $get('#preview > div:nth-child(3) > p:nth-child(3)').text().replace(/Length\:|Minutes/g,''),
                    quality: $get('#preview > div:nth-child(3) > p:nth-child(4)').text().replace('Quality:',''),
                    thumbnail: $get('#preview > div:nth-child(3) > img').attr('src'),
                    download: $get('#download-btn').attr('href')
                }
                resolve(result)
            });
        })
    })
}

function twitter(link){
	return new Promise((resolve, reject) => {
		let config = {
			'URL': link
		}
		axios.post('https://twdown.net/download.php',qs.stringify(config),{
			headers: {
				"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
				"sec-ch-ua": '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
				"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
				"cookie": "_ga=GA1.2.1388798541.1625064838; _gid=GA1.2.1351476739.1625064838; __gads=ID=7a60905ab10b2596-229566750eca0064:T=1625064837:RT=1625064837:S=ALNI_Mbg3GGC2b3oBVCUJt9UImup-j20Iw; _gat=1"
			}
		})
		.then(({ data }) => {
		const $ = cheerio.load(data)
		resolve({
				desc: $('div:nth-child(1) > div:nth-child(2) > p').text().trim(),
				thumb: $('div:nth-child(1) > img').attr('src'),
				video_sd: $('tr:nth-child(2) > td:nth-child(4) > a').attr('href'),
				video_hd: $('tbody > tr:nth-child(1) > td:nth-child(4) > a').attr('href'),
				audio: 'https://twdown.net/' + $('body > div.jumbotron > div > center > div.row > div > div:nth-child(5) > table > tbody > tr:nth-child(3) > td:nth-child(4) > a').attr('href')
			})
		})
	.catch(reject)
	})
}

function facebook(link){
	return new Promise((resolve,reject) => {
	let config = {
		'url': link
		}
	axios('https://www.getfvid.com/downloader',{
			method: 'POST',
			data: new URLSearchParams(Object.entries(config)),
			headers: {
				"content-type": "application/x-www-form-urlencoded",
				"user-agent":  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
				"cookie": "_ga=GA1.2.1310699039.1624884412; _pbjs_userid_consent_data=3524755945110770; cto_bidid=rQH5Tl9NNm5IWFZsem00SVVuZGpEd21sWnp0WmhUeTZpRXdkWlRUOSUyQkYlMkJQQnJRSHVPZ3Fhb1R2UUFiTWJuVGlhVkN1TGM2anhDT1M1Qk0ydHlBb21LJTJGNkdCOWtZalRtZFlxJTJGa3FVTG1TaHlzdDRvJTNE; cto_bundle=g1Ka319NaThuSmh6UklyWm5vV2pkb3NYaUZMeWlHVUtDbVBmeldhNm5qVGVwWnJzSUElMkJXVDdORmU5VElvV2pXUTJhQ3owVWI5enE1WjJ4ZHR5NDZqd1hCZnVHVGZmOEd0eURzcSUyQkNDcHZsR0xJcTZaRFZEMDkzUk1xSmhYMlY0TTdUY0hpZm9NTk5GYXVxWjBJZTR0dE9rQmZ3JTNEJTNE; _gid=GA1.2.908874955.1625126838; __gads=ID=5be9d413ff899546-22e04a9e18ca0046:T=1625126836:RT=1625126836:S=ALNI_Ma0axY94aSdwMIg95hxZVZ-JGNT2w; cookieconsent_status=dismiss"
			}
		})
	.then(async({ data }) => {
		const $ = cheerio.load(data)	
		resolve({
			video_sd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
			video_hd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
			audio: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(2) > a').attr('href')
			})
		})
	.catch(reject)
	})
}

function parseFileSize(size) {
    return parseFloat(size) * (/GB/i.test(size)
        ? 1000000
        : /MB/i.test(size)
            ? 1000
            : /KB/i.test(size)
                ? 1
                : /bytes?/i.test(size)
                    ? 0.001
                    : /B/i.test(size)
                        ? 0.1
                        : 0);
}

function sfilemobi(url) {
    return new Promise(async(resolve, reject) => {
		var _a, _b, _c, _d, _e, _f, _g, _h, _j;
		if (!/sfile\.mobi/i.test(url)) return resolve()	
		const html = await axios.get(url).catch(function (error) {})
		if (!html) {
			resolve();
		}else{
			const $ = cheerio.load(html.data);
			const $k = (_a = /var z = (.*?);/i.exec($.html())) === null || _a === void 0 ? void 0 : _a[1];
			const urlPage = (((_d = (((_b = /var db = "(.*?)"/i.exec($.html())) === null || _b === void 0 ? void 0 : _b[1]) || ((_c = /var sf = "(.*?)"/i.exec($.html())) === null || _c === void 0 ? void 0 : _c[1]))) === null || _d === void 0 ? void 0 : _d.replace(/\\(\\)?/gi, '')) ||
				$('#download').attr('href')) + `&k=${$k}`;
			const filename = $('div.intro-container > img').attr('alt') || $('div.intro-container > h1').text();
			const icon = $('div.intro-container > img').attr('src');
			const type = (_e = /\/smallicon\/(.*?)\.svg/.exec(icon)) === null || _e === void 0 ? void 0 : _e[1];
			const $list = $('div.list');
			const mimetype = (_f = $list.eq(0).text().split('-')[1]) === null || _f === void 0 ? void 0 : _f.trim();
			const aploud = (_g = $list.eq(2).text().split('Uploaded:')[1]) === null || _g === void 0 ? void 0 : _g.trim();
			const $aploud = $list.eq(1).find('a');
			const aploudby = $aploud.eq(0).text();
			const aploudbyUrl = $aploud.eq(0).attr('href');
			const aploudon = $aploud.eq(1).text();
			const aploudonUrl = $aploud.eq(1).attr('href');
			const decs = $('body > div.w3-row-padding.w3-container.w3-white > div > div:nth-child(1) > div:nth-child(6) ').text()
			const downloads = parseInt((_h = $list.eq(3).text().split('Downloads:')[1]) === null || _h === void 0 ? void 0 : _h.trim());
			const filesizeH = (_j = /\((.*?)\)/i.exec($('#download').text())) === null || _j === void 0 ? void 0 : _j[1];
			const filesize = filesizeH && (0, parseFileSize)(filesizeH);
			const results = {
				url: urlPage,
				decs,
				filename,
				icon,
				type,
				mimetype,
				upload_date: aploud,
				upload_by: aploudby,
				upload_byUrl: aploudbyUrl,
				upload_don: aploudon,
				upload_donUrl: aploudonUrl,
				downloads_count: downloads,
				filesizeH,
				filesize: filesize
			};
		  resolve(results);
		}
	})
}

async function ytmp3(url) {
  return new Promise((resolve, reject) => {
    try {
      const id = yt.getVideoID(url)
      const yutub = yt.getInfo(`https://www.youtube.com/watch?v=${id}`)
      .then((data) => {
        let pormat = data.formats
        let audio = []
        for (let i = 0; i < pormat.length; i++) {
          if (pormat[i].mimeType == 'audio/webm; codecs=\"opus\"') {
            let aud = pormat[i]
            audio.push(aud.url)
          }
        }
        const title = data.player_response.microformat.playerMicroformatRenderer.title.simpleText
        const thumb = data.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url
        const channel = data.player_response.microformat.playerMicroformatRenderer.ownerChannelName
        const views = data.player_response.microformat.playerMicroformatRenderer.viewCount
        const published = data.player_response.microformat.playerMicroformatRenderer.publishDate
        
        const result = {
          title: title,
          thumb: thumb,
          channel: channel,
          published: published,
          views: views,
          url: audio[0]
        }
        return(result)
      })
      resolve(yutub)
    } catch (error) {
        reject(error);
      }
      console.log(error)
  })
}

async function ytmp4(url) {
  return new Promise((resolve, reject) => {
    try {
      const id = yt.getVideoID(url)
      const yutub = yt.getInfo(`https://www.youtube.com/watch?v=${id}`)
      .then((data) => {
        let pormat = data.formats
        let video = []
        for (let i = 0; i < pormat.length; i++) {
          if (pormat[i].container == 'mp4' && pormat[i].hasVideo == true && pormat[i].hasAudio == true) {
            let vid = pormat[i]
            video.push(vid.url)
          }
        }
        const title = data.player_response.microformat.playerMicroformatRenderer.title.simpleText
        const thumb = data.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url
        const channel = data.player_response.microformat.playerMicroformatRenderer.ownerChannelName
        const views = data.player_response.microformat.playerMicroformatRenderer.viewCount
        const published = data.player_response.microformat.playerMicroformatRenderer.publishDate
        
        const result = {
          title: title,
          thumb: thumb,
          channel: channel,
          published: published,
          views: views,
          url: video[0]
        }
        return(result)
      })
      resolve(yutub)
    } catch (error) {
        reject(error);
      }
      console.log(error)
  })
}

async function play(query) {
    return new Promise((resolve, reject) => {
        try {
            const search = yts(query)
            .then((data) => {
                const url = []
                const pormat = data.all
                for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].type == 'video') {
                        let dapet = pormat[i]
                        url.push(dapet.url)
                    }
                }
                const id = yt.getVideoID(url[0])
                const yutub = yt.getInfo(`https://www.youtube.com/watch?v=${id}`)
                .then((data) => {
                    let pormat = data.formats
                    let audio = []
                    let video = []
                    for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].mimeType == 'audio/webm; codecs=\"opus\"') {
                        let aud = pormat[i]
                        audio.push(aud.url)
                    }
                    }
                    const title = data.player_response.microformat.playerMicroformatRenderer.title.simpleText
                    const thumb = data.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url
                    const channel = data.player_response.microformat.playerMicroformatRenderer.ownerChannelName
                    const views = data.player_response.microformat.playerMicroformatRenderer.viewCount
                    const published = data.player_response.microformat.playerMicroformatRenderer.publishDate
                    const result = {
                    title: title,
                    thumb: thumb,
                    channel: channel,
                    published: published,
                    views: views,
                    url: audio[0]
                    }
                    return(result)
                })
                return(yutub)
            })
            resolve(search)
        } catch (error) {
            reject(error)
        }
        console.log(error)
    })
}

async function playaudio(query) {
    return new Promise((resolve, reject) => {
        try {
            const search = yts(query)
            .then((data) => {
                const url = []
                const pormat = data.all
                for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].type == 'video') {
                        let dapet = pormat[i]
                        url.push(dapet.url)
                    }
                }
                const id = yt.getVideoID(url[0])
                const yutub = yt.getInfo(`https://www.youtube.com/watch?v=${id}`)
                .then((data) => {
                    let pormat = data.formats
                    let audio = []
                    let video = []
                    for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].mimeType == 'audio/webm; codecs=\"opus\"') {
                        let aud = pormat[i]
                        audio.push(aud.url)
                    }
                    }
                    const title = data.player_response.microformat.playerMicroformatRenderer.title.simpleText
                    const thumb = data.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url
                    const channel = data.player_response.microformat.playerMicroformatRenderer.ownerChannelName
                    const views = data.player_response.microformat.playerMicroformatRenderer.viewCount
                    const published = data.player_response.microformat.playerMicroformatRenderer.publishDate
                    const result = {
                    title: title,
                    thumb: thumb,
                    channel: channel,
                    published: published,
                    views: views,
                    url: audio[0]
                    }
                    return(result)
                })
                return(yutub)
            })
            resolve(search)
        } catch (error) {
            reject(error)
        }
        console.log(error)
    })
}

async function playvideo(query) {
    return new Promise((resolve, reject) => {
        try {
            const search = yts(query)
            .then((data) => {
                const url = []
                const pormat = data.all
                for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].type == 'video') {
                        let dapet = pormat[i]
                        url.push(dapet.url)
                    }
                }
                const id = yt.getVideoID(url[0])
                const yutub = yt.getInfo(`https://www.youtube.com/watch?v=${id}`)
                .then((data) => {
                    let pormat = data.formats
                    let video = []
                    for (let i = 0; i < pormat.length; i++) {
                    if (pormat[i].container == 'mp4' && pormat[i].hasVideo == true && pormat[i].hasAudio == true) {
                        let vid = pormat[i]
                        video.push(vid.url)
                    }
                   }
                    const title = data.player_response.microformat.playerMicroformatRenderer.title.simpleText
                    const thumb = data.player_response.microformat.playerMicroformatRenderer.thumbnail.thumbnails[0].url
                    const channel = data.player_response.microformat.playerMicroformatRenderer.ownerChannelName
                    const views = data.player_response.microformat.playerMicroformatRenderer.viewCount
                    const published = data.player_response.microformat.playerMicroformatRenderer.publishDate
                    const result = {
                    title: title,
                    thumb: thumb,
                    channel: channel,
                    published: published,
                    views: views,
                    url: video[0]
                    }
                    return(result)
                })
                return(yutub)
            })
            resolve(search)
        } catch (error) {
            reject(error)
        }
        console.log(error)
    })
}

async function search(query) {
    return new Promise((resolve, reject) => {
        try {
            const cari = yts(query)
            .then((data) => {
                res = data.all
                return res
            })
            resolve(cari)
        } catch (error) {
            reject(error)
        }
        console.log(error)
    })
}

const clean = e => (e = e.replace(/(<br?\s?\/>)/gi, " \n")).replace(/(<([^>] )>)/gi, "");

async function shortener(e) {
  return e;
}

async function tiktok(url) {
  return new Promise(async (resolve, reject) => {
    try {
      let t = await axios("https://lovetik.com/api/ajax/search", { method: "post", data: new URLSearchParams(Object.entries({ query: url })) });

      const result = {};
      result.title = clean(t.data.desc);
      result.author = clean(t.data.author);
      result.nowm = await shortener((t.data.links[0].a || "").replace("https", "http"));
      result.watermark = await shortener((t.data.links[1].a || "").replace("https", "http"));
      result.audio = await shortener((t.data.links[2].a || "").replace("https", "http"));
      result.thumbnail = await shortener(t.data.cover);
      
      resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}

async function igdl(url) {
            let res = await axios("https://indown.io/");
            let _$ = cheerio.load(res.data);
            let referer = _$("input[name=referer]").val();
            let locale = _$("input[name=locale]").val();
            let _token = _$("input[name=_token]").val();
            let { data } = await axios.post(
              "https://indown.io/download",
              new URLSearchParams({
                link: url,
                referer,
                locale,
                _token,
              }),
              {
                headers: {
                  cookie: res.headers["set-cookie"].join("; "),
                },
              }
            );
            let $ = cheerio.load(data);
            let result = [];
            let __$ = cheerio.load($("#result").html());
            __$("video").each(function () {
              let $$ = $(this);
              result.push({
                type: "video",
                thumbnail: $$.attr("poster"),
                url: $$.find("source").attr("src"),
              });
            });
            __$("img").each(function () {
              let $$ = $(this);
              result.push({
                type: "image",
                url: $$.attr("src"),
              });
            });
          
            return result;
}

async function getLink(payload) {
  let download = await axios.post('https://terabox-dl.qtcloud.workers.dev/api/get-download', payload)
    .catch(e => e.response)
  return download.data?.downloadLink
}

async function terabox(url) {
  let id = (url.split(/surl=|\/s\//) || [])[1]
  id = `1${id.replace(/^1/, '')}`

  let info = await axios.get(`https://terabox-dl.qtcloud.workers.dev/api/get-info?shorturl=${id}`)
    .catch(e => e.response)
  if (info.status !== 200) throw info.statusText

  info = info.data
  if (!info.ok) throw info.message

  for (let file of info.list) {
    if (file.children.length) for (let child of file.children) {
      let dlUrl = await getLink({
        shareid: info.shareid,
        uk: info.uk,
        sign: info.sign,
        timestamp: info.timestamp,
        fs_id: child.fs_id
      })
      child.downloadLink = dlUrl
    } else {
      let dlUrl = await getLink({
        shareid: info.shareid,
        uk: info.uk,
        sign: info.sign,
        timestamp: info.timestamp,
        fs_id: file.fs_id
      })
      file.downloadLink = dlUrl
    }
  }

  return info
}

function screenshotWebsite(url, device) {
  return new Promise((resolve, reject) => {
    const baseURL = 'https://www.screenshotmachine.com'
    const param = {
      url: url,
      device: device,
      cacheLimit: 0
    }
    axios({
      url: baseURL + '/capture.php',
      method: 'POST',
      data: new URLSearchParams(Object.entries(param)),
      headers: {
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
      }
    }).then((data) => {
      const cookies = data.headers['set-cookie']
      if (data.data.status == 'success') {
        axios.get(baseURL + '/' + data.data.link, {
          headers: {
            'cookie': cookies.join('')
          },
          responseType: 'arraybuffer'
        }).then(({
            data
          }) => {
          resolve(data)
        })
      } else {
        reject()
      }
    }).catch(reject)
  })
}

function styleText(text) {
  return new Promise((resolve,
    reject) => {
    axios.get('http://qaz.wtf/u/convert.cgi?text=' + text)
    .then(({
      data
    }) => {
      let $ = cheerio.load(data)
      let result = []
      $('table > tbody > tr').each(function (a, b) {
        result.push({
          text: $(b).find('td:nth-child(2)').text().trim()
        })
      }),
      resolve(result)
    })
  })
}

const base64Encode = (text) => {
  return Buffer.from(text).toString('base64');
};

const base64Decode = (text) => {
  return Buffer.from(text, 'base64').toString('ascii');
};

const base32Encode = (text) => {
  const base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  let encodedText = '';

  for (let i = 0; i < text.length; i++) {
    const charCode = text.charCodeAt(i);
    bits += charCode.toString(2).padStart(8, '0');
  }

  bits = bits.padEnd(Math.ceil(bits.length / 5) * 5, '0');

  for (let i = 0; i < bits.length; i += 5) {
    const index = parseInt(bits.substr(i, 5), 2);
    encodedText += base32Chars[index];
  }

  return encodedText;
};

const base32Decode = (encodedText) => {
  const base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';

  for (let i = 0; i < encodedText.length; i++) {
    const char = encodedText.charAt(i);
    const index = base32Chars.indexOf(char);
    bits += index.toString(2).padStart(5, '0');
  }

  bits = bits.slice(0, bits.lastIndexOf('1'));

  let decodedText = '';

  for (let i = 0; i < bits.length; i += 8) {
    const byte = bits.substr(i, 8);
    const charCode = parseInt(byte, 2);
    decodedText += String.fromCharCode(charCode);
  }

  return decodedText;
};

async function ttStory(username) {
  return new Promise(async (resolve, reject) => {
    await axios
      .request({
        baseURL: "https://tik.storyclone.com",
        url: "/user/" + username,
        method: "GET"
    })
    .then(( response ) => {
      const $ = cheerio.load(response.data)
      const result = {
        profile: $("div.row > div.col-lg-7.separate-column > div.user-info > figure > img").attr("src"),
        username: $("div.row > div.col-lg-7.separate-column > div.user-info > div.article > div.top > div.title > h1").text().trim(),
        name: $("div.row > div.col-lg-7.separate-column > div.user-info > div.article > div.top > div.title > h2").text().trim(),
        desc: $("div.row > div.col-lg-7.separate-column > div.user-info > div.article > div.description > p").text().trim(),
        likes: $("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(0).text().trim(),
        followers: $("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(1).text().trim(),
        following: $("div.col-lg-5.separate-column > div.row > div.col > div.number-box > .count").eq(2).text().trim(),
      }
      resolve(result)
    })
    .catch((e) => {
      console.log(e)
      reject({
        status: 300,
        message: "request failed",
      });
    })
  })
}

async function tiktokv2(url) {
    const urls = { url };
    try {
        const response = await axios.post('https://ssstiktokio.com/wp-json/aio-dl/video-data/', urls, {
            headers: {
                Accept: '*/*',
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
            }
        });
        const data = response.data;
        const result = {
            data: data,
        };

        console.log(result);
        return result;
    } catch (error) {
        console.error(error);
        return error.message;
    }
}

let wss = 'wss://yanzbotz-gensin.hf.space/queue/join';
let send_has_payload = {
  "session_hash": "dhs5kr6b99",
  "fn_index": 2
}

// Yanz & Danz
//let text = "お疲れ様です，トレーナーさん。"
//let character = "无声铃鹿 Silence Suzuka (Umamusume Pretty Derby)"

async function soviets(text, character) {
return new Promise(async(resolve, reject) => {
let result = {}
let send_data_payload =  {
  "fn_index": 2,
  "data": [
    text,
    character,
    "日本語",
    1,
    false 
  ],
  "session_hash": "dhs5kr6b99"
}

    const ws = new WebSocket(wss);

    ws.onopen = function() {
     console.log("Connected to websocket")
    };

    ws.onmessage = async function(event) {
      let message = JSON.parse(event.data);

      switch (message.msg) {
        case 'send_hash':
          ws.send(JSON.stringify(send_has_payload));
          break;

        case 'estimation':
          console.log('Menunggu antrean: ️' + message.rank)
          break;

        case 'send_data':
          console.log('Mengirim audio...');        
          ws.send(JSON.stringify(send_data_payload));
          break;

        case 'process_completed':          
          result.url = 'https://yanzbotz-gensin.hf.space/file=' + message.output.data[1].name
          break;
      }
    };

    ws.onclose = function(event) {
      if (event.code === 1000) {
        console.log('Process completed️');
      } else {
        msg.reply('[ ERROR ] >> WebSocket Connection:\n');
      }
      resolve(result)
    };
  })
}

async function rekening(bank, nomor) {
  return new Promise(async (resolve, reject) => {
    const { data } = await axios({
      url: 'https://tools.revesery.com/rekening/check_account.php',
      method: "POST",
      data: qs.stringify({
        "account_bank": bank,
        "account_number": nomor
      }),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=utf-8",
        "Accept": "*/*"
      }
    })
    console.log(data)
    resolve(data)
  })
}
async function ChatGpt(text) {
  return new Promise(async (resolve, reject) => {
    axios("https://www.chatgptdownload.org/wp-json/mwai-ui/v1/chats/submit", {
      "headers": {
        "content-type": "application/json",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
      },
      data: {
        "id": null,
        "botId": "default",
        "session": "y2cog0j45q",
        "clientId": "7tzjniqtrgx",
        "contextId": 443,
        "messages": [{
          "id": "fkzhaikd7vh",
          "role": "assistant",
          "content": "Saya adalah Dann-MD, bot WhatsApp yang dibuat dengan Node.js, Python. Saya juga dikembangkan oleh seorang Danz atau Creator kami.",
          "who": "AI: ",
          "timestamp": 1695725910365
        }],
        "newMessage": text,
        "stream": false
      },
      "method": "POST"
    }).then(response => {
      resolve(response.data);
    });
  });
};

async function ChatGpt2(text) {
  return new Promise(async (resolve, reject) => {
  	
axios("https://gpt4login.com/wp-json/mwai-ui/v1/chats/submit", {
  "headers": {
    "Content-Type": "application/json",
    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"
  },
  data: {
  "id": "default",
  "botId": "default",
  "session": "N/A",
  "chatId": "kyni4qgv8f",
  "contextId": 27,
  "messages": [
    {
      "id": "wzgr4fdeg1",
      "role": "assistant",
      "content": "Saya adalah Dann-MD, bot WhatsApp yang dibuat dengan Node.js, Python. Saya juga dikembangkan oleh seorang Danz atau Creator kami.",
      "who": "AI: ",
      "timestamp": 1694958059686
    }
  ],
  "newMessage": text,
  "stream": false
},
  "method": "POST"
}).then( a => {
resolve(a.data.reply)
    })
  })
}

async function fbdl(url) {
	return new Promise((resolve, reject) => {
axios("https://getmyfb.com/process", {
  headers: {
    "cookie": "PHPSESSID=mtkljtmk74aiej5h6d846gjbo4; __cflb=04dToeZfC9vebXjRcJCMjjSQh5PprejufZXs2vHCt5; _token=K5Qobnj4QvoYKeLCW6uk"
  },
  data: { 
     id: url,
     locale: "en"
    },
  "method": "POST"
}).then(res => { 
let $ = cheerio.load(res.data)
let result = {}
result.caption = $("div.results-item-text").eq(0).text().trim()
result.thumb = $(".results-item-image-wrapper img").attr("src") 
result.result = $("a").attr("href")
 resolve(result) 
  })
 })
}

async function igdl2(Link) {
	const hasil = []
	const Form = {
		url: Link,
		submit: ""
	}
	await axios(`https://downloadgram.org/`, {
		method: "POST",
		data:  new URLSearchParams(Object.entries(Form)),
		headers: {
			"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
			"accept-language": "en-US,en;q=0.9,id;q=0.8",
			"cache-control": "max-age=0",
			"content-type": "application/x-www-form-urlencoded",
			"sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"",
			"cookie": "_ga=GA1.2.1695343126.1621491858; _gid=GA1.2.28178724.1621491859; __gads=ID=8f9d3ef930e9a07b-2258e672bec80081:T=1621491859:RT=1621491859:S=ALNI_MbqLxhztDiYZttJFX2SkvYei6uGOw; __atuvc=3%7C20; __atuvs=60a6eb107a17dd75000; __atssc=google%3B2; _gat_gtag_UA_142480840_1=1"
		},
		referrerPolicy: "strict-origin-when-cross-origin",
	}).then(async res => {
		const $ = cheerio.load(res.data)
		let url = $('#downloadBox').find('a').attr('href');
		await axios(Link, {
			method: "GET",
			data: null,
			headers: {
				"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
				"accept-language": "en-US,en;q=0.9,id;q=0.8",
				"cache-control": "max-age=0",
				"sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"",
				"cookie": "ig_did=08A3C465-7D43-4D8A-806A-88F98384E63B; ig_nrcb=1; mid=X_ipMwALAAFgQ7AftbrkhIDIdXJ8; fbm_124024574287414=base_domain=.instagram.com; shbid=17905; ds_user_id=14221286336; csrftoken=fXHAj5U3mcJihQEyVXfyCzcg46lHx7QD; sessionid=14221286336%3A5n4czHpQ0GRzlq%3A28; shbts=1621491639.7673564; rur=FTW"
			},
			referrerPolicy: "strict-origin-when-cross-origin"
		}).then(respon => {
			const ch = cheerio.load(respon.data)
			let title = ch('title').text().trim()
			const result = {
				status: true,
				result: {
					link: url,
					desc: title
				}
			}
			hasil.push(result)
		})
	})
	return hasil[0]
}

const wiki = async (query) => {
const res = await axios.get(`https://id.m.wikipedia.org/w/index.php?search=${query}`)
const $ = cheerio.load(res.data)
const hasil = []
let wiki = $('#mf-section-0').find('p').text()
let thumb = $('#mf-section-0').find('div > div > a > img').attr('src')
thumb = thumb ? thumb : '//pngimg.com/uploads/wikipedia/wikipedia_PNG35.png'
thumb = 'https:' + thumb
let judul = $('h1#section_0').text()
hasil.push({ wiki, thumb, judul })
return hasil
}

async function tiktok2(Url) {
	return new Promise (async (resolve, reject) => {
		await axios.request({
			url: "https://ttdownloader.com/",
			method: "GET",
			headers: {
				"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
				"accept-language": "en-US,en;q=0.9,id;q=0.8",
				"user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
				"cookie": "_ga=GA1.2.1240046717.1620835673; PHPSESSID=i14curq5t8omcljj1hlle52762; popCookie=1; _gid=GA1.2.1936694796.1623913934"
			}
		}).then(respon => {
			const $ = cheerio.load(respon.data)
			const token = $('#token').attr('value')
			axios({
				url: "https://ttdownloader.com/req/",
				method: "POST",
				data: new URLSearchParams(Object.entries({url: Url, format: "", token: token})),
				headers: {
					"accept": "*/*",
					"accept-language": "en-US,en;q=0.9,id;q=0.8",
					"content-type": "application/x-www-form-urlencoded; charset=UTF-8",
					"user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36",
					"cookie": "_ga=GA1.2.1240046717.1620835673; PHPSESSID=i14curq5t8omcljj1hlle52762; popCookie=1; _gid=GA1.2.1936694796.1623913934"
				}
			}).then(res => {
				const ch = cheerio.load(res.data)
				const result = {
					status: res.status,
					result: {
						nowatermark: ch('#results-list > div:nth-child(2)').find('div.download > a').attr('href'),
						watermark: ch('#results-list > div:nth-child(3)').find('div.download > a').attr('href'),
						audio: ch('#results-list > div:nth-child(4)').find(' div.download > a').attr('href')
					}
				}
				resolve(result)
			}).catch(reject)
		}).catch(reject)
	})
}

function herodetail(name) {
             return new Promise((resolve, reject) => {
                  var splitStr = name.toLowerCase().split(' ');
                  for (var i = 0; i < splitStr.length; i++) {
                       splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);     
                  }
                  const que = splitStr.join(' ')
                  axios.get('https://mobile-legends.fandom.com/wiki/' + que)
                  .then(({ data }) => {
                       const $ = cheerio.load(data)
                       let mw = []
                       let attrib = []
                       let skill = []
                       const name = $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td > table > tbody > tr > td > font > b').text() 
                       $('.mw-headline').get().map((res) => {
                            const mwna = $(res).text()
                            mw.push(mwna)
                       })
                       $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td').get().map((rest) => {
                            const haz = $(rest).text().replace(/\n/g,'')
                            attrib.push(haz)
                       })
                       $('#mw-content-text > div > div > div > div > div > div > table > tbody > tr > td > div.progressbar-small.progressbar > div').get().map((rest) => {
                            skill.push($(rest).attr('style').replace('width:',''))
                       })
                       axios.get('https://mobile-legends.fandom.com/wiki/' + que + '/Story')
                       .then(({ data }) => {
                            const $ = cheerio.load(data)
                            let pre = []
                            $('#mw-content-text > div > p').get().map((rest) => {
                                 pre.push($(rest).text())
                            })
                            const story = pre.slice(3).join('\n')
                            const items = []
                            const character = []
                            $('#mw-content-text > div > aside > section > div').get().map((rest) => {
                                 character.push($(rest).text().replace(/\n\t\n\t\t/g, '').replace(/\n\t\n\t/g,'').replace(/\n/g,''))
                            })
                            $('#mw-content-text > div > aside > div').get().map((rest) => {
                                 items.push($(rest).text().replace(/\n\t\n\t\t/g, '').replace(/\n\t\n\t/g,'').replace(/\n/g,''))
                            })
                            const img = $('#mw-content-text > div > aside > figure > a').attr('href')
                            const chara = character.slice(0,2)
                            const result = { 
                                 status: 200,
                                 hero_name: name + ` ( ${mw[0].replace('CV:',' CV:')} )`,
                                 entrance_quotes: attrib[2].replace('Entrance Quotes','').replace('\n',''),
                                 hero_feature: attrib[attrib.length - 1].replace('Hero Feature',''),
                                 image: img,
                                 items: items,
                                 character: {
                                      chara
                                 },
                                 attributes: {
                                      movement_speed: attrib[12].replace('● Movement Speed',''),
                                      physical_attack: attrib[13].replace('● Physical Attack',''),
                                      magic_power: attrib[14].replace('● Magic Power',''),
                                      attack_speed: attrib[15].replace('● Attack Speed',''),
                                      physical_defense: attrib[16].replace('● Physical Defense',''),
                                      magic_defense: attrib[17].replace('● Magic Defense',''),
                                      basic_atk_crit_rate: attrib[18].replace('● Basic ATK Crit Rate',''),
                                      hp: attrib[19].replace('● HP',''),
                                      mana: attrib[20].replace('● Mana',''),
                                      ability_crit_rate: attrib[21].replace('● Ability Crit Rate',''),
                                      hp_regen: attrib[22].replace('● HP Regen',''),
                                      mana_regen: attrib[23].replace('● Mana Regen','')
                                 },
                                 price: {
                                      battle_point: mw[1].split('|')[0].replace(/ /g,''),
                                      diamond: mw[1].split('|')[1].replace(/ /g,''),
                                      hero_fragment: mw[1].split('|')[2] ? mw[1].split('|')[2].replace(/ /g,'') : 'none'
                                 },
                                 role: mw[2],
                                 skill: {
                                      durability: skill[0],
                                      offense: skill[1],
                                      skill_effects: skill[2],
                                      difficulty: skill[3]
                                 },
                                 speciality: mw[3],
                                 laning_recommendation: mw[4],
                                 release_date: mw[5],
                                 background_story: story
                            }
                            resolve(result)
                       }).catch((e) => reject({ status: 404, message: e.message }))
                  }).catch((e) => reject({ status: 404, message: e.message }))
             })
        }
        
function herolist(){
            return new Promise((resolve, reject) => {
                  axios.get('https://mobile-legends.fandom.com/wiki/Mobile_Legends:_Bang_Bang_Wiki')
                  .then(({ data }) => {
                       const $ = cheerio.load(data)
                       let data_hero = []
                       let url = []
                       $('div > div > span > span > a').get().map((result) => {
                            const name = decodeURIComponent($(result).attr('href').replace('/wiki/',''))
                            const urln = 'https://mobile-legends.fandom.com' + $(result).attr('href')
                            data_hero.push(name)
                            url.push(urln)
                       })
                       resolve({ status: 200, hero: data_hero })
                  }).catch((e) => reject({ status: 404, message: e.message }))
             })
        }

async function shopee(item, limit) {
	const hasil = []
	await axios.request(`https://shopee.co.id/api/v4/search/search_items?by=relevancy&keyword=${item}&limit=${limit}&newest=0&order=desc&page_type=search&scenario=PAGE_GLOBAL_SEARCH&version=2`, {
		method: "GET",
		data: null,
		headers: {
			"accept": "*/*",
			"accept-language": "en-US,en;q=0.9,id;q=0.8",
			"if-none-match-": "55b03-856cd63f16112f8a43da6096f97ac3fe",
			"sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"90\", \"Google Chrome\";v=\"90\"",
		}
	}).then(respon => {
		hasil.push(respon.data)
	})
	return hasil[0]
}

async function otakudesu(querry) {
	try {
	const link = await axios.get(`https://otakudesu.moe/?s=${querry}&post_type=anime`)
	const c = cheerio.load(link.data)
	let id = c('#venkonten > div > div.venser > div > div > ul > li:nth-child(1) > h2 > a').attr('href')
	const Link = await axios.get(id)
	const $ = cheerio.load(Link.data)
	let judul = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(1) > span').text().trim()
	let judulJpn = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(2) > span').text().trim()
	let score = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(3) > span').text().trim()
	let Produser = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(4) > span').text().trim()
	let Type = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(5) > span').text().trim()
	let Status = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(6) > span').text().trim()
	let TotalEpisode = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(7) > span').text().trim()
	let durasi = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(8) > span').text().trim()
	let Rilis = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(9) > span').text().trim()
	let studio = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(10) > span').text().trim()
	let genre = $('#venkonten').find('div.venser > div.fotoanime > div.infozin > div > p:nth-child(11) > span').text().trim()
	let thumb = $('#venkonten > div.venser > div.fotoanime').find('img').attr('src')
	let Sinopsis = $('#venkonten > div.venser > div.fotoanime > div.sinopc').find('p').text().trim()
	let LinkDown = $('#venkonten').find('div.venser > div:nth-child(8) > ul > li:nth-child(4) > span:nth-child(1) > a').attr('href')
	const data = {
		status: link.status,
		result: {
			judul: judul,
			thumb: thumb,
			japan: judulJpn,
			rating: score,
			produser: Produser,
			type: Type,
			status: Status,
			episode: TotalEpisode,
			durasi: durasi,
			rilis: Rilis,
			studio: studio,
			genre: genre,
			link: LinkDown,
			sinopsis: Sinopsis
		}
	}
	return data
} catch (err) {
	var notFond = {
		status: link.status,
		message: 'Terjadi kesalahan!'
	}
	return notFond
}
}

async function film(querry) {
	const link =  await axios.get(`https://123movies.mom/search/?keyword=${querry}`)
	const $ = cheerio.load(link.data)
	let hasil = []
	let result = []
	$('#main').each(function (a, b) {
			 $(b).find('div').each(function (c, d) {
				let url = $(d).find('a').attr('href')
				let img = $(d).find('a > img').attr('src')
				let judul = $(d).find('a > img').attr('alt')
				let data = {
					judul: judul,
					thumb: img,
					url: url
				}
				result.push(data)
			})
			for (let i = 29; i < result.length; i++) {
			hasil.push(result[i])
			}
	})
	return hasil
}

function playstore(name){
	return new Promise((resolve, reject) => {
		axios.get('https://play.google.com/store/search?q='+ name +'&c=apps')
		.then(({ data }) => {
			const $ = cheerio.load(data)
			let ln = [];
			let nm = [];
			let dv = [];
			let lm = [];
			const result = [];
			$('div.wXUyZd > a').each(function(a,b){
				const link =  'https://play.google.com' + $(b).attr('href')
				ln.push(link);
			})
			$('div.b8cIId.ReQCgd.Q9MA7b > a > div').each(function(d,e){
				const name = $(e).text().trim()
				nm.push(name);
			})
			$('div.b8cIId.ReQCgd.KoLSrc > a > div').each(function(f,g){
				const dev = $(g).text().trim();
				dv.push(dev)
			})
			$('div.b8cIId.ReQCgd.KoLSrc > a').each(function(h,i){
				const limk = 'https://play.google.com' + $(i).attr('href');
				lm.push(limk);
			})			
		for (let i = 0; i < ln.length; i++){
			result.push({
				name: nm[i],
				link: ln[i],
				developer: dv[i],
				link_dev: lm[i]
			})
	}
		resolve(result)
		})
	.catch(reject)
	})
}

function lirik(judul){
	return new Promise(async(resolve, reject) => {
   		axios.get('https://www.musixmatch.com/search/' + judul)
   		.then(async({ data }) => {
   		const $ = cheerio.load(data)
   		const hasil = {};
   		let limk = 'https://www.musixmatch.com'
   		const link = limk + $('div.media-card-body > div > h2').find('a').attr('href')
	   		await axios.get(link)
	   		.then(({ data }) => {
		   		const $$ = cheerio.load(data)
		   		hasil.thumb = 'https:' + $$('div.col-sm-1.col-md-2.col-ml-3.col-lg-3.static-position > div > div > div').find('img').attr('src')
		  		$$('div.col-sm-10.col-md-8.col-ml-6.col-lg-6 > div.mxm-lyrics').each(function(a,b) {
		   hasil.lirik = $$(b).find('span > p > span').text() +'\n' + $$(b).find('span > div > p > span').text()
		   })
	   })
	   resolve(hasil)
   })
   .catch(reject)
   })
}

function tebakgambar() {
	return new Promise(async(resolve, reject) => {
    axios.get('https://jawabantebakgambar.net/all-answers/')
    .then(({ data }) => {
    const $ = cheerio.load(data)
    const result = [];
    let random = Math.floor(Math.random() * 2836) + 2;
    let link2 = 'https://jawabantebakgambar.net'
    $(`#images > li:nth-child(${random}) > a`).each(function(a, b) {
    const img = link2 + $(b).find('img').attr('data-src')
    const jwb = $(b).find('img').attr('alt')
    result.push({
    	image: img,
    	jawaban: jwb
    })

    	resolve(result)
    })
    	})
    .catch(reject)
	})
}

function komiku(judul) {
	return new Promise(async(resolve,reject) => {
	axios.get('https://data3.komiku.id/cari/?post_type=manga&s=' + encodeURIComponent(judul))
	.then(({ data }) => {
	const $ = cheerio.load(data)
	const img = []; 
	const or = [];
	const ind = [];
	const up = [];
	const des = [];
	const li = [];
	const ch = [];
	const ch1 = [];
	$('div.daftar').each(function (a,b) {
		img.push($(b).find('img').attr('data-src'))
	$('div.kan').each(function(c,d) {
		or.push($(d).find('h3').text().trim())
		ind.push($(d).find('span.judul2').text())
		li.push('https://komiku.id' + $(d).find('a').attr('href'))
		up.push($(d).find('p').text().trim().split('. ')[0])
		des.push($(d).find('p').text().trim().split('. ')[1])
		ch1.push($(d).find('div:nth-child(5) > a').attr('title'))
	$('div.new1').each(function(e,f) {
		ch.push($(f).find('a').attr('title'))
		})
	})
})
	for (let i = 0 ; i < img.length; i++) {
		resolve({
			image: img[i],
			title: or[i],
			indo: ind[i],
			update: up[i],
			desc: des[i],
			chapter_awal: ch[i],
			chapter_akhir: ch1[i],
			link: li[i]
		})
	}
})
	.catch(reject)
	})
} 

function linkwa(nama){
	return new Promise((resolve,reject) => {
		axios.get('http://ngarang.com/link-grup-wa/daftar-link-grup-wa.php?search='+ nama +'&searchby=name')
		.then(({ data }) => {
			const $ = cheerio.load(data);
			const result = [];
			const lnk = [];
			const nm = [];
		$('div.wa-chat-title-container').each(function(a,b){
			const limk = $(b).find('a').attr('href');
			lnk.push(limk)
			})
		$('div.wa-chat-title-text').each(function(c,d) {
			const name = $(d).text();
			nm.push(name)
			})
		for( let i = 0; i < lnk.length; i++){
			result.push({
				nama: nm[i].split('. ')[1],
				link: lnk[i].split('?')[0]
			})
		}
		resolve(result)
		})
	.catch(reject)
	})
}

function WattPad2(judul){
	return new Promise((resolve, reject) => {
		axios.get('https://www.wattpad.com/search/' + judul)
		.then(({data}) => {
			const $ = cheerio.load(data)
			const result = [];
			const jdl = [];
			const img = [];
			const des = [];
			const lnk = [];
			const red = [];
			const vt = [];
			const limk = 'https://www.wattpad.com/'
			$('div.cover.cover-xs.pull-left').each(function(a,b){
				img.push($(b).find('img').attr('src')) 
			})
			$('div.content > h5').each(function(a,b) {
				jdl.push($(b).text().trim())
			})	
			$('div.content > p').each(function(a,b){
				des.push($(b).text().trim())
			})	
			$('#results-stories > div > ul > li').each(function(a,b){
				lnk.push(limk + $(b).find('a.on-result').attr('data-id'))
			})
			$('div.content > div > small.reads').each(function(a,b){
				red.push($(b).text())
			})
			$('div.content > div > small.votes').each(function(a, b) {
				vt.push($(b).text())
			})
		for (let i = 0; i < lnk.length; i++){
			result.push({
					judul: jdl[i],
					desc: des[i],
					vote: vt[i],
					reads: red[i],
					image: img[i],
					link: lnk[i]
			})
			resolve(result)
		}
		})
	.catch({message: 'err'})
	})
}


function CekNik(nik) {
    // Data wilayah & kodepos
    const U = { "provinsi": { "11": "ACEH", "12": "SUMATERA UTARA", "13": "SUMATERA BARAT", "14": "RIAU", "15": "JAMBI", "16": "SUMATERA SELATAN", "17": "BENGKULU", "18": "LAMPUNG", "19": "KEPULAUAN BANGKA BELITUNG", "21": "KEPULAUAN RIAU", "31": "DKI JAKARTA", "32": "JAWA BARAT", "33": "JAWA TENGAH", "34": "DAERAH ISTIMEWA YOGYAKARTA", "35": "JAWA TIMUR", "36": "BANTEN", "51": "BALI", "52": "NUSA TENGGARA BARAT", "53": "NUSA TENGGARA TIMUR", "61": "KALIMANTAN BARAT", "62": "KALIMANTAN TENGAH", "63": "KALIMANTAN SELATAN", "64": "KALIMANTAN TIMUR", "65": "KALIMANTAN UTARA", "71": "SULAWESI UTARA", "72": "SULAWESI TENGAH", "73": "SULAWESI SELATAN", "74": "SULAWESI TENGGARA", "75": "GORONTALO", "76": "SULAWESI BARAT", "81": "MALUKU", "82": "MALUKU UTARA", "91": "P A P U A", "92": "PAPUA BARAT" }, "kabkot": { "1101": "KAB. ACEH SELATAN", "1102": "KAB. ACEH TENGGARA", "1103": "KAB. ACEH TIMUR", "1104": "KAB. ACEH TENGAH", "1105": "KAB. ACEH BARAT", "1106": "KAB. ACEH BESAR", "1107": "KAB. PIDIE", "1108": "KAB. ACEH UTARA", "1109": "KAB. SIMEULUE", "1110": "KAB. ACEH SINGKIL", "1111": "KAB. BIREUEN", "1112": "KAB. ACEH BARAT DAYA", "1113": "KAB. GAYO LUES", "1114": "KAB. ACEH JAYA", "1115": "KAB. NAGAN RAYA", "1116": "KAB. ACEH TAMIANG", "1117": "KAB. BENER MERIAH", "1118": "KAB. PIDIE JAYA", "1171": "KOTA BANDA ACEH", "1172": "KOTA SABANG", "1173": "KOTA LHOKSEUMAWE", "1174": "KOTA LANGSA", "1175": "KOTA SUBULUSSALAM", "1201": "KAB. TAPANULI TENGAH", "1202": "KAB. TAPANULI UTARA", "1203": "KAB. TAPANULI SELATAN", "1204": "KAB. NIAS", "1205": "KAB. LANGKAT", "1206": "KAB. KARO", "1207": "KAB. DELI SERDANG", "1208": "KAB. SIMALUNGUN", "1209": "KAB. ASAHAN", "1210": "KAB. LABUHANBATU", "1211": "KAB. DAIRI", "1212": "KAB. TOBA SAMOSIR", "1213": "KAB. MANDAILING NATAL", "1214": "KAB. NIAS SELATAN", "1215": "KAB. PAKPAK BHARAT", "1216": "KAB. HUMBANG HASUNDUTAN", "1217": "KAB. SAMOSIR", "1218": "KAB. SERDANG BEDAGAI", "1219": "KAB. BATU BARA", "1220": "KAB. PADANG LAWAS UTARA", "1221": "KAB. PADANG LAWAS", "1222": "KAB. LABUHANBATU SELATAN", "1223": "KAB. LABUHANBATU UTARA", "1224": "KAB. NIAS UTARA", "1225": "KAB. NIAS BARAT", "1271": "KOTA MEDAN", "1272": "KOTA PEMATANG SIANTAR", "1273": "KOTA SIBOLGA", "1274": "KOTA TANJUNG BALAI", "1275": "KOTA BINJAI", "1276": "KOTA TEBING TINGGI", "1277": "KOTA PADANGSIDIMPUAN", "1278": "KOTA GUNUNGSITOLI", "1301": "KAB. PESISIR SELATAN", "1302": "KAB. SOLOK", "1303": "KAB. SIJUNJUNG", "1304": "KAB. TANAH DATAR", "1305": "KAB. PADANG PARIAMAN", "1306": "KAB. AGAM", "1307": "KAB. LIMA PULUH KOTA", "1308": "KAB. PASAMAN", "1309": "KAB. KEPULAUAN MENTAWAI", "1310": "KAB. DHARMASRAYA", "1311": "KAB. SOLOK SELATAN", "1312": "KAB. PASAMAN BARAT", "1371": "KOTA PADANG", "1372": "KOTA SOLOK", "1373": "KOTA SAWAHLUNTO", "1374": "KOTA PADANG PANJANG", "1375": "KOTA BUKITTINGGI", "1376": "KOTA PAYAKUMBUH", "1377": "KOTA PARIAMAN", "1401": "KAB. KAMPAR", "1402": "KAB. INDRAGIRI HULU", "1403": "KAB. BENGKALIS", "1404": "KAB. INDRAGIRI HILIR", "1405": "KAB.  PELALAWAN", "1406": "KAB.  ROKAN HULU", "1407": "KAB.  ROKAN HILIR", "1408": "KAB.  SIAK", "1409": "KAB. KUANTAN SINGINGI", "1410": "KAB. KEPULAUAN MERANTI", "1471": "KOTA PEKANBARU", "1472": "KOTA DUMAI", "1501": "KAB.  KERINCI", "1502": "KAB.  MERANGIN", "1503": "KAB. SAROLANGUN", "1504": "KAB. BATANGHARI", "1505": "KAB.  MUARO JAMBI", "1506": "KAB. TANJUNG JABUNG BARAT", "1507": "KAB. TANJUNG JABUNG TIMUR", "1508": "KAB. BUNGO", "1509": "KAB. TEBO", "1571": "KOTA JAMBI", "1572": "KOTA SUNGAI PENUH", "1601": "KAB. OGAN KOMERING ULU", "1602": "KAB. OGAN KOMERING ILIR", "1603": "KAB. MUARA ENIM", "1604": "KAB. LAHAT", "1605": "KAB. MUSI RAWAS", "1606": "KAB. MUSI BANYUASIN", "1607": "KAB. BANYUASIN", "1608": "KAB. OGAN KOMERING ULU TIMU", "1609": "KAB. OGAN KOMERING ULU SELAT", "1610": "KAB. OGAN ILIR", "1611": "KAB. EMPAT LAWANG", "1612": "KAB. PENUKAL ABAB LEMATANG I", "1613": "KAB. MUSI RAWAS UTARA", "1671": "KOTA PALEMBANG", "1672": "KOTA PAGAR ALAM", "1673": "KOTA LUBUK LINGGAU", "1674": "KOTA PRABUMULIH", "1701": "KAB. BENGKULU SELATAN", "1702": "KAB. REJANG LEBONG", "1703": "KAB. BENGKULU UTARA", "1704": "KAB. KAUR", "1705": "KAB. SELUMA", "1706": "KAB. MUKO MUKO", "1707": "KAB. LEBONG", "1708": "KAB. KEPAHIANG", "1709": "KAB. BENGKULU TENGAH", "1771": "KOTA BENGKULU", "1801": "KAB. LAMPUNG SELATAN", "1802": "KAB. LAMPUNG TENGAH", "1803": "KAB. LAMPUNG UTARA", "1804": "KAB. LAMPUNG BARAT", "1805": "KAB. TULANG BAWANG", "1806": "KAB. TANGGAMUS", "1807": "KAB. LAMPUNG TIMUR", "1808": "KAB. WAY KANAN", "1809": "KAB. PESAWARAN", "1810": "KAB. PRINGSEWU", "1811": "KAB. MESUJI", "1812": "KAB. TULANG BAWANG BARAT", "1813": "KAB. PESISIR BARAT", "1871": "KOTA BANDAR LAMPUNG", "1872": "KOTA METRO", "1901": "KAB. BANGKA", "1902": "KAB. BELITUNG", "1903": "KAB. BANGKA SELATAN", "1904": "KAB. BANGKA TENGAH", "1905": "KAB. BANGKA BARAT", "1906": "KAB. BELITUNG TIMUR", "1971": "KOTA PANGKAL PINANG", "2101": "KAB. BINTAN", "2102": "KAB. KARIMUN", "2103": "KAB. NATUNA", "2104": "KAB. LINGGA", "2105": "KAB. KEPULAUAN ANAMBAS", "2171": "KOTA BATAM", "2172": "KOTA TANJUNG PINANG", "3101": "KAB. ADM. KEP. SERIBU", "3171": "KOTA ADM. JAKARTA PUSAT", "3172": "KOTA ADM. JAKARTA UTARA", "3173": "KOTA ADM. JAKARTA BARAT", "3174": "KOTA ADM. JAKARTA SELATAN", "3175": "KOTA ADM. JAKARTA TIMUR", "3201": "KAB. BOGOR", "3202": "KAB. SUKABUMI", "3203": "KAB. CIANJUR", "3204": "KAB. BANDUNG", "3205": "KAB. GARUT", "3206": "KAB. TASIKMALAYA", "3207": "KAB. CIAMIS", "3208": "KAB. KUNINGAN", "3209": "KAB. CIREBON", "3210": "KAB. MAJALENGKA", "3211": "KAB. SUMEDANG", "3212": "KAB. INDRAMAYU", "3213": "KAB. SUBANG", "3214": "KAB. PURWAKARTA", "3215": "KAB. KARAWANG", "3216": "KAB. BEKASI", "3217": "KAB. BANDUNG BARAT", "3218": "KAB. PANGANDARAN", "3271": "KOTA BOGOR", "3272": "KOTA SUKABUMI", "3273": "KOTA BANDUNG", "3274": "KOTA CIREBON", "3275": "KOTA BEKASI", "3276": "KOTA DEPOK", "3277": "KOTA CIMAHI", "3278": "KOTA TASIKMALAYA", "3279": "KOTA BANJAR", "3301": "KAB. CILACAP", "3302": "KAB. BANYUMAS", "3303": "KAB. PURBALINGGA", "3304": "KAB. BANJARNEGARA", "3305": "KAB. KEBUMEN", "3306": "KAB. PURWOREJO", "3307": "KAB. WONOSOBO", "3308": "KAB. MAGELANG", "3309": "KAB. BOYOLALI", "3310": "KAB. KLATEN", "3311": "KAB. SUKOHARJO", "3312": "KAB. WONOGIRI", "3313": "KAB. KARANGANYAR", "3314": "KAB. SRAGEN", "3315": "KAB. GROBOGAN", "3316": "KAB. BLORA", "3317": "KAB. REMBANG", "3318": "KAB. PATI", "3319": "KAB. KUDUS", "3320": "KAB. JEPARA", "3321": "KAB. DEMAK", "3322": "KAB. SEMARANG", "3323": "KAB. TEMANGGUNG", "3324": "KAB. KENDAL", "3325": "KAB. BATANG", "3326": "KAB. PEKALONGAN", "3327": "KAB. PEMALANG", "3328": "KAB. TEGAL", "3329": "KAB. BREBES", "3371": "KOTA MAGELANG", "3372": "KOTA SURAKARTA", "3373": "KOTA SALATIGA", "3374": "KOTA SEMARANG", "3375": "KOTA PEKALONGAN", "3376": "KOTA TEGAL", "3401": "KAB. KULON PROGO", "3402": "KAB. BANTUL", "3403": "KAB. GUNUNG KIDUL", "3404": "KAB. SLEMAN", "3471": "KOTA YOGYAKARTA", "3501": "KAB. PACITAN", "3502": "KAB. PONOROGO", "3503": "KAB. TRENGGALEK", "3504": "KAB. TULUNGAGUNG", "3505": "KAB. BLITAR", "3506": "KAB. KEDIRI", "3507": "KAB. MALANG", "3508": "KAB. LUMAJANG", "3509": "KAB. JEMBER", "3510": "KAB. BANYUWANGI", "3511": "KAB. BONDOWOSO", "3512": "KAB. SITUBONDO", "3513": "KAB. PROBOLINGGO", "3514": "KAB. PASURUAN", "3515": "KAB. SIDOARJO", "3516": "KAB. MOJOKERTO", "3517": "KAB. JOMBANG", "3518": "KAB. NGANJUK", "3519": "KAB. MADIUN", "3520": "KAB. MAGETAN", "3521": "KAB. NGAWI", "3522": "KAB. BOJONEGORO", "3523": "KAB. TUBAN", "3524": "KAB. LAMONGAN", "3525": "KAB. GRESIK", "3526": "KAB. BANGKALAN", "3527": "KAB. SAMPANG", "3528": "KAB. PAMEKASAN", "3529": "KAB. SUMENEP", "3571": "KOTA KEDIRI", "3572": "KOTA BLITAR", "3573": "KOTA MALANG", "3574": "KOTA PROBOLINGGO", "3575": "KOTA PASURUAN", "3576": "KOTA MOJOKERTO", "3577": "KOTA MADIUN", "3578": "KOTA SURABAYA", "3579": "KOTA BATU", "3601": "KAB. PANDEGLANG", "3602": "KAB. LEBAK", "3603": "KAB. TANGERANG", "3604": "KAB. SERANG", "3671": "KOTA TANGERANG", "3672": "KOTA CILEGON", "3673": "KOTA SERANG", "3674": "KOTA TANGERANG SELATAN", "5101": "KAB. JEMBRANA", "5102": "KAB. TABANAN", "5103": "KAB. BADUNG", "5104": "KAB. GIANYAR", "5105": "KAB. KLUNGKUNG", "5106": "KAB. BANGLI", "5107": "KAB. KARANGASEM", "5108": "KAB. BULELENG", "5171": "KOTA DENPASAR", "5201": "KAB. LOMBOK BARAT", "5202": "KAB. LOMBOK TENGAH", "5203": "KAB. LOMBOK TIMUR", "5204": "KAB. SUMBAWA", "5205": "KAB. DOMPU", "5206": "KAB. BIMA", "5207": "KAB. SUMBAWA BARAT", "5208": "KAB. LOMBOK UTARA", "5271": "KOTA MATARAM", "5272": "KOTA BIMA", "5301": "KAB. KUPANG", "5302": "KAB TIMOR TENGAH SELATAN", "5303": "KAB. TIMOR TENGAH UTARA", "5304": "KAB. BELU", "5305": "KAB. ALOR", "5306": "KAB. FLORES TIMUR", "5307": "KAB. SIKKA", "5308": "KAB. ENDE", "5309": "KAB. NGADA", "5310": "KAB. MANGGARAI", "5311": "KAB. SUMBA TIMUR", "5312": "KAB. SUMBA BARAT", "5313": "KAB. LEMBATA", "5314": "KAB. ROTE NDAO", "5315": "KAB. MANGGARAI BARAT", "5316": "KAB. NAGEKEO", "5317": "KAB. SUMBA TENGAH", "5318": "KAB. SUMBA BARAT DAYA", "5319": "KAB. MANGGARAI TIMUR", "5320": "KAB. SABU RAIJUA", "5321": "KAB. MALAKA", "5371": "KOTA KUPANG", "6101": "KAB. SAMBAS", "6102": "KAB. MEMPAWAH", "6103": "KAB. SANGGAU", "6104": "KAB. KETAPANG", "6105": "KAB. SINTANG", "6106": "KAB. KAPUAS HULU", "6107": "KAB. BENGKAYANG", "6108": "KAB. LANDAK", "6109": "KAB. SEKADAU", "6110": "KAB. MELAWI", "6111": "KAB. KAYONG UTARA", "6112": "KAB. KUBU RAYA", "6171": "KOTA PONTIANAK", "6172": "KOTA SINGKAWANG", "6201": "KAB. KOTAWARINGIN BARAT", "6202": "KAB. KOTAWARINGIN TIMUR", "6203": "KAB. KAPUAS", "6204": "KAB. BARITO SELATAN", "6205": "KAB. BARITO UTARA", "6206": "KAB. KATINGAN", "6207": "KAB. SERUYAN", "6208": "KAB. SUKAMARA", "6209": "KAB. LAMANDAU", "6210": "KAB. GUNUNG MAS", "6211": "KAB. PULANG PISAU", "6212": "KAB. MURUNG RAYA", "6213": "KAB. BARITO TIMUR", "6271": "KOTA PALANGKARAYA", "6301": "KAB. TANAH LAUT", "6302": "KAB. KOTABARU", "6303": "KAB. BANJAR", "6304": "KAB. BARITO KUALA", "6305": "KAB. TAPIN", "6306": "KAB. HULU SUNGAI SELATAN", "6307": "KAB. HULU SUNGAI TENGAH", "6308": "KAB. HULU SUNGAI UTARA", "6309": "KAB. TABALONG", "6310": "KAB. TANAH BUMBU", "6311": "KAB. BALANGAN", "6371": "KOTA BANJARMASIN", "6372": "KOTA BANJARBARU", "6401": "KAB. PASER", "6402": "KAB. KUTAI KARTANEGARA", "6403": "KAB. BERAU", "6407": "KAB. KUTAI BARAT", "6408": "KAB. KUTAI TIMUR", "6409": "KAB. PENAJAM PASER UTARA", "6411": "KAB. MAHAKAM ULU", "6471": "KOTA BALIKPAPAN", "6472": "KOTA SAMARINDA", "6474": "KOTA BONTANG", "6501": "KAB. BULUNGAN", "6502": "KAB. MALINAU", "6503": "KAB. NUNUKAN", "6504": "KAB. TANA TIDUNG", "6571": "KOT. TARAKAN", "7101": "KAB. BOLAANG MONGONDOW", "7102": "KAB. MINAHASA", "7103": "KAB. KEPULAUAN SANGIHE", "7104": "KAB. KEPULAUAN TALAUD", "7105": "KAB. MINAHASA SELATAN", "7106": "KAB. MINAHASA UTARA", "7107": "KAB. MINAHASA TENGGARA", "7108": "KAB. BOLAANG MONGONDOW UT", "7109": "KAB. KEP. SIAU TAGULANDANG B", "7110": "KAB. BOLAANG MONGONDOW TI", "7111": "KAB. BOLAANG MONGONDOW SE", "7171": "KOTA MANADO", "7172": "KOTA BITUNG", "7173": "KOTA TOMOHON", "7174": "KOTA KOTAMOBAGU", "7201": "KAB. BANGGAI", "7202": "KAB. POSO", "7203": "KAB. DONGGALA", "7204": "KAB. TOLI TOLI", "7205": "KAB. BUOL", "7206": "KAB. MOROWALI", "7207": "KAB. BANGGAI KEPULAUAN", "7208": "KAB. PARIGI MOUTONG", "7209": "KAB. TOJO UNA UNA", "7210": "KAB. SIGI", "7211": "KAB. BANGGAI LAUT", "7212": "KAB. MOROWALI UTARA", "7271": "KOTA PALU", "7301": "KAB. KEPULAUAN SELAYAR", "7302": "KAB. BULUKUMBA", "7303": "KAB. BANTAENG", "7304": "KAB. JENEPONTO", "7305": "KAB. TAKALAR", "7306": "KAB. GOWA", "7307": "KAB. SINJAI", "7308": "KAB. BONE", "7309": "KAB. MAROS", "7310": "KAB. PANGKAJENE KEPULAUAN", "7311": "KAB. BARRU", "7312": "KAB. SOPPENG", "7313": "KAB. WAJO", "7314": "KAB. SIDENRENG RAPPANG", "7315": "KAB. PINRANG", "7316": "KAB. ENREKANG", "7317": "KAB. LUWU", "7318": "KAB. TANA TORAJA", "7322": "KAB. LUWU UTARA", "7324": "KAB. LUWU TIMUR", "7326": "KAB. TORAJA UTARA", "7371": "KOTA MAKASSAR", "7372": "KOTA PARE PARE", "7373": "KOTA PALOPO", "7401": "KAB. KOLAKA", "7402": "KAB. KONAWE", "7403": "KAB. MUNA", "7404": "KAB. BUTON", "7405": "KAB. KONAWE SELATAN", "7406": "KAB. BOMBANA", "7407": "KAB. WAKATOBI", "7408": "KAB. KOLAKA UTARA", "7409": "KAB. KONAWE UTARA", "7410": "KAB. BUTON UTARA", "7411": "KAB. KOLAKA TIMUR", "7412": "KAB. KONAWE KEPULAUAN", "7413": "KAB. MUNA BARAT", "7414": "KAB. BUTON TENGAH", "7415": "KAB. BUTON SELATAN", "7471": "KOTA KENDARI", "7472": "KOTA BAU BAU", "7501": "KAB. GORONTALO", "7502": "KAB. BOALEMO", "7503": "KAB. BONE BOLANGO", "7504": "KAB. PAHUWATO", "7505": "KAB. GORONTALO UTARA", "7571": "KOTA GORONTALO", "7601": "KAB. MAMUJU UTARA", "7602": "KAB. MAMUJU", "7603": "KAB. MAMASA", "7604": "KAB. POLEWALI MANDAR", "7605": "KAB. MAJENE", "7606": "KAB. MAMUJU TENGAH", "8101": "KAB. MALUKU TENGAH", "8102": "KAB. MALUKU TENGGARA", "8103": "KAB MALUKU TENGGARA BARAT", "8104": "KAB. BURU", "8105": "KAB. SERAM BAGIAN TIMUR", "8106": "KAB. SERAM BAGIAN BARAT", "8107": "KAB. KEPULAUAN ARU", "8108": "KAB. MALUKU BARAT DAYA", "8109": "KAB. BURU SELATAN", "8171": "KOTA AMBON", "8172": "KOTA TUAL", "8201": "KAB. HALMAHERA BARAT", "8202": "KAB. HALMAHERA TENGAH", "8203": "KAB. HALMAHERA UTARA", "8204": "KAB. HALMAHERA SELATAN", "8205": "KAB. KEPULAUAN SULA", "8206": "KAB. HALMAHERA TIMUR", "8207": "KAB. PULAU MOROTAI", "8208": "KAB. PULAU TALIABU", "8271": "KOTA TERNATE", "8272": "KOTA TIDORE KEPULAUAN", "9101": "KAB. MERAUKE", "9102": "KAB. JAYAWIJAYA", "9103": "KAB. JAYAPURA", "9104": "KAB. NABIRE", "9105": "KAB. KEPULAUAN YAPEN", "9106": "KAB. BIAK NUMFOR", "9107": "KAB. PUNCAK JAYA", "9108": "KAB. PANIAI", "9109": "KAB. MIMIKA", "9110": "KAB. SARMI", "9111": "KAB. KEEROM", "9112": "KAB PEGUNUNGAN BINTANG", "9113": "KAB. YAHUKIMO", "9114": "KAB. TOLIKARA", "9115": "KAB. WAROPEN", "9116": "KAB. BOVEN DIGOEL", "9117": "KAB. MAPPI", "9118": "KAB. ASMAT", "9119": "KAB. SUPIORI", "9120": "KAB. MAMBERAMO RAYA", "9121": "KAB. MAMBERAMO TENGAH", "9122": "KAB. YALIMO", "9123": "KAB. LANNY JAYA", "9124": "KAB. NDUGA", "9125": "KAB. PUNCAK", "9126": "KAB. DOGIYAI", "9127": "KAB. INTAN JAYA", "9128": "KAB. DEIYAI", "9171": "KOTA JAYAPURA", "9201": "KAB. SORONG", "9202": "KOT. MANOKWARI", "9203": "KAB. FAK FAK", "9204": "KAB. SORONG SELATAN", "9205": "KAB. RAJA AMPAT", "9206": "KAB. TELUK BINTUNI", "9207": "KAB. TELUK WONDAMA", "9208": "KAB. KAIMANA", "9209": "KAB. TAMBRAUW", "9210": "KAB. MAYBRAT", "9211": "KAB. MANOKWARI SELATAN", "9212": "KAB. PEGUNUNGAN ARFAK", "9271": "KOTA SORONG" }, "kecamatan": { "110101": "BAKONGAN -- 23773", "110102": "KLUET UTARA -- 23771", "110103": "KLUET SELATAN -- 23772", "110104": "LABUHAN HAJI -- 23761", "110105": "MEUKEK -- 23754", "110106": "SAMADUA -- 23752", "110107": "SAWANG -- 24377", "110108": "TAPAKTUAN -- 23711", "110109": "TRUMON -- 23774", "110110": "PASI RAJA -- 23755", "110111": "LABUHAN HAJI TIMUR -- 23758", "110112": "LABUHAN HAJI BARAT -- 23757", "110113": "KLUET TENGAH -- 23772", "110114": "KLUET TIMUR -- 23772", "110115": "BAKONGAN TIMUR -- 23773", "110116": "TRUMON TIMUR -- 23774", "110117": "KOTA BAHAGIA -- 23773", "110118": "TRUMON TENGAH -- 23774", "110201": "LAWE ALAS -- 24661", "110202": "LAWE SIGALA-GALA -- 24673", "110203": "BAMBEL -- 24671", "110204": "BABUSSALAM -- 24651", "110205": "BADAR -- 24652", "110206": "BABUL MAKMUR -- 24673", "110207": "DARUL HASANAH -- 24653", "110208": "LAWE BULAN -- 24651", "110209": "BUKIT TUSAM -- 24671", "110210": "SEMADAM -- 24678", "110211": "BABUL RAHMAH -- 24673", "110212": "KETAMBE -- 24652", "110213": "DELENG POKHKISEN -- 24660", "110214": "LAWE SUMUR -- 24671", "110215": "TANOH ALAS -- 24673", "110216": "LEUSER -- 24673", "110301": "DARUL AMAN -- 24455", "110302": "JULOK -- 24457", "110303": "IDI RAYEUK -- 24454", "110304": "BIREM BAYEUN -- 24452", "110305": "SERBAJADI -- 24461", "110306": "NURUSSALAM -- 24456", "110307": "PEUREULAK -- 24453", "110308": "RANTAU SELAMAT -- 24452", "110309": "SIMPANG ULIM -- 24458", "110310": "RANTAU PEUREULAK -- 24441", "110311": "PANTE BIDARI -- 24458", "110312": "MADAT -- 24458", "110313": "INDRA MAKMU -- 24457", "110314": "IDI TUNONG -- 24454", "110315": "BANDA ALAM -- 24458", "110316": "PEUDAWA -- 24454", "110317": "PEUREULAK TIMUR -- 24453", "110318": "PEUREULAK BARAT -- 24453", "110319": "SUNGAI RAYA -- 24458", "110320": "SIMPANG JERNIH -- 24458", "110321": "DARUL IHSAN -- 24468", "110322": "DARUL FALAH -- 24454", "110323": "IDI TIMUR -- 24456", "110324": "PEUNARON -- 24461", "110401": "LINGE -- 24563", "110402": "SILIH NARA -- 24562", "110403": "BEBESEN -- 24552", "110407": "PEGASING -- 24561", "110408": "BINTANG -- 24571", "110410": "KETOL -- 24562", "110411": "KEBAYAKAN -- 24519", "110412": "KUTE PANANG -- 24568", "110413": "CELALA -- 24562", "110417": "LAUT TAWAR -- 24511 - 24516", "110418": "ATU LINTANG -- 24563", "110419": "JAGONG JEGET -- 24563", "110420": "BIES -- 24561", "110421": "RUSIP ANTARA -- 24562", "110501": "JOHAN PAHWALAN -- 23617 - 23618", "110502": "KAWAY XVI -- 23681", "110503": "SUNGAI MAS -- 23681", "110504": "WOYLA -- 23682", "110505": "SAMATIGA -- 23652", "110506": "BUBON -- 23652", "110507": "ARONGAN LAMBALEK -- 23652", "110508": "PANTE CEUREUMEN -- 23681", "110509": "MEUREUBO -- 23615", "110510": "WOYLA BARAT -- 23682", "110511": "WOYLA TIMUR -- 23682", "110512": "PANTON REU -- 23681", "110601": "LHOONG -- 23354", "110602": "LHOKNGA -- 23353", "110603": "INDRAPURI -- 23363", "110604": "SEULIMEUM -- 23951", "110605": "MONTASIK -- 23362", "110606": "SUKAMAKMUR -- 23361", "110607": "DARUL IMARAH -- 23352", "110608": "PEUKAN BADA -- 23351", "110609": "MESJID RAYA -- 23381", "110610": "INGIN JAYA -- 23371", "110611": "KUTA BARO -- 23372", "110612": "DARUSSALAM -- 23373", "110613": "PULO ACEH -- 23391", "110614": "LEMBAH SEULAWAH -- 23952", "110615": "KOTA JANTHO -- 23917", "110616": "KOTA COT GLIE -- 23363", "110617": "KUTA MALAKA -- 23363", "110618": "SIMPANG TIGA -- 23371", "110619": "DARUL KAMAL -- 23352", "110620": "BAITUSSALAM -- 23373", "110621": "KRUENG BARONA JAYA -- 23371", "110622": "LEUPUNG -- 23353", "110623": "BLANG BINTANG -- 23360", "110703": "BATEE -- 24152", "110704": "DELIMA -- 24162", "110705": "GEUMPANG -- 24167", "110706": "GEULUMPANG TIGA -- 24183", "110707": "INDRA JAYA -- 23657", "110708": "KEMBANG TANJONG -- 24182", "110709": "KOTA SIGLI -- 24112", "110711": "MILA -- 24163", "110712": "MUARA TIGA -- 24153", "110713": "MUTIARA -- 24173", "110714": "PADANG TIJI -- 24161", "110715": "PEUKAN BARO -- 24172", "110716": "PIDIE -- 24151", "110717": "SAKTI -- 24164", "110718": "SIMPANG TIGA -- 23371", "110719": "TANGSE -- 24166", "110721": "TIRO/TRUSEB -- 24174", "110722": "KEUMALA -- 24165", "110724": "MUTIARA TIMUR -- 24173", "110725": "GRONG-GRONG -- 24150", "110727": "MANE -- 24186", "110729": "GLUMPANG BARO -- 24183", "110731": "TITEUE -- 24165", "110801": "BAKTIYA -- 24392", "110802": "DEWANTARA -- 24354", "110803": "KUTA MAKMUR -- 24371", "110804": "LHOKSUKON -- 24382", "110805": "MATANGKULI -- 24386", "110806": "MUARA BATU -- 24355", "110807": "MEURAH MULIA -- 24372", "110808": "SAMUDERA -- 24374", "110809": "SEUNUDDON -- 24393", "110810": "SYAMTALIRA ARON -- 24381", "110811": "SYAMTALIRA BAYU -- 24373", "110812": "TANAH LUAS -- 24385", "110813": "TANAH PASIR -- 24391", "110814": "T. JAMBO AYE -- 24395", "110815": "SAWANG -- 24377", "110816": "NISAM -- 24376", "110817": "COT GIREK -- 24352", "110818": "LANGKAHAN -- 24394", "110819": "BAKTIYA BARAT -- 24392", "110820": "PAYA BAKONG -- 24386", "110821": "NIBONG -- 24385", "110822": "SIMPANG KRAMAT -- 24313", "110823": "LAPANG -- 24391", "110824": "PIRAK TIMUR -- 24386", "110825": "GEUREDONG PASE -- 24373", "110826": "BANDA BARO -- 24376", "110827": "NISAM ANTARA -- 24376", "110901": "SIMEULUE TENGAH -- 23894", "110902": "SALANG -- 23893", "110903": "TEUPAH BARAT -- 23892", "110904": "SIMEULUE TIMUR -- 23891", "110905": "TELUK DALAM -- 23891", "110906": "SIMEULUE BARAT -- 23892", "110907": "TEUPAH SELATAN -- 23891", "110908": "ALAPAN -- 23893", "110909": "TEUPAH TENGAH -- 23891", "110910": "SIMEULUE CUT -- 23894", "111001": "PULAU BANYAK -- 24791", "111002": "SIMPANG KANAN -- 24783", "111004": "SINGKIL -- 24785", "111006": "GUNUNG MERIAH -- 24784", "111009": "KOTA BAHARU -- 24784", "111010": "SINGKIL UTARA -- 24785", "111011": "DANAU PARIS -- 24784", "111012": "SURO MAKMUR -- 24784", "111013": "SINGKOHOR -- 24784", "111014": "KUALA BARU -- 24784", "111016": "PULAU BANYAK BARAT -- 24791", "111101": "SAMALANGA -- 24264", "111102": "JEUNIEB -- 24263", "111103": "PEUDADA -- 24262", "111104": "JEUMPA -- 24251", "111105": "PEUSANGAN -- 24261", "111106": "MAKMUR -- 23662", "111107": "GANDAPURA -- 24356", "111108": "PANDRAH -- 24263", "111109": "JULI -- 24251", "111110": "JANGKA -- 24261", "111111": "SIMPANG MAMPLAM -- 24251", "111112": "PEULIMBANG -- 24263", "111113": "KOTA JUANG -- 24251", "111114": "KUALA -- 23661", "111115": "PEUSANGAN SIBLAH KRUENG -- 24261", "111116": "PEUSANGAN SELATAN -- 24261", "111117": "KUTA BLANG -- 24356", "111201": "BLANG PIDIE -- 23764", "111202": "TANGAN-TANGAN -- 23763", "111203": "MANGGENG -- 23762", "111204": "SUSOH -- 23765", "111205": "KUALA BATEE -- 23766", "111206": "BABAH ROT -- 23767", "111207": "SETIA -- 23763", "111208": "JEUMPA -- 24251", "111209": "LEMBAH SABIL -- 23762", "111301": "BLANGKEJEREN -- 24655", "111302": "KUTAPANJANG -- 24655", "111303": "RIKIT GAIB -- 24654", "111304": "TERANGUN -- 24656", "111305": "PINING -- 24655", "111306": "BLANGPEGAYON -- 24653", "111307": "PUTERI BETUNG -- 24658", "111308": "DABUN GELANG -- 24653", "111309": "BLANGJERANGO -- 24655", "111310": "TERIPE JAYA -- 24657", "111311": "PANTAN CUACA -- 24654", "111401": "TEUNOM -- 23653", "111402": "KRUENG SABEE -- 23654", "111403": "SETIA BHAKTI -- 23655", "111404": "SAMPOINIET -- 23656", "111405": "JAYA -- 23371", "111406": "PANGA -- 23653", "111407": "INDRA JAYA -- 23657", "111408": "DARUL HIKMAH -- 23656", "111409": "PASIE RAYA -- 23653", "111501": "KUALA -- 23661", "111502": "SEUNAGAN -- 23671", "111503": "SEUNAGAN TIMUR -- 23671", "111504": "BEUTONG -- 23672", "111505": "DARUL MAKMUR -- 23662", "111506": "SUKA MAKMUE -- 23671", "111507": "KUALA PESISIR -- 23661", "111508": "TADU RAYA -- 23661", "111509": "TRIPA MAKMUR -- 23662", "111510": "BEUTONG ATEUH BANGGALANG -- 23672", "111601": "MANYAK PAYED -- 24471", "111602": "BENDAHARA -- 24472", "111603": "KARANG BARU -- 24476", "111604": "SERUWAY -- 24473", "111605": "KOTA KUALASINPANG -- 24475", "111606": "KEJURUAN MUDA -- 24477", "111607": "TAMIANG HULU -- 24478", "111608": "RANTAU -- 24452", "111609": "BANDA MULIA -- 24472", "111610": "BANDAR PUSAKA -- 24478", "111611": "TENGGULUN -- 24477", "111612": "SEKERAK -- 24476", "111701": "PINTU RIME GAYO -- 24553", "111702": "PERMATA -- 24582", "111703": "SYIAH UTAMA -- 24582", "111704": "BANDAR -- 24184", "111705": "BUKIT -- 24671", "111706": "WIH PESAM -- 24581", "111707": "TIMANG GAJAH -- 24553", "111708": "BENER KELIPAH -- 24582", "111709": "MESIDAH -- 24582", "111710": "GAJAH PUTIH -- 24553", "111801": "MEUREUDU -- 24186", "111802": "ULIM -- 24458", "111803": "JANGKA BUAYA -- 24186", "111804": "BANDAR DUA -- 24188", "111805": "MEURAH DUA -- 24186", "111806": "BANDAR BARU -- 24184", "111807": "PANTERAJA -- 24185", "111808": "TRIENGGADENG -- 24185", "117101": "BAITURRAHMAN -- 23244", "117102": "KUTA ALAM -- 23126", "117103": "MEURAXA -- 23232", "117104": "SYIAH KUALA -- 23116", "117105": "LUENG BATA -- 23245", "117106": "KUTA RAJA -- 23128", "117107": "BANDA RAYA -- 23239", "117108": "JAYA BARU -- 23235", "117109": "ULEE KARENG -- 23117", "117201": "SUKAKARYA -- 23514", "117202": "SUKAJAYA -- 23524", "117301": "MUARA DUA -- 24352", "117302": "BANDA SAKTI -- 24351", "117303": "BLANG MANGAT -- 24375", "117304": "MUARA SATU -- 24352", "117401": "LANGSA TIMUR -- 24411", "117402": "LANGSA BARAT -- 24410", "117403": "LANGSA KOTA -- 24410", "117404": "LANGSA LAMA -- 24416", "117405": "LANGSA BARO -- 24415", "117501": "SIMPANG KIRI -- 24782", "117502": "PENANGGALAN -- 24782", "117503": "RUNDENG -- 24786", "117504": "SULTAN DAULAT -- 24782", "117505": "LONGKIB -- 24782", "120101": "BARUS -- 22564", "120102": "SORKAM -- 22563", "120103": "PANDAN -- 22613", "120104": "PINANGSORI -- 22654", "120105": "MANDUAMAS -- 22565", "120106": "KOLANG -- 22562", "120107": "TAPIAN NAULI -- 22618", "120108": "SIBABANGUN -- 22654", "120109": "SOSOR GADONG -- 22564", "120110": "SORKAM BARAT -- 22563", "120111": "SIRANDORUNG -- 22565", "120112": "ANDAM DEWI -- 22651", "120113": "SITAHUIS -- 22611", "120114": "TUKKA -- 22617", "120115": "BADIRI -- 22654", "120116": "PASARIBU TOBING -- 22563", "120117": "BARUS UTARA -- 22564", "120118": "SUKA BANGUN -- 22654", "120119": "LUMUT -- 22654", "120120": "SARUDIK -- 22611", "120201": "TARUTUNG -- 22413", "120202": "SIATAS BARITA -- 22417", "120203": "ADIAN KOTING -- 22461", "120204": "SIPOHOLON -- 22452", "120205": "PAHAE JULU -- 22463", "120206": "PAHAE JAE -- 22465", "120207": "SIMANGUMBAN -- 22466", "120208": "PURBA TUA -- 22465", "120209": "SIBORONG-BORONG -- 22474", "120210": "PAGARAN -- 22458", "120211": "PARMONANGAN -- 22453", "120212": "SIPAHUTAR -- 22471", "120213": "PANGARIBUAN -- 22472", "120214": "GAROGA -- 22473", "120215": "MUARA -- 22476", "120301": "ANGKOLA BARAT -- 22735", "120302": "BATANG TORU -- 22738", "120303": "ANGKOLA TIMUR -- 22733", "120304": "SIPIROK -- 22742", "120305": "SAIPAR DOLOK HOLE -- 22758", "120306": "ANGKOLA SELATAN -- 22732", "120307": "BATANG ANGKOLA -- 22773", "120314": "ARSE -- 21126", "120320": "MARANCAR -- 22738", "120321": "SAYUR MATINGGI -- 22774", "120322": "AEK BILAH -- 22758", "120329": "MUARA BATANG TORU -- 22738", "120330": "TANO TOMBANGAN ANGKOLA -- 22774", "120331": "ANGKOLA SANGKUNUR -- 22735", "120405": "HILIDUHO -- 22854", "120406": "GIDO -- 22871", "120410": "IDANOGAWO -- 22872", "120411": "BAWOLATO -- 22876", "120420": "HILISERANGKAI -- 22851", "120421": "BOTOMUZOI -- 22815", "120427": "ULUGAWO -- 22861", "120428": "MA'U -- -", "120429": "SOMOLO-MOLO -- 22871", "120435": "SOGAE'ADU -- -", "120501": "BAHOROK -- 20774", "120502": "SALAPIAN -- 20773", "120503": "KUALA -- 21475", "120504": "SEI BINGEI -- -", "120505": "BINJAI -- 20719", "120506": "SELESAI -- 20762", "120507": "STABAT -- 20811", "120508": "WAMPU -- 20851", "120509": "SECANGGANG -- 20855", "120510": "HINAI -- 20854", "120511": "TANJUNG PURA -- 20853", "120512": "PADANG TUALANG -- 20852", "120513": "GEBANG -- 20856", "120514": "BABALAN -- 20857", "120515": "PANGKALAN SUSU -- 20858", "120516": "BESITANG -- 20859", "120517": "SEI LEPAN -- 20773", "120518": "BRANDAN BARAT -- 20881", "120519": "BATANG SERANGAN -- 20852", "120520": "SAWIT SEBERANG -- 20811", "120521": "SIRAPIT -- 20772", "120522": "KUTAMBARU -- 20773", "120523": "PEMATANG JAYA -- 20858", "120601": "KABANJAHE -- 22111", "120602": "BERASTAGI -- 22152", "120603": "BARUSJAHE -- 22172", "120604": "TIGAPANAH -- 22171", "120605": "MEREK -- 22173", "120606": "MUNTE -- 22755", "120607": "JUHAR -- 22163", "120608": "TIGABINANGA -- 22162", "120609": "LAUBALENG -- 22164", "120610": "MARDINGDING -- -", "120611": "PAYUNG -- 22154", "120612": "SIMPANG EMPAT -- 21271", "120613": "KUTABULUH -- 22155", "120614": "DOLAT RAYAT -- 22171", "120615": "MERDEKA -- 22153", "120616": "NAMAN TERAN -- -", "120617": "TIGANDERKET -- 22154", "120701": "GUNUNG MERIAH -- 20583", "120702": "TANJUNG MORAWA -- 20362", "120703": "SIBOLANGIT -- 20357", "120704": "KUTALIMBARU -- 20354", "120705": "PANCUR BATU -- 20353", "120706": "NAMORAMBE -- 20356", "120707": "SIBIRU-BIRU -- -", "120708": "STM HILIR -- -", "120709": "BANGUN PURBA -- 20581", "120719": "GALANG -- 20585", "120720": "STM HULU -- -", "120721": "PATUMBAK -- 20361", "120722": "DELI TUA -- 20355", "120723": "SUNGGAL -- 20121", "120724": "HAMPARAN PERAK -- 20374", "120725": "LABUHAN DELI -- 20373", "120726": "PERCUT SEI TUAN -- 20371", "120727": "BATANG KUIS -- 20372", "120728": "LUBUK PAKAM -- 20511", "120731": "PAGAR MERBAU -- 20551", "120732": "PANTAI LABU -- 20553", "120733": "BERINGIN -- 20552", "120801": "SIANTAR -- 21126", "120802": "GUNUNG MALELA -- 21174", "120803": "GUNUNG MALIGAS -- 21174", "120804": "PANEI -- 21161", "120805": "PANOMBEIAN PANE -- 21165", "120806": "JORLANG HATARAN -- 21172", "120807": "RAYA KAHEAN -- 21156", "120808": "BOSAR MALIGAS -- 21183", "120809": "SIDAMANIK -- 21171", "120810": "PEMATANG SIDAMANIK -- 21186", "120811": "TANAH JAWA -- 21181", "120812": "HATONDUHAN -- 21174", "120813": "DOLOK PANRIBUAN -- 21173", "120814": "PURBA -- 20581", "120815": "HARANGGAOL HORISON -- 21174", "120816": "GIRSANG SIPANGAN BOLON -- 21174", "120817": "DOLOK BATU NANGGAR -- 21155", "120818": "HUTA BAYU RAJA -- 21182", "120819": "JAWA MARAJA BAH JAMBI -- 21153", "120820": "DOLOK PARDAMEAN -- 21163", "120821": "PEMATANG BANDAR -- 21186", "120822": "BANDAR HULUAN -- 21184", "120823": "BANDAR -- 21274", "120824": "BANDAR MASILAM -- 21184", "120825": "SILIMAKUTA -- 21167", "120826": "DOLOK SILAU -- 21168", "120827": "SILOU KAHEAN -- 21157", "120828": "TAPIAN DOLOK -- 21154", "120829": "RAYA -- 22866", "120830": "UJUNG PADANG -- 21187", "120831": "PAMATANG SILIMA HUTA -- -", "120908": "MERANTI -- 21264", "120909": "AIR JOMAN -- 21263", "120910": "TANJUNG BALAI -- 21352", "120911": "SEI KEPAYANG -- 21381", "120912": "SIMPANG EMPAT -- 21271", "120913": "AIR BATU -- 21272", "120914": "PULAU RAKYAT -- 21273", "120915": "BANDAR PULAU -- 21274", "120916": "BUNTU PANE -- 21261", "120917": "BANDAR PASIR MANDOGE -- 21262", "120918": "AEK KUASAN -- 21273", "120919": "KOTA KISARAN BARAT -- -", "120920": "KOTA KISARAN TIMUR -- -", "120921": "AEK SONGSONGAN -- 21274", "120922": "RAHUNIG -- -", "120923": "SEI DADAP -- 21272", "120924": "SEI KEPAYANG BARAT -- 21381", "120925": "SEI KEPAYANG TIMUR -- 21381", "120926": "TINGGI RAJA -- 21261", "120927": "SETIA JANJI -- 21261", "120928": "SILAU LAUT -- 21263", "120929": "RAWANG PANCA ARGA -- 21264", "120930": "PULO BANDRING -- 21264", "120931": "TELUK DALAM -- 21271", "120932": "AEK LEDONG -- 21273", "121001": "RANTAU UTARA -- 21419", "121002": "RANTAU SELATAN -- 21421", "121007": "BILAH BARAT -- 21411", "121008": "BILAH HILIR -- 21471", "121009": "BILAH HULU -- 21451", "121014": "PANGKATAN -- 21462", "121018": "PANAI TENGAH -- 21472", "121019": "PANAI HILIR -- 21473", "121020": "PANAI HULU -- 21471", "121101": "SIDIKALANG -- 22212", "121102": "SUMBUL -- 22281", "121103": "TIGALINGGA -- 22252", "121104": "SIEMPAT NEMPU -- 22261", "121105": "SILIMA PUNGGA PUNGA -- -", "121106": "TANAH PINEM -- 22253", "121107": "SIEMPAT NEMPU HULU -- 22254", "121108": "SIEMPAT NEMPU HILIR -- 22263", "121109": "PEGAGAN HILIR -- 22283", "121110": "PARBULUAN -- 22282", "121111": "LAE PARIRA -- 22281", "121112": "GUNUNG SITEMBER -- 22251", "121113": "BRAMPU -- 22251", "121114": "SILAHISABUNGAN -- 22281", "121115": "SITINJO -- 22219", "121201": "BALIGE -- 22312", "121202": "LAGUBOTI -- 22381", "121203": "SILAEN -- 22382", "121204": "HABINSARAN -- 22383", "121205": "PINTU POHAN MERANTI -- 22384", "121206": "BORBOR -- -", "121207": "PORSEA -- 22384", "121208": "AJIBATA -- 22386", "121209": "LUMBAN JULU -- 22386", "121210": "ULUAN -- 21184", "121219": "SIGUMPAR -- 22381", "121220": "SIANTAR NARUMONDA -- 22384", "121221": "NASSAU -- 22383", "121222": "TAMPAHAN -- 22312", "121223": "BONATUA LUNASI -- 22386", "121224": "PARMAKSIAN -- 22384", "121301": "PANYABUNGAN -- 22912", "121302": "PANYABUNGAN UTARA -- 22978", "121303": "PANYABUNGAN TIMUR -- 22912", "121304": "PANYABUNGAN SELATAN -- 22952", "121305": "PANYABUNGAN BARAT -- 22911", "121306": "SIABU -- 22976", "121307": "BUKIT MALINTANG -- 22977", "121308": "KOTANOPAN -- 22994", "121309": "LEMBAH SORIK MARAPI -- -", "121310": "TAMBANGAN -- 22994", "121311": "ULU PUNGKUT -- 22998", "121312": "MUARA SIPONGI -- 22998", "121313": "BATANG NATAL -- 22983", "121314": "LINGGA BAYU -- 22983", "121315": "BATAHAN -- 22988", "121316": "NATAL -- 22983", "121317": "MUARA BATANG GADIS -- 22989", "121318": "RANTO BAEK -- 22983", "121319": "HUTA BARGOT -- 22978", "121320": "PUNCAK SORIK MARAPI -- 22994", "121321": "PAKANTAN -- 22998", "121322": "SINUNUKAN -- 22988", "121323": "NAGA JUANG -- 22977", "121401": "LOLOMATUA -- 22867", "121402": "GOMO -- 22873", "121403": "LAHUSA -- 22874", "121404": "HIBALA -- 22881", "121405": "PULAU-PULAU BATU -- 22881", "121406": "TELUK DALAM -- 21271", "121407": "AMANDRAYA -- 22866", "121408": "LALOWA'U -- -", "121409": "SUSUA -- 22866", "121410": "MANIAMOLO -- 22865", "121411": "HILIMEGAI -- 22864", "121412": "TOMA -- 22865", "121413": "MAZINO -- 22865", "121414": "UMBUNASI -- 22873", "121415": "ARAMO -- 22866", "121416": "PULAU-PULAU BATU TIMUR -- 22881", "121417": "MAZO -- 22873", "121418": "FANAYAMA -- 22865", "121419": "ULUNOYO -- 22867", "121420": "HURUNA -- 22867", "121421": "O'O'U -- -", "121422": "ONOHAZUMBA -- 22864", "121423": "HILISALAWA'AHE -- -", "121425": "SIDUA'ORI -- -", "121426": "SOMAMBAWA -- 22874", "121427": "BORONADU -- 22873", "121428": "SIMUK -- 22881", "121429": "PULAU-PULAU BATU BARAT -- 22881", "121430": "PULAU-PULAU BATU UTARA -- 22881", "121501": "SITELU TALI URANG JEHE -- -", "121502": "KERAJAAN -- 22271", "121503": "SALAK -- 22272", "121504": "SITELU TALI URANG JULU -- -", "121505": "PERGETTENG GETTENG SENGKUT -- 22271", "121506": "PAGINDAR -- 22271", "121507": "TINADA -- 22272", "121508": "SIEMPAT RUBE -- 22272", "121601": "PARLILITAN -- 22456", "121602": "POLLUNG -- 22457", "121603": "BAKTIRAJA -- 22457", "121604": "PARANGINAN -- 22475", "121605": "LINTONG NIHUTA -- 22475", "121606": "DOLOK SANGGUL -- 22457", "121607": "SIJAMAPOLANG -- 22457", "121608": "ONAN GANJANG -- 22454", "121609": "PAKKAT -- 22455", "121610": "TARABINTANG -- 22456", "121701": "SIMANINDO -- 22395", "121702": "ONAN RUNGGU -- 22391", "121703": "NAINGGOLAN -- 22394", "121704": "PALIPI -- 22393", "121705": "HARIAN -- 22391", "121706": "SIANJAR MULA MULA -- -", "121707": "RONGGUR NIHUTA -- 22392", "121708": "PANGURURAN -- 22392", "121709": "SITIO-TIO -- 22395", "121801": "PANTAI CERMIN -- 20987", "121802": "PERBAUNGAN -- 20986", "121803": "TELUK MENGKUDU -- 20997", "121804": "SEI. RAMPAH -- -", "121805": "TANJUNG BERINGIN -- 20996", "121806": "BANDAR KHALIFAH -- 20994", "121807": "DOLOK MERAWAN -- 20993", "121808": "SIPISPIS -- 20992", "121809": "DOLOK MASIHUL -- 20991", "121810": "KOTARIH -- 20984", "121811": "SILINDA -- 20984", "121812": "SERBA JADI -- 20991", "121813": "TEBING TINGGI -- 20615", "121814": "PEGAJAHAN -- 20986", "121815": "SEI BAMBAN -- 20995", "121816": "TEBING SYAHBANDAR -- 20998", "121817": "BINTANG BAYU -- 20984", "121901": "MEDANG DERAS -- 21258", "121902": "SEI SUKA -- 21257", "121903": "AIR PUTIH -- 21256", "121904": "LIMA PULUH -- 21255", "121905": "TALAWI -- 21254", "121906": "TANJUNG TIRAM -- 21253", "121907": "SEI BALAI -- 21252", "122001": "DOLOK SIGOMPULON -- 22756", "122002": "DOLOK -- 22756", "122003": "HALONGONAN -- 22753", "122004": "PADANG BOLAK -- 22753", "122005": "PADANG BOLAK JULU -- 22753", "122006": "PORTIBI -- 22741", "122007": "BATANG ONANG -- 22762", "122008": "SIMANGAMBAT -- 22747", "122009": "HULU SIHAPAS -- 22733", "122101": "SOSOPAN -- 22762", "122102": "BARUMUN TENGAH -- 22755", "122103": "HURISTAK -- 22742", "122104": "LUBUK BARUMUN -- 22763", "122105": "HUTA RAJA TINGGI -- 22774", "122106": "ULU BARUMUN -- 22763", "122107": "BARUMUN -- 22755", "122108": "SOSA -- 22765", "122109": "BATANG LUBU SUTAM -- 22742", "122110": "BARUMUN SELATAN -- 22763", "122111": "AEK NABARA BARUMUN -- 22755", "122112": "SIHAPAS BARUMUN -- 22755", "122201": "KOTAPINANG -- 21464", "122202": "KAMPUNG RAKYAT -- 21463", "122203": "TORGAMBA -- 21464", "122204": "SUNGAI KANAN -- 21465", "122205": "SILANGKITANG -- 21461", "122301": "KUALUH HULU -- 21457", "122302": "KUALUH LEIDONG -- 21475", "122303": "KUALUH HILIR -- 21474", "122304": "AEK KUO -- 21455", "122305": "MARBAU -- 21452", "122306": "NA IX - X -- 21454", "122307": "AEK NATAS -- 21455", "122308": "KUALUH SELATAN -- 21457", "122401": "LOTU -- 22851", "122402": "SAWO -- 22852", "122403": "TUHEMBERUA -- 22852", "122404": "SITOLU ORI -- 22852", "122405": "NAMOHALU ESIWA -- 22816", "122406": "ALASA TALUMUZOI -- 22814", "122407": "ALASA -- 22861", "122408": "TUGALA OYO -- 22861", "122409": "AFULU -- 22857", "122410": "LAHEWA -- 22853", "122411": "LAHEWA TIMUR -- 22851", "122501": "LAHOMI -- 22864", "122502": "SIROMBU -- 22863", "122503": "MANDREHE BARAT -- 22812", "122504": "MORO'O -- -", "122505": "MANDREHE -- 22814", "122506": "MANDREHE UTARA -- 22814", "122507": "LOLOFITU MOI -- 22875", "122508": "ULU MORO'O -- -", "127101": "MEDAN KOTA -- 20215", "127102": "MEDAN SUNGGAL -- 20121", "127103": "MEDAN HELVETIA -- 20126", "127104": "MEDAN DENAI -- 20228", "127105": "MEDAN BARAT -- 20115", "127106": "MEDAN DELI -- 20243", "127107": "MEDAN TUNTUNGAN -- 20136", "127108": "MEDAN BELAWAN -- 20414", "127109": "MEDAN AMPLAS -- 20229", "127110": "MEDAN AREA -- 20215", "127111": "MEDAN JOHOR -- 20144", "127112": "MEDAN MARELAN -- 20254", "127113": "MEDAN LABUHAN -- 20251", "127114": "MEDAN TEMBUNG -- 20223", "127115": "MEDAN MAIMUN -- 20151", "127116": "MEDAN POLONIA -- 20152", "127117": "MEDAN BARU -- 20154", "127118": "MEDAN PERJUANGAN -- 20233", "127119": "MEDAN PETISAH -- 20112", "127120": "MEDAN TIMUR -- 20235", "127121": "MEDAN SELAYANG -- 20133", "127201": "SIANTAR TIMUR -- 21136", "127202": "SIANTAR BARAT -- 21112", "127203": "SIANTAR UTARA -- 21142", "127204": "SIANTAR SELATAN -- 21126", "127205": "SIANTAR MARIHAT -- 21129", "127206": "SIANTAR MARTOBA -- 21137", "127207": "SIANTAR SITALASARI -- 21139", "127208": "SIANTAR MARIMBUN -- 21128", "127301": "SIBOLGA UTARA -- 22511", "127302": "SIBOLGA KOTA -- 22521", "127303": "SIBOLGA SELATAN -- 22533", "127304": "SIBOLGA SAMBAS -- 22535", "127401": "TANJUNG BALAI SELATAN -- 21315", "127402": "TANJUNG BALAI UTARA -- 21324", "127403": "SEI TUALANG RASO -- 21344", "127404": "TELUK NIBUNG -- 21335", "127405": "DATUK BANDAR -- 21367", "127406": "DATUK BANDAR TIMUR -- 21367", "127501": "BINJAI UTARA -- 20747", "127502": "BINJAI KOTA -- 20715", "127503": "BINJAI BARAT -- 20719", "127504": "BINJAI TIMUR -- 20736", "127505": "BINJAI SELATAN -- 20728", "127601": "PADANG HULU -- 20625", "127602": "RAMBUTAN -- 20611", "127603": "PADANG HILIR -- 20634", "127604": "BAJENIS -- 20613", "127605": "TEBING TINGGI KOTA -- 20615", "127701": "PADANGSIDIMPUAN UTARA -- -", "127702": "PADANGSIDIMPUAN SELATAN -- -", "127703": "PADANGSIDIMPUAN BATUNADUA -- -", "127704": "PADANGSIDIMPUAN HUTAIMBARU -- -", "127705": "PADANGSIDIMPUAN TENGGARA -- -", "127706": "PADANGSIDIMPUAN ANGKOLA JULU -- -", "130101": "PANCUNG SOAL -- 25673", "130102": "RANAH PESISIR -- 25666", "130103": "LENGAYANG -- 25663", "130104": "BATANG KAPAS -- 25661", "130105": "IV JURAI -- 25651", "130106": "BAYANG -- 25652", "130107": "KOTO XI TARUSAN -- 25654", "130108": "SUTERA -- 25662", "130109": "LINGGO SARI BAGANTI -- 25668", "130111": "BASA AMPEK BALAI TAPAN -- 25673", "130112": "IV NAGARI BAYANG UTARA -- 25652", "130113": "AIRPURA -- 25673", "130114": "RANAH AMPEK HULU TAPAN -- 25673", "130115": "SILAUT -- 25674", "130203": "PANTAI CERMIN -- 27373", "130204": "LEMBAH GUMANTI -- 27371", "130205": "PAYUNG SEKAKI -- 27387", "130206": "LEMBANG JAYA -- 27383", "130207": "GUNUNG TALANG -- 27365", "130208": "BUKIT SUNDI -- 27381", "130209": "IX KOTO SUNGAI LASI -- -", "130210": "KUBUNG -- 27361", "130211": "X KOTO SINGKARAK -- 27356", "130212": "X KOTO DIATAS -- 27355", "130213": "JUNJUNG SIRIH -- 27388", "130217": "HILIRAN GUMANTI -- 27372", "130218": "TIGO LURAH -- 27372", "130219": "DANAU KEMBAR -- 27383", "130303": "TANJUNG GADANG -- 27571", "130304": "SIJUNJUNG -- 27553", "130305": "IV NAGARI -- 26161", "130306": "KAMANG BARU -- 27572", "130307": "LUBUAK TAROK -- 27553", "130308": "KOTO VII -- 27562", "130309": "SUMPUR KUDUS -- 27563", "130310": "KUPITAN -- 27564", "130401": "X KOTO -- 27151", "130402": "BATIPUH -- 27265", "130403": "RAMBATAN -- 27271", "130404": "LIMA KAUM -- 27213", "130405": "TANJUNG EMAS -- 27281", "130406": "LINTAU BUO -- 27292", "130407": "SUNGAYANG -- 27294", "130408": "SUNGAI TARAB -- 27261", "130409": "PARIANGAN -- 27264", "130410": "SALIMPAUANG -- -", "130411": "PADANG GANTING -- 27282", "130412": "TANJUANG BARU -- -", "130413": "LINTAU BUO UTARA -- 27292", "130414": "BATIPUAH SELATAN -- -", "130501": "LUBUK ALUNG -- 25581", "130502": "BATANG ANAI -- 25586", "130503": "NAN SABARIS -- 25571", "130505": "VII KOTO SUNGAI SARIK -- 25573", "130506": "V KOTO KAMPUNG DALAM -- 25552", "130507": "SUNGAI GARINGGING -- -", "130508": "SUNGAI LIMAU -- 25561", "130509": "IV KOTO AUR MALINTANG -- 25564", "130510": "ULAKAN TAPAKIH -- 25572", "130511": "SINTUAK TOBOH GADANG -- 25582", "130512": "PADANG SAGO -- 25573", "130513": "BATANG GASAN -- 25563", "130514": "V KOTO TIMUR -- 25573", "130516": "PATAMUAN -- 25573", "130517": "ENAM LINGKUNG -- 25584", "130601": "TANJUNG MUTIARA -- 26473", "130602": "LUBUK BASUNG -- 26451", "130603": "TANJUNG RAYA -- 26471", "130604": "MATUR -- 26162", "130605": "IV KOTO -- 25564", "130606": "BANUHAMPU -- 26181", "130607": "AMPEK ANGKEK -- 26191", "130608": "BASO -- 26192", "130609": "TILATANG KAMANG -- 26152", "130610": "PALUPUH -- 26151", "130611": "PELEMBAYAN -- -", "130612": "SUNGAI PUA -- 26181", "130613": "AMPEK NAGARI -- 26161", "130614": "CANDUNG -- 26191", "130615": "KAMANG MAGEK -- 26152", "130616": "MALALAK -- -", "130701": "SULIKI -- 26255", "130702": "GUGUAK -- 26111", "130703": "PAYAKUMBUH -- 26228", "130704": "LUAK -- 26261", "130705": "HARAU -- 26271", "130706": "PANGKALAN KOTO BARU -- 26272", "130707": "KAPUR IX -- 26273", "130708": "GUNUANG OMEH -- 26256", "130709": "LAREH SAGO HALABAN -- 26262", "130710": "SITUJUAH LIMO NAGARI -- -", "130711": "MUNGKA -- 26254", "130712": "BUKIK BARISAN -- 26257", "130713": "AKABILURU -- 26252", "130804": "BONJOL -- 26381", "130805": "LUBUK SIKAPING -- 26318", "130807": "PANTI -- 26352", "130808": "MAPAT TUNGGUL -- 26353", "130812": "DUO KOTO -- 26311", "130813": "TIGO NAGARI -- 26353", "130814": "RAO -- 26353", "130815": "MAPAT TUNGGUL SELATAN -- 26353", "130816": "SIMPANG ALAHAN MATI -- 26381", "130817": "PADANG GELUGUR -- 26352", "130818": "RAO UTARA -- 26353", "130819": "RAO SELATAN -- 26353", "130901": "PAGAI UTARA -- 25391", "130902": "SIPORA SELATAN -- 25392", "130903": "SIBERUT SELATAN -- 25393", "130904": "SIBERUT UTARA -- 25394", "130905": "SIBERUT BARAT -- 25393", "130906": "SIBERUT BARAT DAYA -- 25393", "130907": "SIBERUT TENGAH -- 25394", "130908": "SIPORA UTARA -- 25392", "130909": "SIKAKAP -- 25391", "130910": "PAGAI SELATAN -- 25391", "131001": "KOTO BARU -- 27681", "131002": "PULAU PUNJUNG -- 27573", "131003": "SUNGAI RUMBAI -- 27684", "131004": "SITIUNG -- 27678", "131005": "SEMBILAN KOTO -- 27681", "131006": "TIMPEH -- 27678", "131007": "KOTO SALAK -- 27681", "131008": "TIUMANG -- 27681", "131009": "PADANG LAWEH -- 27681", "131010": "ASAM JUJUHAN -- 27684", "131011": "KOTO BESAR -- 27684", "131101": "SANGIR -- 27779", "131102": "SUNGAI PAGU -- 27776", "131103": "KOTO PARIK GADANG DIATEH -- 27775", "131104": "SANGIR JUJUAN -- 27777", "131105": "SANGIR BATANG HARI -- 27779", "131106": "PAUH DUO -- 27776", "131107": "SANGIR BALAI JANGGO -- 27777", "131201": "SUNGAIBEREMAS -- -", "131202": "LEMBAH MELINTANG -- 26572", "131203": "PASAMAN -- 26566", "131204": "TALAMAU -- 26561", "131205": "KINALI -- 26567", "131206": "GUNUNGTULEH -- 26571", "131207": "RANAH BATAHAN -- 26366", "131208": "KOTO BALINGKA -- 26572", "131209": "SUNGAIAUR -- 26573", "131210": "LUHAK NAN DUO -- 26567", "131211": "SASAK RANAH PESISIR -- -", "137101": "PADANG SELATAN -- 25217", "137102": "PADANG TIMUR -- 25126", "137103": "PADANG BARAT -- 25118", "137104": "PADANG UTARA -- 25132", "137105": "BUNGUS TELUK KABUNG -- 25237", "137106": "LUBUK BEGALUNG -- 25222", "137107": "LUBUK KILANGAN -- 25231", "137108": "PAUH -- 27776", "137109": "KURANJI -- 25154", "137110": "NANGGALO -- 25145", "137111": "KOTO TANGAH -- 25176", "137201": "LUBUK SIKARAH -- 27317", "137202": "TANJUNG HARAPAN -- 27321", "137301": "LEMBAH SEGAR -- 27418", "137302": "BARANGIN -- 27422", "137303": "SILUNGKANG -- 27435", "137304": "TALAWI -- 27443", "137401": "PADANG PANJANG TIMUR -- 27125", "137402": "PADANG PANJANG BARAT -- 27114", "137501": "GUGUAK PANJANG -- 26111", "137502": "MANDIANGIN K. SELAYAN -- -", "137503": "AUR BIRUGO TIGO BALEH -- 26131", "137601": "PAYAKUMBUH BARAT -- 26224", "137602": "PAYAKUMBUH UTARA -- 26212", "137603": "PAYAKUMBUH TIMUR -- 26231", "137604": "LAMPOSI TIGO NAGORI -- -", "137605": "PAYAKUMBUH SELATAN -- 26228", "137701": "PARIAMAN TENGAH -- 25519", "137702": "PARIAMAN UTARA -- 25522", "137703": "PARIAMAN SELATAN -- 25531", "137704": "PARIAMAN TIMUR -- 25531", "140101": "BANGKINANG KOTA -- -", "140102": "KAMPAR -- 28461", "140103": "TAMBANG -- 28462", "140104": "XIII KOTO KAMPAR -- 28453", "140106": "SIAK HULU -- 28452", "140107": "KAMPAR KIRI -- 28471", "140108": "KAMPAR KIRI HILIR -- 28471", "140109": "KAMPAR KIRI HULU -- 28471", "140110": "TAPUNG -- 28464", "140111": "TAPUNG HILIR -- 28464", "140112": "TAPUNG HULU -- 28464", "140113": "SALO -- 28451", "140114": "RUMBIO JAYA -- 28458", "140116": "PERHENTIAN RAJA -- 28462", "140117": "KAMPAR TIMUR -- 28461", "140118": "KAMPAR UTARA -- 28461", "140119": "KAMPAR KIRI TENGAH -- 28471", "140120": "GUNUNG SAHILAN -- 28471", "140121": "KOTO KAMPAR HULU -- 28453", "140201": "RENGAT -- 29351", "140202": "RENGAT BARAT -- 29351", "140203": "KELAYANG -- 29352", "140204": "PASIR PENYU -- 29352", "140205": "PERANAP -- 29354", "140206": "SIBERIDA -- -", "140207": "BATANG CENAKU -- 29355", "140208": "BATANG GANGSAL -- -", "140209": "LIRIK -- 29353", "140210": "KUALA CENAKU -- 29335", "140211": "SUNGAI LALA -- 29363", "140212": "LUBUK BATU JAYA -- 29352", "140213": "RAKIT KULIM -- 29352", "140214": "BATANG PERANAP -- 29354", "140301": "BENGKALIS -- 28711", "140302": "BANTAN -- 28754", "140303": "BUKIT BATU -- 28761", "140309": "MANDAU -- 28784", "140310": "RUPAT -- 28781", "140311": "RUPAT UTARA -- 28781", "140312": "SIAK KECIL -- 28771", "140313": "PINGGIR -- 28784", "140401": "RETEH -- 29273", "140402": "ENOK -- 29272", "140403": "KUALA INDRAGIRI -- 29281", "140404": "TEMBILAHAN -- 29212", "140405": "TEMPULING -- 29261", "140406": "GAUNG ANAK SERKA -- 29253", "140407": "MANDAH -- 29254", "140408": "KATEMAN -- 29255", "140409": "KERITANG -- 29274", "140410": "TANAH MERAH -- 29271", "140411": "BATANG TUAKA -- 29252", "140412": "GAUNG -- 29282", "140413": "TEMBILAHAN HULU -- 29213", "140414": "KEMUNING -- 29274", "140415": "PELANGIRAN -- 29255", "140416": "TELUK BELENGKONG -- 29255", "140417": "PULAU BURUNG -- 29256", "140418": "CONCONG -- 29281", "140419": "KEMPAS -- 29261", "140420": "SUNGAI BATANG -- 29273", "140501": "UKUI -- 28382", "140502": "PANGKALAN KERINCI -- 28381", "140503": "PANGKALAN KURAS -- 28382", "140504": "PANGKALAN LESUNG -- 28382", "140505": "LANGGAM -- 28381", "140506": "PELALAWAN -- 28353", "140507": "KERUMUTAN -- 28353", "140508": "BUNUT -- 28383", "140509": "TELUK MERANTI -- 28353", "140510": "KUALA KAMPAR -- 28384", "140511": "BANDAR SEI KIJANG -- 28383", "140512": "BANDAR PETALANGAN -- 28384", "140601": "UJUNG BATU -- 28554", "140602": "ROKAN IV KOTO -- 28555", "140603": "RAMBAH -- 28557", "140604": "TAMBUSAI -- 28558", "140605": "KEPENUHAN -- 28559", "140606": "KUNTO DARUSSALAM -- 28556", "140607": "RAMBAH SAMO -- 28565", "140608": "RAMBAH HILIR -- 28557", "140609": "TAMBUSAI UTARA -- 28558", "140610": "BANGUN PURBA -- 28557", "140611": "TANDUN -- 28554", "140612": "KABUN -- 28554", "140613": "BONAI DARUSSALAM -- 28559", "140614": "PAGARAN TAPAH DARUSSALAM -- 28556", "140615": "KEPENUHAN HULU -- 28559", "140616": "PENDALIAN IV KOTO -- 28555", "140701": "KUBU -- 28991", "140702": "BANGKO -- 28912", "140703": "TANAH PUTIH -- 28983", "140704": "RIMBA MELINTANG -- 28953", "140705": "BAGAN SINEMBAH -- 28992", "140706": "PASIR LIMAU KAPAS -- 28991", "140707": "SINABOI -- 28912", "140708": "PUJUD -- 28983", "140709": "TANAH PUTIH TANJUNG MELAWAN -- 28983", "140710": "BANGKO PUSAKO -- -", "140711": "SIMPANG KANAN -- 28992", "140712": "BATU HAMPAR -- 28912", "140713": "RANTAU KOPAR -- 28983", "140714": "PEKAITAN -- 28912", "140715": "KUBU BABUSSALAM -- 28991", "140801": "SIAK -- 28771", "140802": "SUNGAI APIT -- 28662", "140803": "MINAS -- 28685", "140804": "TUALANG -- 28772", "140805": "SUNGAI MANDAU -- 28671", "140806": "DAYUN -- 28671", "140807": "KERINCI KANAN -- 28654", "140808": "BUNGA RAYA -- 28763", "140809": "KOTO GASIB -- 28671", "140810": "KANDIS -- 28686", "140811": "LUBUK DALAM -- 28654", "140812": "SABAK AUH -- 28685", "140813": "MEMPURA -- 28773", "140814": "PUSAKO -- 28992", "140901": "KUANTAN MUDIK -- 29564", "140902": "KUANTAN TENGAH -- 29511", "140903": "SINGINGI -- 29563", "140904": "KUANTAN HILIR -- 29561", "140905": "CERENTI -- 29555", "140906": "BENAI -- 29566", "140907": "GUNUNGTOAR -- 29565", "140908": "SINGINGI HILIR -- 29563", "140909": "PANGEAN -- 29553", "140910": "LOGAS TANAH DARAT -- 29556", "140911": "INUMAN -- 29565", "140912": "HULU KUANTAN -- 29565", "140913": "KUANTAN HILIR SEBERANG -- 29561", "140914": "SENTAJO RAYA -- 29566", "140915": "PUCUK RANTAU -- 29564", "141001": "TEBING TINGGI -- 28753", "141002": "RANGSANG BARAT -- 28755", "141003": "RANGSANG -- 28755", "141004": "TEBING TINGGI BARAT -- 28753", "141005": "MERBAU -- 28752", "141006": "PULAUMERBAU -- 28752", "141007": "TEBING TINGGI TIMUR -- 28753", "141008": "TASIK PUTRI PUYU -- 28752", "147101": "SUKAJADI -- 28122", "147102": "PEKANBARU KOTA -- 28114", "147103": "SAIL -- 28131", "147104": "LIMA PULUH -- 28144", "147105": "SENAPELAN -- 28153", "147106": "RUMBAI -- 28263", "147107": "BUKIT RAYA -- 28284", "147108": "TAMPAN -- 28291", "147109": "MARPOYAN DAMAI -- 28125", "147110": "TENAYAN RAYA -- 28286", "147111": "PAYUNG SEKAKI -- 28292", "147112": "RUMBAI PESISIR -- 28263", "147201": "DUMAI BARAT -- 28821", "147202": "DUMAI TIMUR -- 28811", "147203": "BUKIT KAPUR -- 28882", "147204": "SUNGAI SEMBILAN -- 28826", "147205": "MEDANG KAMPAI -- 28825", "147206": "DUMAI KOTA -- 28812", "147207": "DUMAI SELATAN -- 28825", "150101": "GUNUNG RAYA -- 37174", "150102": "DANAU KERINCI -- 37172", "150104": "SITINJAU LAUT -- 37171", "150105": "AIR HANGAT -- 37161", "150106": "GUNUNG KERINCI -- 37162", "150107": "BATANG MERANGIN -- 37175", "150108": "KELILING DANAU -- 37173", "150109": "KAYU ARO -- 37163", "150111": "AIR HANGAT TIMUR -- 37161", "150115": "GUNUNG TUJUH -- 37163", "150116": "SIULAK -- 37162", "150117": "DEPATI TUJUH -- 37161", "150118": "SIULAK MUKAI -- 37162", "150119": "KAYU ARO BARAT -- 37163", "150121": "AIR HANGAT BARAT -- 37161", "150201": "JANGKAT -- 37372", "150202": "BANGKO -- 37311", "150203": "MUARA SIAU -- 37371", "150204": "SUNGAI MANAU -- 37361", "150205": "TABIR -- 37353", "150206": "PAMENANG -- 37352", "150207": "TABIR ULU -- 37356", "150208": "TABIR SELATAN -- 37354", "150209": "LEMBAH MASURAI -- 37372", "150210": "BANGKO BARAT -- 37311", "150211": "NALO TATAN -- -", "150212": "BATANG MASUMAI -- 37311", "150213": "PAMENANG BARAT -- 37352", "150214": "TABIR ILIR -- 37353", "150215": "TABIR TIMUR -- 37353", "150216": "RENAH PEMBARAP -- 37361", "150217": "PANGKALAN JAMBU -- 37361", "150218": "SUNGAI TENANG -- 37372", "150301": "BATANG ASAI -- 37485", "150302": "LIMUN -- 37382", "150303": "SAROLANGUN -- 37481", "150304": "PAUH -- 37491", "150305": "PELAWAN -- 37482", "150306": "MANDIANGIN -- 37492", "150307": "AIR HITAM -- 37491", "150308": "BATHIN VIII -- 37481", "150309": "SINGKUT -- 37482", "150310": "CERMIN NAN GEDANG -- -", "150401": "MERSAM -- 36654", "150402": "MUARA TEMBESI -- 36653", "150403": "MUARA BULIAN -- 36611", "150404": "BATIN XXIV -- 36656", "150405": "PEMAYUNG -- 36657", "150406": "MARO SEBO ULU -- 36655", "150407": "BAJUBANG -- 36611", "150408": "MARO SEBO ILIR -- 36655", "150501": "JAMBI LUAR KOTA -- 36361", "150502": "SEKERNAN -- 36381", "150503": "KUMPEH -- 36373", "150504": "MARO SEBO -- 36382", "150505": "MESTONG -- 36364", "150506": "KUMPEH ULU -- 36373", "150507": "SUNGAI BAHAR -- 36365", "150508": "SUNGAI GELAM -- 36364", "150510": "BAHAR SELATAN -- 36365", "150601": "TUNGKAL ULU -- 36552", "150602": "TUNGKAL ILIR -- 36555", "150603": "PENGABUAN -- 36553", "150604": "BETARA -- 36555", "150605": "MERLUNG -- 36554", "150606": "TEBING TINGGI -- 36552", "150607": "BATANG ASAM -- 36552", "150608": "RENAH MENDALUH -- 36554", "150609": "MUARA PAPALIK -- 36554", "150610": "SEBERANG KOTA -- 36511", "150611": "BRAM ITAM -- 36514", "150612": "KUALA BETARA -- 36555", "150613": "SENYERANG -- 36553", "150701": "MUARA SABAK TIMUR -- 36761", "150702": "NIPAH PANJANG -- 36771", "150703": "MENDAHARA -- 36764", "150704": "RANTAU RASAU -- 36772", "150705": "S A D U -- 36773", "150706": "DENDANG -- 36763", "150707": "MUARA SABAK BARAT -- 36761", "150708": "KUALA JAMBI -- 36761", "150709": "MENDAHARA ULU -- 36764", "150710": "GERAGAI -- 36764", "150711": "BERBAK -- 36572", "150801": "TANAH TUMBUH -- 37255", "150802": "RANTAU PANDAN -- 37261", "150803": "PASAR MUARO BUNGO -- -", "150804": "JUJUHAN -- 37257", "150805": "TANAH SEPENGGAL -- 37263", "150806": "PELEPAT -- 37262", "150807": "LIMBUR LUBUK MENGKUANG -- 37211", "150808": "MUKO-MUKO BATHIN VII -- -", "150809": "PELEPAT ILIR -- 37252", "150810": "BATIN II BABEKO -- -", "150811": "BATHIN III -- 37211", "150812": "BUNGO DANI -- 37211", "150813": "RIMBO TENGAH -- 37211", "150814": "BATHIN III ULU -- 37261", "150815": "BATHIN II PELAYANG -- 37255", "150816": "JUJUHAN ILIR -- 37257", "150817": "TANAH SEPENGGAL LINTAS -- 37263", "150901": "TEBO TENGAH -- 37571", "150902": "TEBO ILIR -- 37572", "150903": "TEBO ULU -- 37554", "150904": "RIMBO BUJANG -- 37553", "150905": "SUMAY -- 37573", "150906": "VII KOTO -- 37259", "150907": "RIMBO ULU -- 37553", "150908": "RIMBO ILIR -- 37553", "150909": "TENGAH ILIR -- 37572", "150910": "SERAI SERUMPUN -- 37554", "150911": "VII KOTO ILIR -- 37259", "150912": "MUARA TABIR -- 37572", "157101": "TELANAIPURA -- 36123", "157102": "JAMBI SELATAN -- 36139", "157103": "JAMBI TIMUR -- 36145", "157104": "PASAR JAMBI -- 36112", "157105": "PELAYANGAN -- 36251", "157106": "DANAU TELUK -- 36262", "157107": "KOTA BARU -- 36129", "157108": "JELUTUNG -- 36134", "157201": "SUNGAI PENUH -- 37111", "157202": "PESISIR BUKIT -- 37111", "157203": "HAMPARAN RAWANG -- 37152", "157204": "TANAH KAMPUNG -- 37171", "157205": "KUMUN DEBAI -- 37111", "157206": "PONDOK TINGGI -- 37111", "157207": "KOTO BARU -- 37152", "157208": "SUNGAI BUNGKAL -- 37112", "160107": "SOSOH BUAY RAYAP -- 32151", "160108": "PENGANDONAN -- 32155", "160109": "PENINJAUAN -- 32191", "160113": "BATURAJA BARAT -- 32121", "160114": "BATURAJA TIMUR -- 32111", "160120": "ULU OGAN -- 32157", "160121": "SEMIDANG AJI -- 32156", "160122": "LUBUK BATANG -- 32192", "160128": "LENGKITI -- 32158", "160129": "SINAR PENINJAUAN -- 32159", "160130": "LUBUK RAJA -- 32152", "160131": "MUARA JAYA -- 32155", "160202": "TANJUNG LUBUK -- 30671", "160203": "PEDAMARAN -- 30672", "160204": "MESUJI -- 30681", "160205": "KAYU AGUNG -- 30618", "160208": "SIRAH PULAU PADANG -- 30652", "160211": "TULUNG SELAPAN -- 30655", "160212": "PAMPANGAN -- 30654", "160213": "LEMPUING -- 30657", "160214": "AIR SUGIHAN -- 30656", "160215": "SUNGAI MENANG -- 30681", "160217": "JEJAWI -- 30652", "160218": "CENGAL -- 30658", "160219": "PANGKALAN LAMPAM -- 30659", "160220": "MESUJI MAKMUR -- 30681", "160221": "MESUJI RAYA -- 30681", "160222": "LEMPUING JAYA -- 30657", "160223": "TELUK GELAM -- 30673", "160224": "PEDAMARAN TIMUR -- 30672", "160301": "TANJUNG AGUNG -- 31355", "160302": "MUARA ENIM -- 31311", "160303": "RAMBANG DANGKU -- 31172", "160304": "GUNUNG MEGANG -- 31352", "160306": "GELUMBANG -- 31171", "160307": "LAWANG KIDUL -- 31711", "160308": "SEMENDE DARAT LAUT -- -", "160309": "SEMENDE DARAT TENGAH -- -", "160310": "SEMENDE DARAT ULU -- -", "160311": "UJAN MAS -- 31351", "160314": "LUBAI -- 31173", "160315": "RAMBANG -- 31172", "160316": "SUNGAI ROTAN -- 31357", "160317": "LEMBAK -- 31171", "160319": "BENAKAT -- 31626", "160321": "KELEKAR -- 31171", "160322": "MUARA BELIDA -- 31171", "160323": "BELIMBING -- -", "160324": "BELIDA DARAT -- -", "160325": "LUBAI ULU -- -", "160401": "TANJUNGSAKTI PUMU -- 31581", "160406": "JARAI -- 31591", "160407": "KOTA AGUNG -- 31462", "160408": "PULAUPINANG -- 31461", "160409": "MERAPI BARAT -- 31471", "160410": "LAHAT -- 31414", "160412": "PAJAR BULAN -- 31356", "160415": "MULAK ULU -- 31453", "160416": "KIKIM SELATAN -- 31452", "160417": "KIKIM TIMUR -- 31452", "160418": "KIKIM TENGAH -- 31452", "160419": "KIKIM BARAT -- 31452", "160420": "PSEKSU -- 31419", "160421": "GUMAY TALANG -- 31419", "160422": "PAGAR GUNUNG -- 31461", "160423": "MERAPI TIMUR -- 31471", "160424": "TANJUNG SAKTI PUMI -- 31581", "160425": "GUMAY ULU -- 31461", "160426": "MERAPI SELATAN -- 31471", "160427": "TANJUNGTEBAT -- 31462", "160428": "MUARAPAYANG -- 31591", "160429": "SUKAMERINDU -- 31356", "160501": "TUGUMULYO -- 31662", "160502": "MUARA LAKITAN -- 31666", "160503": "MUARA KELINGI -- 31663", "160508": "JAYALOKA -- 31665", "160509": "MUARA BELITI -- 31661", "160510": "STL ULU TERAWAS -- 30771", "160511": "SELANGIT -- 31625", "160512": "MEGANG SAKTI -- 31657", "160513": "PURWODADI -- 31668", "160514": "BTS. ULU -- -", "160518": "TIANG PUMPUNG KEPUNGUT -- 31661", "160519": "SUMBER HARTA -- 30771", "160520": "TUAH NEGERI -- 31663", "160521": "SUKA KARYA -- 31665", "160601": "SEKAYU -- 30711", "160602": "LAIS -- 30757", "160603": "SUNGAI KERUH -- 30757", "160604": "BATANG HARI LEKO -- 30755", "160605": "SANGA DESA -- 30759", "160606": "BABAT TOMAN -- 30752", "160607": "SUNGAI LILIN -- 30755", "160608": "KELUANG -- 30754", "160609": "BAYUNG LENCIR -- 30756", "160610": "PLAKAT TINGGI -- 30758", "160611": "LALAN -- 30758", "160612": "TUNGKAL JAYA -- 30756", "160613": "LAWANG WETAN -- 30752", "160614": "BABAT SUPAT -- 30755", "160701": "BANYUASIN I -- 30962", "160702": "BANYUASIN II -- 30953", "160703": "BANYUASIN III -- 30953", "160704": "PULAU RIMAU -- 30959", "160705": "BETUNG -- 30958", "160706": "RAMBUTAN -- 30967", "160707": "MUARA PADANG -- 30975", "160708": "MUARA TELANG -- 30974", "160709": "MAKARTI JAYA -- 30972", "160710": "TALANG KELAPA -- 30961", "160711": "RANTAU BAYUR -- 30968", "160712": "TANJUNG LAGO -- 30961", "160713": "MUARA SUGIHAN -- 30975", "160714": "AIR SALEK -- 30975", "160715": "TUNGKAL ILIR -- 30959", "160716": "SUAK TAPEH -- 30958", "160717": "SEMBAWA -- 30953", "160718": "SUMBER MARGA TELANG -- 30974", "160719": "AIR KUMBANG -- 30962", "160801": "MARTAPURA -- 32315", "160802": "BUAY MADANG -- 32361", "160803": "BELITANG -- 32385", "160804": "CEMPAKA -- 32384", "160805": "BUAY PEMUKA PELIUNG -- -", "160806": "MADANG SUKU II -- 32366", "160807": "MADANG SUKU I -- 32362", "160808": "SEMENDAWAI SUKU III -- 32386", "160809": "BELITANG II -- 32383", "160810": "BELITANG III -- 32385", "160811": "BUNGA MAYANG -- 32381", "160812": "BUAY MADANG TIMUR -- 32361", "160813": "MADANG SUKU III -- 32366", "160814": "SEMENDAWAI BARAT -- 32184", "160815": "SEMENDAWAI TIMUR -- 32185", "160816": "JAYAPURA -- 32381", "160817": "BELITANG JAYA -- 32385", "160818": "BELITANG MADANG RAYA -- 32362", "160819": "BELITANG MULYA -- 32383", "160820": "BUAY PEMUKA BANGSA RAJA -- 32361", "160901": "MUARA DUA -- 32272", "160902": "PULAU BERINGIN -- 32273", "160903": "BANDING AGUNG -- 32274", "160904": "MUARA DUA KISAM -- 32272", "160905": "SIMPANG -- 32264", "160906": "BUAY SANDANG AJI -- 32277", "160907": "BUAY RUNJUNG -- 32278", "160908": "MEKAKAU ILIR -- 32276", "160909": "BUAY PEMACA -- 32265", "160910": "KISAM TINGGI -- 32279", "160911": "KISAM ILIR -- 32272", "160912": "BUAY PEMATANG RIBU RANAU TENGAH -- 32274", "160913": "WARKUK RANAU SELATAN -- 32274", "160914": "RUNJUNG AGUNG -- 32278", "160915": "SUNGAI ARE -- 32273", "160916": "SINDANG DANAU -- 32273", "160917": "BUANA PEMACA -- 32264", "160918": "TIGA DIHAJI -- 32277", "160919": "BUAY RAWAN -- 32211", "161001": "MUARA KUANG -- 30865", "161002": "TANJUNG BATU -- 30664", "161003": "TANJUNG RAJA -- 30661", "161004": "INDRALAYA -- 30862", "161005": "PEMULUTAN -- 30653", "161006": "RANTAU ALAI -- 30866", "161007": "INDRALAYA UTARA -- 30862", "161008": "INDRALAYA SELATAN -- 30862", "161009": "PEMULUTAN SELATAN -- 30653", "161010": "PEMULUTAN BARAT -- 30653", "161011": "RANTAU PANJANG -- 30661", "161012": "SUNGAI PINANG -- 30661", "161013": "KANDIS -- 30867", "161014": "RAMBANG KUANG -- 30869", "161015": "LUBUK KELIAT -- 30868", "161016": "PAYARAMAN -- 30664", "161101": "MUARA PINANG -- 31592", "161102": "PENDOPO -- 31593", "161103": "ULU MUSI -- 31594", "161104": "TEBING TINGGI -- 31453", "161105": "LINTANG KANAN -- 31593", "161106": "TALANG PADANG -- 31596", "161107": "PASEMAH AIR KERUH -- 31595", "161108": "SIKAP DALAM -- 31594", "161109": "SALING -- 31453", "161110": "PENDOPO BARAT -- 31593", "161201": "TALANG UBI -- 31214", "161202": "PENUKAL UTARA -- 31315", "161203": "PENUKAL -- 31315", "161204": "ABAB -- 31315", "161205": "TANAH ABANG -- 31314", "161301": "RUPIT -- 31654", "161302": "RAWAS ULU -- 31656", "161303": "NIBUNG -- 31667", "161304": "RAWAS ILIR -- 31655", "161305": "KARANG DAPO -- 31658", "161306": "KARANG JAYA -- 31654", "161307": "ULU RAWAS -- 31669", "167101": "ILIR BARAT II -- 30141", "167102": "SEBERANG ULU I -- 30257", "167103": "SEBERANG ULU II -- 30267", "167104": "ILIR BARAT I -- 30136", "167105": "ILIR TIMUR I -- 30117", "167106": "ILIR TIMUR II -- 30117", "167107": "SUKARAMI -- 30151", "167108": "SAKO -- 30163", "167109": "KEMUNING -- 30127", "167110": "KALIDONI -- 30114", "167111": "BUKIT KECIL -- 30132", "167112": "GANDUS -- 30147", "167113": "KERTAPATI -- 30259", "167114": "PLAJU -- 30268", "167115": "ALANG-ALANG LEBAR -- 30154", "167116": "SEMATANG BORANG -- 30161", "167201": "PAGAR ALAM UTARA -- 31513", "167202": "PAGAR ALAM SELATAN -- 31526", "167203": "DEMPO UTARA -- 31521", "167204": "DEMPO SELATAN -- 31521", "167205": "DEMPO TENGAH -- 31521", "167305": "LUBUK LINGGAU TIMUR II -- -", "167306": "LUBUK LINGGAU BARAT II -- -", "167307": "LUBUK LINGGAU SELATAN II -- -", "167308": "LUBUK LINGGAU UTARA II -- -", "167401": "PRABUMULIH BARAT -- 31122", "167402": "PRABUMULIH TIMUR -- 31117", "167403": "CAMBAI -- 31141", "167404": "RAMBANG KPK TENGAH -- -", "167405": "PRABUMULIH UTARA -- 31121", "167406": "PRABUMULIH SELATAN -- 31124", "170101": "KEDURANG -- 38553", "170102": "SEGINIM -- 38552", "170103": "PINO -- 38571", "170104": "MANNA -- 38571", "170105": "KOTA MANNA -- 38511", "170106": "PINO RAYA -- 38571", "170107": "KEDURANG ILIR -- 38553", "170108": "AIR NIPIS -- 38571", "170109": "ULU MANNA -- 38571", "170110": "BUNGA MAS -- 38511", "170111": "PASAR MANNA -- 38518", "170206": "KOTA PADANG -- 39183", "170207": "PADANG ULAK TANDING -- 39182", "170208": "SINDANG KELINGI -- 39153", "170209": "CURUP -- 39125", "170210": "BERMANI ULU -- 39152", "170211": "SELUPU REJANG -- 39153", "170216": "CURUP UTARA -- 39125", "170217": "CURUP TIMUR -- 39115", "170218": "CURUP SELATAN -- 39125", "170219": "CURUP TENGAH -- 39125", "170220": "BINDURIANG -- 39182", "170221": "SINDANG BELITI ULU -- 39182", "170222": "SINDANG DATARAN -- -", "170223": "SINDANG BELITI ILIR -- 39183", "170224": "BERMANI ULU RAYA -- 39152", "170301": "ENGGANO -- 38387", "170306": "KERKAP -- 38374", "170307": "KOTA ARGA MAKMUR -- -", "170308": "GIRI MULYA -- -", "170309": "PADANG JAYA -- 38657", "170310": "LAIS -- 38653", "170311": "BATIK NAU -- 38656", "170312": "KETAHUN -- 38361", "170313": "NAPAL PUTIH -- 38363", "170314": "PUTRI HIJAU -- 38326", "170315": "AIR BESI -- 38575", "170316": "AIR NAPAL -- 38373", "170319": "HULU PALIK -- 38374", "170320": "AIR PADANG -- 38653", "170321": "ARMA JAYA -- 38611", "170323": "ULOK KUPAI -- 38363", "170401": "KINAL -- 38962", "170402": "TANJUNG KEMUNING -- 38955", "170403": "KAUR UTARA -- 38956", "170404": "KAUR TENGAH -- 38961", "170405": "KAUR SELATAN -- 38963", "170406": "MAJE -- 38965", "170407": "NASAL -- 38964", "170408": "SEMIDANG GUMAY -- -", "170409": "KELAM TENGAH -- 38955", "170410": "LUAS -- 38961", "170411": "MUARA SAHUNG -- 38961", "170412": "TETAP -- 38963", "170413": "LUNGKANG KULE -- 38956", "170414": "PADANG GUCI HILIR -- 38956", "170415": "PADANG GUCI HULU -- 38956", "170501": "SUKARAJA -- 38877", "170502": "SELUMA -- 38883", "170503": "TALO -- 38886", "170504": "SEMIDANG ALAS -- 38873", "170505": "SEMIDANG ALAS MARAS -- 38875", "170506": "AIR PERIUKAN -- 38881", "170507": "LUBUK SANDI -- 38882", "170508": "SELUMA BARAT -- 38883", "170509": "SELUMA TIMUR -- 38885", "170510": "SELUMA UTARA -- 38884", "170511": "SELUMA SELATAN -- 38878", "170512": "TALO KECIL -- 38888", "170513": "ULU TALO -- 38886", "170514": "ILIR TALO -- 38887", "170601": "LUBUK PINANG -- 38767", "170602": "KOTA MUKOMUKO -- 38765", "170603": "TERAS TERUNJAM -- 38768", "170604": "PONDOK SUGUH -- 38766", "170605": "IPUH -- 38764", "170606": "MALIN DEMAN -- 38764", "170607": "AIR RAMI -- 38764", "170608": "TERAMANG JAYA -- 38766", "170609": "SELAGAN RAYA -- 38768", "170610": "PENARIK -- 38768", "170611": "XIV KOTO -- 38765", "170612": "V KOTO -- 38765", "170613": "AIR MAJUNTO -- 38767", "170614": "AIR DIKIT -- 38765", "170615": "SUNGAI RUMBAI -- 38766", "170701": "LEBONG UTARA -- 39264", "170702": "LEBONG ATAS -- 39265", "170703": "LEBONG TENGAH -- 39263", "170704": "LEBONG SELATAN -- 39262", "170705": "RIMBO PENGADANG -- 39261", "170706": "TOPOS -- 39262", "170707": "BINGIN KUNING -- 39262", "170708": "LEBONG SAKTI -- 39267", "170709": "PELABAI -- 39265", "170710": "AMEN -- 39264", "170711": "URAM JAYA -- 39268", "170712": "PINANG BELAPIS -- 39269", "170801": "BERMANI ILIR -- 39374", "170802": "UJAN MAS -- 39371", "170803": "TEBAT KARAI -- 39373", "170804": "KEPAHIANG -- 39372", "170805": "MERIGI -- 38383", "170806": "KEBAWETAN -- 39372", "170807": "SEBERANG MUSI -- 39373", "170808": "MUARA KEMUMU -- 39374", "170901": "KARANG TINGGI -- 38382", "170902": "TALANG EMPAT -- 38385", "170903": "PONDOK KELAPA -- 38371", "170904": "PEMATANG TIGA -- 38372", "170905": "PAGAR JATI -- 38383", "170906": "TABA PENANJUNG -- 38386", "170907": "MERIGI KELINDANG -- 38386", "170908": "MERIGI SAKTI -- 38383", "170909": "PONDOK KUBANG -- 38375", "170910": "BANG HAJI -- 38372", "177101": "SELEBAR -- 38214", "177102": "GADING CEMPAKA -- 38221", "177103": "TELUK SEGARA -- 38118", "177104": "MUARA BANGKA HULU -- 38121", "177105": "KAMPUNG MELAYU -- 38215", "177106": "RATU AGUNG -- 38223", "177107": "RATU SAMBAN -- 38222", "177108": "SUNGAI SERUT -- 38119", "177109": "SINGARAN PATI -- 38229", "180104": "NATAR -- 35362", "180105": "TANJUNG BINTANG -- 35361", "180106": "KALIANDA -- 35551", "180107": "SIDOMULYO -- 35353", "180108": "KATIBUNG -- 35452", "180109": "PENENGAHAN -- 35592", "180110": "PALAS -- 35594", "180113": "JATI AGUNG -- 35365", "180114": "KETAPANG -- 35596", "180115": "SRAGI -- 35597", "180116": "RAJA BASA -- 35552", "180117": "CANDIPURO -- 35356", "180118": "MERBAU MATARAM -- 35357", "180121": "BAKAUHENI -- 35592", "180122": "TANJUNG SARI -- 35361", "180123": "WAY SULAN -- 35452", "180124": "WAY PANJI -- 35353", "180201": "KALIREJO -- 34174", "180202": "BANGUN REJO -- 34173", "180203": "PADANG RATU -- 34175", "180204": "GUNUNG SUGIH -- 34161", "180205": "TRIMURJO -- 34172", "180206": "PUNGGUR -- 34152", "180207": "TERBANGGI BESAR -- 34163", "180208": "SEPUTIH RAMAN -- 34155", "180209": "RUMBIA -- 34157", "180210": "SEPUTIH BANYAK -- 34156", "180211": "SEPUTIH MATARAM -- 34164", "180212": "SEPUTIH SURABAYA -- 34158", "180213": "TERUSAN NUNYAI -- 34167", "180214": "BUMI RATU NUBAN -- 34161", "180215": "BEKRI -- 34162", "180216": "SEPUTIH AGUNG -- 34166", "180217": "WAY PANGUBUAN -- 35213", "180218": "BANDAR MATARAM -- 34169", "180219": "PUBIAN -- 34176", "180220": "SELAGAI LINGGA -- 34176", "180221": "ANAK TUHA -- 34161", "180222": "SENDANG AGUNG -- 34174", "180223": "KOTA GAJAH -- 34153", "180224": "BUMI NABUNG -- 34168", "180225": "WAY SEPUTIH -- 34179", "180226": "BANDAR SURABAYA -- 34159", "180227": "ANAK RATU AJI -- 35513", "180228": "PUTRA RUMBIA -- 34157", "180301": "BUKIT KEMUNING -- 34556", "180302": "KOTABUMI -- 34511", "180303": "SUNGKAI SELATAN -- 34554", "180304": "TANJUNG RAJA -- 34557", "180305": "ABUNG TIMUR -- 34583", "180306": "ABUNG BARAT -- 34558", "180307": "ABUNG SELATAN -- 34581", "180308": "SUNGKAI UTARA -- 34555", "180309": "KOTABUMI UTARA -- 34511", "180310": "KOTABUMI SELATAN -- 34511", "180311": "ABUNG TENGAH -- 34582", "180312": "ABUNG TINGGI -- 34556", "180313": "ABUNG SEMULI -- 34581", "180314": "ABUNG SURAKARTA -- 34581", "180315": "MUARA SUNGKAI -- 34559", "180316": "BUNGA MAYANG -- 34555", "180317": "HULU SUNGKAI -- 34555", "180318": "SUNGKAI TENGAH -- 34555", "180319": "ABUNG PEKURUN -- 34582", "180320": "SUNGKAI JAYA -- 34554", "180321": "SUNGKAI BARAT -- 34558", "180322": "ABUNG KUNANG -- 34558", "180323": "BLAMBANGAN PAGAR -- 34581", "180404": "BALIK BUKIT -- 34811", "180405": "SUMBER JAYA -- 34871", "180406": "BELALAU -- 34872", "180407": "WAY TENONG -- 34884", "180408": "SEKINCAU -- 34885", "180409": "SUOH -- 34882", "180410": "BATU BRAK -- 34881", "180411": "SUKAU -- 34879", "180415": "GEDUNG SURIAN -- 34871", "180418": "KEBUN TEBU -- 34871", "180419": "AIR HITAM -- 34876", "180420": "PAGAR DEWA -- 34885", "180421": "BATU KETULIS -- 34872", "180422": "LUMBOK SEMINUNG -- 34879", "180423": "BANDAR NEGERI SUOH -- 34882", "180502": "MENGGALA -- 34613", "180506": "GEDUNG AJI -- 34681", "180508": "BANJAR AGUNG -- 34682", "180511": "GEDUNG MENENG -- 34596", "180512": "RAWA JITU SELATAN -- 34596", "180513": "PENAWAR TAMA -- 34595", "180518": "RAWA JITU TIMUR -- 34596", "180520": "BANJAR MARGO -- 34682", "180522": "RAWA PITU -- 34595", "180523": "PENAWAR AJI -- 34595", "180525": "DENTE TELADAS -- 34596", "180526": "MERAKSA AJI -- 34681", "180527": "GEDUNG AJI BARU -- 34595", "180601": "KOTA AGUNG -- 35384", "180602": "TALANG PADANG -- 35377", "180603": "WONOSOBO -- 35686", "180604": "PULAU PANGGUNG -- 35679", "180609": "CUKUH BALAK -- 35683", "180611": "PUGUNG -- 35675", "180612": "SEMAKA -- 35386", "180613": "SUMBER REJO -- -", "180615": "ULU BELU -- 35377", "180616": "PEMATANG SAWA -- 35382", "180617": "KLUMBAYAN -- -", "180618": "KOTA AGUNG BARAT -- 35384", "180619": "KOTA AGUNG TIMUR -- 35384", "180620": "GISTING -- 35378", "180621": "GUNUNG ALIP -- 35379", "180624": "LIMAU -- 35613", "180625": "BANDAR NEGERI SEMUONG -- 35686", "180626": "AIR NANINGAN -- 35679", "180627": "BULOK -- 35682", "180628": "KLUMBAYAN BARAT -- -", "180701": "SUKADANA -- 34194", "180702": "LABUHAN MARINGGAI -- 34198", "180703": "JABUNG -- 34384", "180704": "PEKALONGAN -- 34391", "180705": "SEKAMPUNG -- 34385", "180706": "BATANGHARI -- 34381", "180707": "WAY JEPARA -- 34396", "180708": "PURBOLINGGO -- 34373", "180709": "RAMAN UTARA -- 34371", "180710": "METRO KIBANG -- 34331", "180711": "MARGA TIGA -- 34386", "180712": "SEKAMPUNG UDIK -- 34385", "180713": "BATANGHARI NUBAN -- 34372", "180714": "BUMI AGUNG -- 34763", "180715": "BANDAR SRIBHAWONO -- -", "180716": "MATARAM BARU -- 34199", "180717": "MELINTING -- 34377", "180718": "GUNUNG PELINDUNG -- 34388", "180719": "PASIR SAKTI -- 34387", "180720": "WAWAY KARYA -- 34376", "180721": "LABUHAN RATU -- 35149", "180722": "BRAJA SELEBAH -- -", "180723": "WAY BUNGUR -- 34373", "180724": "MARGA SEKAMPUNG -- 34384", "180801": "BLAMBANGAN UMPU -- 34764", "180802": "KASUI -- 34765", "180803": "BANJIT -- 34766", "180804": "BARADATU -- 34761", "180805": "BAHUGA -- 34763", "180806": "PAKUAN RATU -- 34762", "180807": "NEGERI AGUNG -- 34769", "180808": "WAY TUBA -- 34767", "180809": "REBANG TANGKAS -- 34767", "180810": "GUNUNG LABUHAN -- 34768", "180811": "NEGARA BATIN -- 34769", "180812": "NEGERI BESAR -- 34769", "180813": "BUAY BAHUGA -- 34767", "180814": "BUMI AGUNG -- 34763", "180901": "GEDONG TATAAN -- 35366", "180902": "NEGERI KATON -- 35353", "180903": "TEGINENENG -- 35363", "180904": "WAY LIMA -- 35367", "180905": "PADANG CERMIN -- 35451", "180906": "PUNDUH PIDADA -- 35453", "180907": "KEDONDONG -- 35368", "180908": "MARGA PUNDUH -- 35453", "180909": "WAY KHILAU -- 35368", "181001": "PRINGSEWU -- 35373", "181002": "GADING REJO -- 35372", "181003": "AMBARAWA -- 35376", "181004": "PARDASUKA -- 35682", "181005": "PAGELARAN -- 35376", "181006": "BANYUMAS -- 35373", "181007": "ADILUWIH -- 35674", "181008": "SUKOHARJO -- 35674", "181009": "PAGELARAN UTARA -- 35376", "181101": "MESUJI -- 34697", "181102": "MESUJI TIMUR -- 34697", "181103": "RAWA JITU UTARA -- 34696", "181104": "WAY SERDANG -- 34684", "181105": "SIMPANG PEMATANG -- 34698", "181106": "PANCA JAYA -- 34698", "181107": "TANJUNG RAYA -- 34598", "181201": "TULANG BAWANG TENGAH -- 34693", "181202": "TUMIJAJAR -- 34594", "181203": "TULANG BAWANG UDIK -- 34691", "181204": "GUNUNG TERANG -- 34683", "181205": "GUNUNG AGUNG -- 34683", "181206": "WAY KENANGA -- 34388", "181207": "LAMBU KIBANG -- 34388", "181208": "PAGAR DEWA -- 34885", "181301": "PESISIR TENGAH -- 34874", "181302": "PESISIR SELATAN -- 34875", "181303": "LEMONG -- 34877", "181304": "PESISIR UTARA -- 34876", "181305": "KARYA PENGGAWA -- 34878", "181306": "PULAUPISANG -- 34876", "181307": "WAY KRUI -- 34874", "181308": "KRUI SELATAN -- 34874", "181309": "NGAMBUR -- 34883", "181310": "BENGKUNAT -- 34883", "181311": "BENGKUNAT BELIMBING -- 34883", "187101": "KEDATON -- 35141", "187102": "SUKARAME -- 35131", "187103": "TANJUNGKARANG BARAT -- 35151", "187104": "PANJANG -- 35245", "187105": "TANJUNGKARANG TIMUR -- 35121", "187106": "TANJUNGKARANG PUSAT -- 35116", "187107": "TELUKBETUNG SELATAN -- 35222", "187108": "TELUKBETUNG BARAT -- 35238", "187109": "TELUKBETUNG UTARA -- 35214", "187110": "RAJABASA -- 35552", "187111": "TANJUNG SENANG -- 35142", "187112": "SUKABUMI -- 35122", "187113": "KEMILING -- 35158", "187114": "LABUHAN RATU -- 35149", "187115": "WAY HALIM -- 35136", "187116": "LANGKAPURA -- 35155", "187117": "ENGGAL -- 34613", "187118": "KEDAMAIAN -- 35122", "187119": "TELUKBETUNG TIMUR -- 35235", "187120": "BUMI WARAS -- 35228", "187201": "METRO PUSAT -- 34113", "187202": "METRO UTARA -- 34117", "187203": "METRO BARAT -- 34114", "187204": "METRO TIMUR -- 34112", "187205": "METRO SELATAN -- 34119", "190101": "SUNGAILIAT -- 33211", "190102": "BELINYU -- 33253", "190103": "MERAWANG -- 33172", "190104": "MENDO BARAT -- 33173", "190105": "PEMALI -- 33255", "190106": "BAKAM -- 33252", "190107": "RIAU SILIP -- 33253", "190108": "PUDING BESAR -- 33179", "190201": "TANJUNG PANDAN -- 33411", "190202": "MEMBALONG -- 33452", "190203": "SELAT NASIK -- 33481", "190204": "SIJUK -- 33414", "190205": "BADAU -- 33451", "190301": "TOBOALI -- 33783", "190302": "LEPAR PONGOK -- 33791", "190303": "AIR GEGAS -- 33782", "190304": "SIMPANG RIMBA -- 33777", "190305": "PAYUNG -- 33778", "190306": "TUKAK SADAI -- 33783", "190307": "PULAUBESAR -- 33778", "190308": "KEPULAUAN PONGOK -- 33791", "190401": "KOBA -- 33681", "190402": "PANGKALAN BARU -- 33684", "190403": "SUNGAI SELAN -- 33675", "190404": "SIMPANG KATIS -- 33674", "190405": "NAMANG -- 33681", "190406": "LUBUK BESAR -- 33681", "190501": "MENTOK -- 33351", "190502": "SIMPANG TERITIP -- 33366", "190503": "JEBUS -- 33362", "190504": "KELAPA -- 33364", "190505": "TEMPILANG -- 33365", "190506": "PARITTIGA -- 33362", "190601": "MANGGAR -- 33512", "190602": "GANTUNG -- 33562", "190603": "DENDANG -- 33561", "190604": "KELAPA KAMPIT -- 33571", "190605": "DAMAR -- 33571", "190606": "SIMPANG RENGGIANG -- 33562", "190607": "SIMPANG PESAK -- 33561", "197101": "BUKITINTAN -- 33149", "197102": "TAMAN SARI -- 33121", "197103": "PANGKAL BALAM -- 33113", "197104": "RANGKUI -- 33135", "197105": "GERUNGGANG -- 33123", "197106": "GABEK -- 33111", "197107": "GIRIMAYA -- 33141", "210104": "GUNUNG KIJANG -- 29151", "210106": "BINTAN TIMUR -- 29151", "210107": "BINTAN UTARA -- 29152", "210108": "TELUK BINTAN -- 29133", "210109": "TAMBELAN -- 29193", "210110": "TELOK SEBONG -- -", "210112": "TOAPAYA -- 29151", "210113": "MANTANG -- 29151", "210114": "BINTAN PESISIR -- 29151", "210115": "SERI KUALA LOBAM -- -", "210201": "MORO -- 29663", "210202": "KUNDUR -- 29662", "210203": "KARIMUN -- 29661", "210204": "MERAL -- 29664", "210205": "TEBING -- 29663", "210206": "BURU -- 29664", "210207": "KUNDUR UTARA -- 29662", "210208": "KUNDUR BARAT -- 29662", "210209": "DURAI -- 29664", "210210": "MERAL BARAT -- 29664", "210211": "UNGAR -- 29662", "210212": "BELAT -- 29662", "210304": "MIDAI -- 29784", "210305": "BUNGURAN BARAT -- 29782", "210306": "SERASAN -- 29781", "210307": "BUNGURAN TIMUR -- 29783", "210308": "BUNGURAN UTARA -- 29783", "210309": "SUBI -- 29781", "210310": "PULAU LAUT -- 29783", "210311": "PULAU TIGA -- 29783", "210315": "BUNGURAN TIMUR LAUT -- 29783", "210316": "BUNGURAN TENGAH -- 29783", "210401": "SINGKEP -- 29875", "210402": "LINGGA -- 29874", "210403": "SENAYANG -- 29873", "210404": "SINGKEP BARAT -- 29875", "210405": "LINGGA UTARA -- 29874", "210406": "SINGKEP PESISIR -- 29871", "210407": "LINGGA TIMUR -- 29872", "210408": "SELAYAR -- 29872", "210409": "SINGKEP SELATAN -- -", "210501": "SIANTAN -- 29783", "210502": "PALMATAK -- 29783", "210503": "SIANTAN TIMUR -- 29791", "210504": "SIANTAN SELATAN -- 29791", "210505": "JEMAJA TIMUR -- 29792", "210506": "JEMAJA -- 29792", "210507": "SIANTAN TENGAH -- 29783", "217101": "BELAKANG PADANG -- 29413", "217102": "BATU AMPAR -- 29452", "217103": "SEKUPANG -- 29427", "217104": "NONGSA -- 29466", "217105": "BULANG -- 29474", "217106": "LUBUK BAJA -- 29432", "217107": "SEI BEDUK -- -", "217108": "GALANG -- 29483", "217109": "BENGKONG -- 29458", "217110": "BATAM KOTA -- 29431", "217111": "SAGULUNG -- 29439", "217112": "BATU AJI -- 29438", "217201": "TANJUNG PINANG BARAT -- 29111", "217202": "TANJUNG PINANG TIMUR -- 29122", "217203": "TANJUNG PINANG KOTA -- 29115", "217204": "BUKIT BESTARI -- 29124", "310101": "KEPULAUAN SERIBU UTARA -- 14540", "310102": "KEPULAUAN SERIBU SELATAN. -- -", "317101": "GAMBIR -- 10150", "317102": "SAWAH BESAR -- 10720", "317103": "KEMAYORAN -- 10640", "317104": "SENEN -- 10460", "317105": "CEMPAKA PUTIH -- 10520", "317106": "MENTENG -- 10330", "317107": "TANAH ABANG -- 10210", "317108": "JOHAR BARU -- 10530", "317201": "PENJARINGAN -- 14470", "317202": "TANJUNG PRIOK -- 14320", "317203": "KOJA -- 14210", "317204": "CILINCING -- 14120", "317205": "PADEMANGAN -- 14430", "317206": "KELAPA GADING -- 14240", "317301": "CENGKARENG -- 11730", "317302": "GROGOL PETAMBURAN -- 11450", "317303": "TAMAN SARI -- 11120", "317304": "TAMBORA -- 11330", "317305": "KEBON JERUK -- 11510", "317306": "KALIDERES -- 11840", "317307": "PAL MERAH -- 11430", "317308": "KEMBANGAN -- 11640", "317401": "TEBET -- 12840", "317402": "SETIABUDI -- 12980", "317403": "MAMPANG PRAPATAN -- 12730", "317404": "PASAR MINGGU -- 12560", "317405": "KEBAYORAN LAMA -- 12230", "317406": "CILANDAK -- 12430", "317407": "KEBAYORAN BARU -- 12150", "317408": "PANCORAN -- 12770", "317409": "JAGAKARSA -- 12630", "317410": "PESANGGRAHAN -- 12330", "317501": "MATRAMAN -- 13130", "317502": "PULOGADUNG -- 13240", "317503": "JATINEGARA -- 13310", "317504": "KRAMATJATI -- 13530", "317505": "PASAR REBO -- 13780", "317506": "CAKUNG -- 13910", "317507": "DUREN SAWIT -- 13440", "317508": "MAKASAR -- 13620", "317509": "CIRACAS -- 13720", "317510": "CIPAYUNG -- 13890", "320101": "CIBINONG -- 43271", "320102": "GUNUNG PUTRI -- 16969", "320103": "CITEUREUP -- 16810", "320104": "SUKARAJA -- 16710", "320105": "BABAKAN MADANG -- 16810", "320106": "JONGGOL -- 16830", "320107": "CILEUNGSI -- 16820", "320108": "CARIU -- 16840", "320109": "SUKAMAKMUR -- 16830", "320110": "PARUNG -- 43357", "320111": "GUNUNG SINDUR -- 16340", "320112": "KEMANG -- 16310", "320113": "BOJONG GEDE -- 16920", "320114": "LEUWILIANG -- 16640", "320115": "CIAMPEA -- 16620", "320116": "CIBUNGBULANG -- 16630", "320117": "PAMIJAHAN -- 16810", "320118": "RUMPIN -- 16350", "320119": "JASINGA -- 16670", "320120": "PARUNG PANJANG -- 16360", "320121": "NANGGUNG -- 16650", "320122": "CIGUDEG -- 16660", "320123": "TENJO -- 16370", "320124": "CIAWI -- 16720", "320125": "CISARUA -- 45355", "320126": "MEGAMENDUNG -- 16770", "320127": "CARINGIN -- 43154", "320128": "CIJERUK -- 16740", "320129": "CIOMAS -- 16610", "320130": "DRAMAGA -- 16680", "320131": "TAMANSARI -- 46196", "320132": "KLAPANUNGGAL -- 16710", "320133": "CISEENG -- 16120", "320134": "RANCA BUNGUR -- 16310", "320135": "SUKAJAYA -- 16660", "320136": "TANJUNGSARI -- 16840", "320137": "TAJURHALANG -- 16320", "320138": "CIGOMBONG -- 16110", "320139": "LEUWISADENG -- 16640", "320140": "TENJOLAYA -- 16370", "320201": "PELABUHANRATU -- -", "320202": "SIMPENAN -- 43361", "320203": "CIKAKAK -- 43365", "320204": "BANTARGADUNG -- 43363", "320205": "CISOLOK -- 43366", "320206": "CIKIDANG -- 43367", "320207": "LENGKONG -- 40262", "320208": "JAMPANG TENGAH -- 43171", "320209": "WARUNGKIARA -- 43362", "320210": "CIKEMBAR -- 43157", "320211": "CIBADAK -- 43351", "320212": "NAGRAK -- 43356", "320213": "PARUNGKUDA -- 43357", "320214": "BOJONGGENTENG -- 43353", "320215": "PARAKANSALAK -- 43355", "320216": "CICURUG -- 43359", "320217": "CIDAHU -- 43358", "320218": "KALAPANUNGGAL -- 43354", "320219": "KABANDUNGAN -- 43368", "320220": "WALURAN -- 43175", "320221": "JAMPANG KULON -- 43178", "320222": "CIEMAS -- 43177", "320223": "KALIBUNDER -- 43185", "320224": "SURADE -- 43179", "320225": "CIBITUNG -- 43172", "320226": "CIRACAP -- 43176", "320227": "GUNUNGGURUH -- 43156", "320228": "CICANTAYAN -- 43155", "320229": "CISAAT -- 43152", "320230": "KADUDAMPIT -- 43153", "320231": "CARINGIN -- 43154", "320232": "SUKABUMI -- 43151", "320233": "SUKARAJA -- 16710", "320234": "KEBONPEDES -- 43194", "320235": "CIREUNGHAS -- 43193", "320236": "SUKALARANG -- 43191", "320237": "PABUARAN -- 41262", "320238": "PURABAYA -- 43187", "320239": "NYALINDUNG -- 43196", "320240": "GEGERBITUNG -- 43197", "320241": "SAGARANTEN -- 43181", "320242": "CURUGKEMBAR -- 43182", "320243": "CIDOLOG -- 46352", "320244": "CIDADAP -- 43183", "320245": "TEGALBULEUD -- 43186", "320246": "CIMANGGU -- 43178", "320247": "CIAMBAR -- 43356", "320301": "CIANJUR -- 43211", "320302": "WARUNGKONDANG -- 43261", "320303": "CIBEBER -- 43262", "320304": "CILAKU -- 43285", "320305": "CIRANJANG -- 43282", "320306": "BOJONGPICUNG -- 43283", "320307": "KARANGTENGAH -- 43281", "320308": "MANDE -- 43292", "320309": "SUKALUYU -- 43284", "320310": "PACET -- 43253", "320311": "CUGENANG -- 43252", "320312": "CIKALONGKULON -- 43291", "320313": "SUKARESMI -- 43254", "320314": "SUKANAGARA -- 43264", "320315": "CAMPAKA -- 41181", "320316": "TAKOKAK -- 43265", "320317": "KADUPANDAK -- 43268", "320318": "PAGELARAN -- 43266", "320319": "TANGGEUNG -- 43267", "320320": "CIBINONG -- 43271", "320321": "SINDANGBARANG -- 43272", "320322": "AGRABINTA -- 43273", "320323": "CIDAUN -- 43275", "320324": "NARINGGUL -- 43274", "320325": "CAMPAKAMULYA -- 43269", "320326": "CIKADU -- 43284", "320327": "GEKBRONG -- 43261", "320328": "CIPANAS -- 43253", "320329": "CIJATI -- 43284", "320330": "LELES -- 44119", "320331": "HAURWANGI -- 43283", "320332": "PASIRKUDA -- 43267", "320405": "CILEUNYI -- 40626", "320406": "CIMENYAN -- -", "320407": "CILENGKRANG -- 40615", "320408": "BOJONGSOANG -- 40288", "320409": "MARGAHAYU -- 40226", "320410": "MARGAASIH -- 40214", "320411": "KATAPANG -- 40921", "320412": "DAYEUHKOLOT -- 40239", "320413": "BANJARAN -- 40377", "320414": "PAMEUNGPEUK -- 44175", "320415": "PANGALENGAN -- 40378", "320416": "ARJASARI -- 40379", "320417": "CIMAUNG -- 40374", "320425": "CICALENGKA -- 40395", "320426": "NAGREG -- 40215", "320427": "CIKANCUNG -- 40396", "320428": "RANCAEKEK -- 40394", "320429": "CIPARAY -- 40223", "320430": "PACET -- 43253", "320431": "KERTASARI -- 40386", "320432": "BALEENDAH -- 40375", "320433": "MAJALAYA -- 41371", "320434": "SOLOKANJERUK -- 40376", "320435": "PASEH -- 45381", "320436": "IBUN -- 43185", "320437": "SOREANG -- 40914", "320438": "PASIRJAMBU -- 40972", "320439": "CIWIDEY -- 40973", "320440": "RANCABALI -- 40973", "320444": "CANGKUANG -- 40238", "320446": "KUTAWARINGIN -- 40911", "320501": "GARUT KOTA -- 44113", "320502": "KARANGPAWITAN -- 44182", "320503": "WANARAJA -- 44183", "320504": "TAROGONG KALER -- 44151", "320505": "TAROGONG KIDUL -- 44151", "320506": "BANYURESMI -- 44191", "320507": "SAMARANG -- 44161", "320508": "PASIRWANGI -- 44161", "320509": "LELES -- 44119", "320510": "KADUNGORA -- 44153", "320511": "LEUWIGOONG -- 44192", "320512": "CIBATU -- 44185", "320513": "KERSAMANAH -- 44185", "320514": "MALANGBONG -- 44188", "320515": "SUKAWENING -- 44184", "320516": "KARANGTENGAH -- 43281", "320517": "BAYONGBONG -- 44162", "320518": "CIGEDUG -- 44116", "320519": "CILAWU -- 44181", "320520": "CISURUPAN -- 44163", "320521": "SUKARESMI -- 43254", "320522": "CIKAJANG -- 44171", "320523": "BANJARWANGI -- 44172", "320524": "SINGAJAYA -- 44173", "320525": "CIHURIP -- 44173", "320526": "PEUNDEUY -- 41272", "320527": "PAMEUNGPEUK -- 44175", "320528": "CISOMPET -- 44174", "320529": "CIBALONG -- 46185", "320530": "CIKELET -- 44177", "320531": "BUNGBULANG -- 44165", "320532": "MEKARMUKTI -- 44165", "320533": "PAKENJENG -- 44164", "320534": "PAMULIHAN -- 45365", "320535": "CISEWU -- 44166", "320536": "CARINGIN -- 43154", "320537": "TALEGONG -- 44167", "320538": "BL. LIMBANGAN -- -", "320539": "SELAAWI -- 44187", "320540": "CIBIUK -- 44193", "320541": "PANGATIKAN -- 44183", "320542": "SUCINARAJA -- 44115", "320601": "CIPATUJAH -- 46187", "320602": "KARANGNUNGGAL -- 46186", "320603": "CIKALONG -- 46195", "320604": "PANCATENGAH -- 46194", "320605": "CIKATOMAS -- 46193", "320606": "CIBALONG -- 46185", "320607": "PARUNGPONTENG -- 46185", "320608": "BANTARKALONG -- 46187", "320609": "BOJONGASIH -- 46475", "320610": "CULAMEGA -- 46188", "320611": "BOJONGGAMBIR -- 46475", "320612": "SODONGHILIR -- 46473", "320613": "TARAJU -- 46474", "320614": "SALAWU -- 46471", "320615": "PUSPAHIANG -- 46471", "320616": "TANJUNGJAYA -- 46184", "320617": "SUKARAJA -- 16710", "320618": "SALOPA -- 46192", "320619": "JATIWARAS -- 46185", "320620": "CINEAM -- 46198", "320621": "KARANG JAYA -- 46198", "320622": "MANONJAYA -- 46197", "320623": "GUNUNG TANJUNG -- 46418", "320624": "SINGAPARNA -- 46418", "320625": "MANGUNREJA -- 46462", "320626": "SUKARAME -- 46461", "320627": "CIGALONTANG -- 46463", "320628": "LEUWISARI -- 46464", "320629": "PADAKEMBANG -- 46466", "320630": "SARIWANGI -- 46465", "320631": "SUKARATU -- 46415", "320632": "CISAYONG -- 46153", "320633": "SUKAHENING -- 46155", "320634": "RAJAPOLAH -- 46155", "320635": "JAMANIS -- 46175", "320636": "CIAWI -- 16720", "320637": "KADIPATEN -- 45452", "320638": "PAGERAGEUNG -- 46158", "320639": "SUKARESIK -- 46418", "320701": "CIAMIS -- 46217", "320702": "CIKONENG -- 46261", "320703": "CIJEUNGJING -- 46271", "320704": "SADANANYA -- 46256", "320705": "CIDOLOG -- 46352", "320706": "CIHAURBEUTI -- 46262", "320707": "PANUMBANGAN -- 46263", "320708": "PANJALU -- 46264", "320709": "KAWALI -- 46253", "320710": "PANAWANGAN -- 46255", "320711": "CIPAKU -- 46252", "320712": "JATINAGARA -- 46273", "320713": "RAJADESA -- 46254", "320714": "SUKADANA -- 46272", "320715": "RANCAH -- 46387", "320716": "TAMBAKSARI -- 46388", "320717": "LAKBOK -- 46385", "320718": "BANJARSARI -- 46383", "320719": "PAMARICAN -- 46382", "320729": "CIMARAGAS -- 46381", "320730": "CISAGA -- 46386", "320731": "SINDANGKASIH -- 46268", "320732": "BAREGBEG -- 46274", "320733": "SUKAMANTRI -- 46264", "320734": "LUMBUNG -- 46258", "320735": "PURWADADI -- 46385", "320801": "KADUGEDE -- 45561", "320802": "CINIRU -- 45565", "320803": "SUBANG -- 45586", "320804": "CIWARU -- 45583", "320805": "CIBINGBIN -- 45587", "320806": "LURAGUNG -- 45581", "320807": "LEBAKWANGI -- 45574", "320808": "GARAWANGI -- 45571", "320809": "KUNINGAN -- 45514", "320810": "CIAWIGEBANG -- 45591", "320811": "CIDAHU -- 43358", "320812": "JALAKSANA -- 45554", "320813": "CILIMUS -- 45556", "320814": "MANDIRANCAN -- 45558", "320815": "SELAJAMBE -- 45566", "320816": "KRAMATMULYA -- 45553", "320817": "DARMA -- 45562", "320818": "CIGUGUR -- 45552", "320819": "PASAWAHAN -- 45559", "320820": "NUSAHERANG -- 45563", "320821": "CIPICUNG -- 45592", "320822": "PANCALANG -- 45557", "320823": "JAPARA -- 45555", "320824": "CIMAHI -- 40521", "320825": "CILEBAK -- 45585", "320826": "HANTARA -- 45564", "320827": "KALIMANGGIS -- 45594", "320828": "CIBEUREUM -- 46196", "320829": "KARANG KANCANA -- 45584", "320830": "MALEBER -- 45575", "320831": "SINDANG AGUNG -- 45573", "320832": "CIGANDAMEKAR -- 45556", "320901": "WALED -- 45187", "320902": "CILEDUG -- 45188", "320903": "LOSARI -- 45192", "320904": "PABEDILAN -- 45193", "320905": "BABAKAN -- 40223", "320906": "KARANGSEMBUNG -- 45186", "320907": "LEMAHABANG -- 45183", "320908": "SUSUKAN LEBAK -- 45185", "320909": "SEDONG -- 45189", "320910": "ASTANAJAPURA -- 45181", "320911": "PANGENAN -- 45182", "320912": "MUNDU -- 45173", "320913": "BEBER -- 45172", "320914": "TALUN -- 45171", "320915": "SUMBER -- 45612", "320916": "DUKUPUNTANG -- 45652", "320917": "PALIMANAN -- 45161", "320918": "PLUMBON -- 45155", "320919": "WERU -- 45154", "320920": "KEDAWUNG -- 45153", "320921": "GUNUNG JATI -- 45151", "320922": "KAPETAKAN -- 45152", "320923": "KLANGENAN -- 45156", "320924": "ARJAWINANGUN -- 45162", "320925": "PANGURAGAN -- 45163", "320926": "CIWARINGIN -- 45167", "320927": "SUSUKAN -- 45166", "320928": "GEGESIK -- 45164", "320929": "KALIWEDI -- 45165", "320930": "GEBANG -- 17151", "320931": "DEPOK -- 45155", "320932": "PASALEMAN -- 45187", "320933": "PABUARAN -- 41262", "320934": "KARANGWARENG -- 45186", "320935": "TENGAH TANI -- 45153", "320936": "PLERED -- 41162", "320937": "GEMPOL -- 45161", "320938": "GREGED -- 45172", "320939": "SURANENGGALA -- 45152", "320940": "JAMBLANG -- 45156", "321001": "LEMAHSUGIH -- 45465", "321002": "BANTARUJEG -- 45464", "321003": "CIKIJING -- 45466", "321004": "TALAGA -- 45463", "321005": "ARGAPURA -- 45462", "321006": "MAJA -- 16417", "321007": "MAJALENGKA -- 45419", "321008": "SUKAHAJI -- 45471", "321009": "RAJAGALUH -- 45472", "321010": "LEUWIMUNDING -- 45473", "321011": "JATIWANGI -- 45454", "321012": "DAWUAN -- 45453", "321013": "KADIPATEN -- 45452", "321014": "KERTAJATI -- 45457", "321015": "JATITUJUH -- 45458", "321016": "LIGUNG -- 45456", "321017": "SUMBERJAYA -- 45468", "321018": "PANYINGKIRAN -- 45459", "321019": "PALASAH -- 45475", "321020": "CIGASONG -- 45476", "321021": "SINDANGWANGI -- 45474", "321022": "BANJARAN -- 40377", "321023": "CINGAMBUL -- 45467", "321024": "KASOKANDEL -- 45453", "321025": "SINDANG -- 45227", "321026": "MALAUSMA -- 45464", "321101": "WADO -- 45373", "321102": "JATINUNGGAL -- 45376", "321103": "DARMARAJA -- 45372", "321104": "CIBUGEL -- 45375", "321105": "CISITU -- 45363", "321106": "SITURAJA -- 45371", "321107": "CONGGEANG -- 45391", "321108": "PASEH -- 45381", "321109": "SURIAN -- 45393", "321110": "BUAHDUA -- 45392", "321111": "TANJUNGSARI -- 16840", "321112": "SUKASARI -- 41254", "321113": "PAMULIHAN -- 45365", "321114": "CIMANGGUNG -- 45364", "321115": "JATINANGOR -- 45363", "321116": "RANCAKALONG -- 45361", "321117": "SUMEDANG SELATAN -- 45311", "321118": "SUMEDANG UTARA -- 45321", "321119": "GANEAS -- 45356", "321120": "TANJUNGKERTA -- 45354", "321121": "TANJUNGMEDAR -- 45354", "321122": "CIMALAKA -- 45353", "321123": "CISARUA -- 45355", "321124": "TOMO -- 45382", "321125": "UJUNGJAYA -- 45383", "321126": "JATIGEDE -- 45377", "321201": "HAURGEULIS -- 45264", "321202": "KROYA -- 45265", "321203": "GABUSWETAN -- 45263", "321204": "CIKEDUNG -- 45262", "321205": "LELEA -- 45261", "321206": "BANGODUA -- 45272", "321207": "WIDASARI -- 45271", "321208": "KERTASEMAYA -- 45274", "321209": "KRANGKENG -- 45284", "321210": "KARANGAMPEL -- 45283", "321211": "JUNTINYUAT -- 45282", "321212": "SLIYEG -- 45281", "321213": "JATIBARANG -- 45273", "321214": "BALONGAN -- 45217", "321215": "INDRAMAYU -- 45214", "321216": "SINDANG -- 45227", "321217": "CANTIGI -- 45258", "321218": "LOHBENER -- 45252", "321219": "ARAHAN -- 45365", "321220": "LOSARANG -- 45253", "321221": "KANDANGHAUR -- 45254", "321222": "BONGAS -- 45255", "321223": "ANJATAN -- 45256", "321224": "SUKRA -- 45257", "321225": "GANTAR -- 45264", "321226": "TRISI -- 45262", "321227": "SUKAGUMIWANG -- 45274", "321228": "KEDOKAN BUNDER -- 45283", "321229": "PASEKAN -- 45219", "321230": "TUKDANA -- 45272", "321231": "PATROL -- 45257", "321301": "SAGALAHERANG -- 41282", "321302": "CISALAK -- 41283", "321303": "SUBANG -- 45586", "321304": "KALIJATI -- 41271", "321305": "PABUARAN -- 41262", "321306": "PURWADADI -- 46385", "321307": "PAGADEN -- 41252", "321308": "BINONG -- 43271", "321309": "CIASEM -- 41256", "321310": "PUSAKANAGARA -- 41255", "321311": "PAMANUKAN -- 41254", "321312": "JALANCAGAK -- 41281", "321313": "BLANAKAN -- 41259", "321314": "TANJUNGSIANG -- 41284", "321315": "COMPRENG -- 41258", "321316": "PATOKBEUSI -- 41263", "321317": "CIBOGO -- 41285", "321318": "CIPUNAGARA -- 41257", "321319": "CIJAMBE -- 41286", "321320": "CIPEUNDUEY -- -", "321321": "LEGONKULON -- 41254", "321322": "CIKAUM -- 41253", "321323": "SERANGPANJANG -- 41282", "321324": "SUKASARI -- 41254", "321325": "TAMBAKDAHAN -- 41253", "321326": "KASOMALANG -- 41283", "321327": "DAWUAN -- 45453", "321328": "PAGADEN BARAT -- 41252", "321329": "CIATER -- 41281", "321330": "PUSAKAJAYA -- 41255", "321401": "PURWAKARTA -- 41113", "321402": "CAMPAKA -- 41181", "321403": "JATILUHUR -- 41161", "321404": "PLERED -- 41162", "321405": "SUKATANI -- 17630", "321406": "DARANGDAN -- 41163", "321407": "MANIIS -- 41166", "321408": "TEGALWARU -- 41165", "321409": "WANAYASA -- 41174", "321410": "PASAWAHAN -- 45559", "321411": "BOJONG -- 40232", "321412": "BABAKANCIKAO -- 41151", "321413": "BUNGURSARI -- 46151", "321414": "CIBATU -- 44185", "321415": "SUKASARI -- 41254", "321416": "PONDOKSALAM -- 41115", "321417": "KIARAPEDES -- 41175", "321501": "KARAWANG BARAT -- 41311", "321502": "PANGKALAN -- 41362", "321503": "TELUKJAMBE TIMUR -- 41361", "321504": "CIAMPEL -- 41363", "321505": "KLARI -- 41371", "321506": "RENGASDENGKLOK -- 41352", "321507": "KUTAWALUYA -- 41358", "321508": "BATUJAYA -- 41354", "321509": "TIRTAJAYA -- 41357", "321510": "PEDES -- 43194", "321511": "CIBUAYA -- 41356", "321512": "PAKISJAYA -- 41355", "321513": "CIKAMPEK -- 41373", "321514": "JATISARI -- 41374", "321515": "CILAMAYA WETAN -- 41384", "321516": "TIRTAMULYA -- 41372", "321517": "TELAGASARI -- -", "321518": "RAWAMERTA -- 41382", "321519": "LEMAHABANG -- 45183", "321520": "TEMPURAN -- 41385", "321521": "MAJALAYA -- 41371", "321522": "JAYAKERTA -- 41352", "321523": "CILAMAYA KULON -- 41384", "321524": "BANYUSARI -- 41374", "321525": "KOTA BARU -- 41374", "321526": "KARAWANG TIMUR -- 41314", "321527": "TELUKJAMBE BARAT -- 41361", "321528": "TEGALWARU -- 41165", "321529": "PURWASARI -- 41373", "321530": "CILEBAR -- 41353", "321601": "TARUMAJAYA -- 17216", "321602": "BABELAN -- 17610", "321603": "SUKAWANGI -- 17620", "321604": "TAMBELANG -- 17620", "321605": "TAMBUN UTARA -- 17510", "321606": "TAMBUN SELATAN -- 17510", "321607": "CIBITUNG -- 43172", "321608": "CIKARANG BARAT -- 17530", "321609": "CIKARANG UTARA -- 17530", "321610": "KARANG BAHAGIA -- 17530", "321611": "CIKARANG TIMUR -- 17530", "321612": "KEDUNG WARINGIN -- 17540", "321613": "PEBAYURAN -- 17710", "321614": "SUKAKARYA -- 17630", "321615": "SUKATANI -- 17630", "321616": "CABANGBUNGIN -- 17720", "321617": "MUARAGEMBONG -- 17730", "321618": "SETU -- 17320", "321619": "CIKARANG SELATAN -- 17530", "321620": "CIKARANG PUSAT -- 17530", "321621": "SERANG BARU -- 17330", "321622": "CIBARUSAH -- 17340", "321623": "BOJONGMANGU -- 17352", "321701": "LEMBANG -- 40391", "321702": "PARONGPONG -- 40559", "321703": "CISARUA -- 45355", "321704": "CIKALONGWETAN -- 40556", "321705": "CIPEUNDEUY -- 41272", "321706": "NGAMPRAH -- 40552", "321707": "CIPATAT -- 40554", "321708": "PADALARANG -- 40553", "321709": "BATUJAJAR -- 40561", "321710": "CIHAMPELAS -- 40562", "321711": "CILILIN -- 40562", "321712": "CIPONGKOR -- 40564", "321713": "RONGGA -- 40566", "321714": "SINDANGKERTA -- 40563", "321715": "GUNUNGHALU -- 40565", "321716": "SAGULING -- 40561", "321801": "PARIGI -- 46393", "321802": "CIJULANG -- 46394", "321803": "CIMERAK -- 46395", "321804": "CIGUGUR -- 45552", "321805": "LANGKAPLANCAR -- 46391", "321806": "MANGUNJAYA -- 46371", "321807": "PADAHERANG -- 46384", "321808": "KALIPUCANG -- 46397", "321809": "PANGANDARAN -- 46396", "321810": "SIDAMULIH -- 46365", "327101": "BOGOR SELATAN -- 16133", "327102": "BOGOR TIMUR -- 16143", "327103": "BOGOR TENGAH -- 16126", "327104": "BOGOR BARAT -- 16116", "327105": "BOGOR UTARA -- 16153", "327106": "TANAH SAREAL -- -", "327201": "GUNUNG PUYUH -- 43123", "327202": "CIKOLE -- 43113", "327203": "CITAMIANG -- 43142", "327204": "WARUDOYONG -- 43132", "327205": "BAROS -- 43161", "327206": "LEMBURSITU -- 43168", "327207": "CIBEUREUM -- 46196", "327301": "SUKASARI -- 41254", "327302": "COBLONG -- 40131", "327303": "BABAKAN CIPARAY -- 40223", "327304": "BOJONGLOA KALER -- 40232", "327305": "ANDIR -- 40184", "327306": "CICENDO -- 40172", "327307": "SUKAJADI -- 40162", "327308": "CIDADAP -- 43183", "327309": "BANDUNG WETAN -- 40114", "327310": "ASTANA ANYAR -- 40241", "327311": "REGOL -- 40254", "327312": "BATUNUNGGAL -- 40275", "327313": "LENGKONG -- 40262", "327314": "CIBEUNYING KIDUL -- 40121", "327315": "BANDUNG KULON -- 40212", "327316": "KIARACONDONG -- 40283", "327317": "BOJONGLOA KIDUL -- 40239", "327318": "CIBEUNYING KALER -- 40191", "327319": "SUMUR BANDUNG -- 40117", "327320": "ANTAPANI -- 40291", "327321": "BANDUNG KIDUL -- 40266", "327322": "BUAHBATU -- 40287", "327323": "RANCASARI -- 40292", "327324": "ARCAMANIK -- 40293", "327325": "CIBIRU -- 40614", "327326": "UJUNG BERUNG -- 40611", "327327": "GEDEBAGE -- 40294", "327328": "PANYILEUKAN -- 40614", "327329": "CINAMBO -- 40294", "327330": "MANDALAJATI -- 40195", "327401": "KEJAKSAN -- 45121", "327402": "LEMAH WUNGKUK -- 45114", "327403": "HARJAMUKTI -- 45145", "327404": "PEKALIPAN -- 45115", "327405": "KESAMBI -- 45133", "327501": "BEKASI TIMUR -- 17111", "327502": "BEKASI BARAT -- 17136", "327503": "BEKASI UTARA -- 17123", "327504": "BEKASI SELATAN -- 17146", "327505": "RAWA LUMBU -- 17117", "327506": "MEDAN SATRIA -- 17143", "327507": "BANTAR GEBANG -- 17151", "327508": "PONDOK GEDE -- 17412", "327509": "JATIASIH -- 17422", "327510": "JATI SEMPURNA -- -", "327511": "MUSTIKA JAYA -- 17155", "327512": "PONDOK MELATI -- 17414", "327601": "PANCORAN MAS -- 16432", "327602": "CIMANGGIS -- 16452", "327603": "SAWANGAN -- 16519", "327604": "LIMO -- 16512", "327605": "SUKMAJAYA -- 16417", "327606": "BEJI -- 16422", "327607": "CIPAYUNG -- 16436", "327608": "CILODONG -- 16414", "327609": "CINERE -- 16514", "327610": "TAPOS -- 16458", "327611": "BOJONGSARI -- 16516", "327701": "CIMAHI SELATAN -- 40531", "327702": "CIMAHI TENGAH -- 40521", "327703": "CIMAHI UTARA -- 40513", "327801": "CIHIDEUNG -- 46122", "327802": "CIPEDES -- 46133", "327803": "TAWANG -- 46114", "327804": "INDIHIANG -- 46151", "327805": "KAWALU -- 46182", "327806": "CIBEUREUM -- 46196", "327807": "TAMANSARI -- 46196", "327808": "MANGKUBUMI -- 46181", "327809": "BUNGURSARI -- 46151", "327810": "PURBARATU -- 46196", "327901": "BANJAR -- 46312", "327902": "PATARUMAN -- 46326", "327903": "PURWAHARJA -- 46332", "327904": "LANGENSARI -- 46325", "330101": "KEDUNGREJA -- 53263", "330102": "KESUGIHAN -- 53274", "330103": "ADIPALA -- 53271", "330104": "BINANGUN -- 53281", "330105": "NUSAWUNGU -- 53283", "330106": "KROYA -- 53282", "330107": "MAOS -- 53272", "330108": "JERUKLEGI -- 53252", "330109": "KAWUNGANTEN -- 53253", "330110": "GANDRUNGMANGU -- 53254", "330111": "SIDAREJA -- 53261", "330112": "KARANGPUCUNG -- 53255", "330113": "CIMANGGU -- 53256", "330114": "MAJENANG -- 53257", "330115": "WANAREJA -- 53265", "330116": "DAYEUHLUHUR -- 53266", "330117": "SAMPANG -- 53273", "330118": "CIPARI -- 53262", "330119": "PATIMUAN -- 53264", "330120": "BANTARSARI -- 53281", "330121": "CILACAP SELATAN -- 53211", "330122": "CILACAP TENGAH -- 53222", "330123": "CILACAP UTARA -- 53231", "330124": "KAMPUNG LAUT -- 53253", "330201": "LUMBIR -- 53177", "330202": "WANGON -- 53176", "330203": "JATILAWANG -- 53174", "330204": "RAWALO -- 53173", "330205": "KEBASEN -- 53172", "330206": "KEMRANJEN -- 53194", "330207": "SUMPIUH -- 53195", "330208": "TAMBAK -- 59174", "330209": "SOMAGEDE -- 53193", "330210": "KALIBAGOR -- 53191", "330211": "BANYUMAS -- 53192", "330212": "PATIKRAJA -- 53171", "330213": "PURWOJATI -- 53175", "330214": "AJIBARANG -- 53163", "330215": "GUMELAR -- 53165", "330216": "PEKUNCEN -- 53164", "330217": "CILONGOK -- 53162", "330218": "KARANGLEWAS -- 53161", "330219": "SOKARAJA -- 53181", "330220": "KEMBARAN -- 53182", "330221": "SUMBANG -- 53183", "330222": "BATURRADEN -- -", "330223": "KEDUNGBANTENG -- 53152", "330224": "PURWOKERTO SELATAN -- 53146", "330225": "PURWOKERTO BARAT -- 53133", "330226": "PURWOKERTO TIMUR -- 53113", "330227": "PURWOKERTO UTARA -- 53121", "330301": "KEMANGKON -- 53381", "330302": "BUKATEJA -- 53382", "330303": "KEJOBONG -- 53392", "330304": "KALIGONDANG -- 53391", "330305": "PURBALINGGA -- 53316", "330306": "KALIMANAH -- 53371", "330307": "KUTASARI -- 53361", "330308": "MREBET -- 53352", "330309": "BOBOTSARI -- 53353", "330310": "KARANGREJA -- 53357", "330311": "KARANGANYAR -- 59582", "330312": "KARANGMONCOL -- 53355", "330313": "REMBANG -- 53356", "330314": "BOJONGSARI -- 53362", "330315": "PADAMARA -- 53372", "330316": "PENGADEGAN -- 53393", "330317": "KARANGJAMBU -- 53357", "330318": "KERTANEGARA -- 53354", "330401": "SUSUKAN -- 50777", "330402": "PURWOREJA KLAMPOK -- -", "330403": "MANDIRAJA -- 53473", "330404": "PURWANEGARA -- -", "330405": "BAWANG -- 53471", "330406": "BANJARNEGARA -- 53418", "330407": "SIGALUH -- 53481", "330408": "MADUKARA -- 53482", "330409": "BANJARMANGU -- 53452", "330410": "WANADADI -- 53461", "330411": "RAKIT -- 53463", "330412": "PUNGGELAN -- 53462", "330413": "KARANGKOBAR -- 53453", "330414": "PAGENTAN -- 53455", "330415": "PEJAWARAN -- 53454", "330416": "BATUR -- 53456", "330417": "WANAYASA -- 53457", "330418": "KALIBENING -- 53458", "330419": "PANDANARUM -- 53458", "330420": "PAGEDONGAN -- 53418", "330501": "AYAH -- 54473", "330502": "BUAYAN -- 54474", "330503": "PURING -- 54383", "330504": "PETANAHAN -- 54382", "330505": "KLIRONG -- 54381", "330506": "BULUSPESANTREN -- 54391", "330507": "AMBAL -- 54392", "330508": "MIRIT -- 54395", "330509": "PREMBUN -- 54394", "330510": "KUTOWINANGUN -- 54393", "330511": "ALIAN -- 56153", "330512": "KEBUMEN -- 54317", "330513": "PEJAGOAN -- 54361", "330514": "SRUWENG -- 54362", "330515": "ADIMULYO -- 54363", "330516": "KUWARASAN -- 54366", "330517": "ROWOKELE -- 54472", "330518": "SEMPOR -- 54421", "330519": "GOMBONG -- 54416", "330520": "KARANGANYAR -- 59582", "330521": "KARANGGAYAM -- 54365", "330522": "SADANG -- 54353", "330523": "BONOROWO -- 54395", "330524": "PADURESO -- 54394", "330525": "PONCOWARNO -- 54393", "330526": "KARANGSAMBUNG -- 54353", "330601": "GRABAG -- 54265", "330602": "NGOMBOL -- 54172", "330603": "PURWODADI -- 54173", "330604": "BAGELEN -- 54174", "330605": "KALIGESING -- 54175", "330606": "PURWOREJO -- 54118", "330607": "BANYUURIP -- 54171", "330608": "BAYAN -- 54224", "330609": "KUTOARJO -- 54211", "330610": "BUTUH -- 54264", "330611": "PITURUH -- 54263", "330612": "KEMIRI -- 54262", "330613": "BRUNO -- 54261", "330614": "GEBANG -- 54191", "330615": "LOANO -- 54181", "330616": "BENER -- 54183", "330701": "WADASLINTANG -- 56365", "330702": "KEPIL -- 56374", "330703": "SAPURAN -- 56373", "330704": "KALIWIRO -- 56364", "330705": "LEKSONO -- 56362", "330706": "SELOMERTO -- 56361", "330707": "KALIKAJAR -- 56372", "330708": "KERTEK -- 56371", "330709": "WONOSOBO -- 56318", "330710": "WATUMALANG -- 56352", "330711": "MOJOTENGAH -- 56351", "330712": "GARUNG -- 56353", "330713": "KEJAJAR -- 56354", "330714": "SUKOHARJO -- 57551", "330715": "KALIBAWANG -- 56373", "330801": "SALAMAN -- 56162", "330802": "BOROBUDUR -- 56553", "330803": "NGLUWAR -- 56485", "330804": "SALAM -- 56162", "330805": "SRUMBUNG -- 56483", "330806": "DUKUN -- 56482", "330807": "SAWANGAN -- 56481", "330808": "MUNTILAN -- 56415", "330809": "MUNGKID -- 56512", "330810": "MERTOYUDAN -- 56172", "330811": "TEMPURAN -- 56161", "330812": "KAJORAN -- 56163", "330813": "KALIANGKRIK -- 56153", "330814": "BANDONGAN -- 56151", "330815": "CANDIMULYO -- 56191", "330816": "PAKIS -- 56193", "330817": "NGABLAK -- 56194", "330818": "GRABAG -- 54265", "330819": "TEGALREJO -- 56192", "330820": "SECANG -- 56195", "330821": "WINDUSARI -- 56152", "330901": "SELO -- 56361", "330902": "AMPEL -- 52364", "330903": "CEPOGO -- 57362", "330904": "MUSUK -- 57331", "330905": "BOYOLALI -- 57313", "330906": "MOJOSONGO -- 57322", "330907": "TERAS -- 57372", "330908": "SAWIT -- 57374", "330909": "BANYUDONO -- 57373", "330910": "SAMBI -- 57376", "330911": "NGEMPLAK -- 57375", "330912": "NOGOSARI -- 57378", "330913": "SIMO -- 57377", "330914": "KARANGGEDE -- 57381", "330915": "KLEGO -- 57385", "330916": "ANDONG -- 57384", "330917": "KEMUSU -- 57383", "330918": "WONOSEGORO -- 57382", "330919": "JUWANGI -- 57391", "331001": "PRAMBANAN -- 57454", "331002": "GANTIWARNO -- 57455", "331003": "WEDI -- 57461", "331004": "BAYAT -- 57462", "331005": "CAWAS -- 57463", "331006": "TRUCUK -- 57467", "331007": "KEBONARUM -- 57486", "331008": "JOGONALAN -- 57452", "331009": "MANISRENGGO -- 57485", "331010": "KARANGNONGKO -- 57483", "331011": "CEPER -- 57465", "331012": "PEDAN -- 57468", "331013": "KARANGDOWO -- 57464", "331014": "JUWIRING -- 57472", "331015": "WONOSARI -- 57473", "331016": "DELANGGU -- 57471", "331017": "POLANHARJO -- 57474", "331018": "KARANGANOM -- 57475", "331019": "TULUNG -- 57482", "331020": "JATINOM -- 57481", "331021": "KEMALANG -- 57484", "331022": "NGAWEN -- 58254", "331023": "KALIKOTES -- 57451", "331024": "KLATEN UTARA -- 57438", "331025": "KLATEN TENGAH -- 57414", "331026": "KLATEN SELATAN -- 57425", "331101": "WERU -- 57562", "331102": "BULU -- 54391", "331103": "TAWANGSARI -- 57561", "331104": "SUKOHARJO -- 57551", "331105": "NGUTER -- 57571", "331106": "BENDOSARI -- 57528", "331107": "POLOKARTO -- 57555", "331108": "MOJOLABAN -- 57554", "331109": "GROGOL -- 57552", "331110": "BAKI -- 57556", "331111": "GATAK -- 57557", "331112": "KARTASURA -- 57169", "331201": "PRACIMANTORO -- 57664", "331202": "GIRITONTRO -- 57678", "331203": "GIRIWOYO -- 57675", "331204": "BATUWARNO -- 57674", "331205": "TIRTOMOYO -- 57672", "331206": "NGUNTORONADI -- 57671", "331207": "BATURETNO -- 57673", "331208": "EROMOKO -- 57663", "331209": "WURYANTORO -- 57661", "331210": "MANYARAN -- 57662", "331211": "SELOGIRI -- 57652", "331212": "WONOGIRI -- 57615", "331213": "NGADIROJO -- 57681", "331214": "SIDOHARJO -- 57281", "331215": "JATIROTO -- 57692", "331216": "KISMANTORO -- 57696", "331217": "PURWANTORO -- 57695", "331218": "BULUKERTO -- 57697", "331219": "SLOGOHIMO -- 57694", "331220": "JATISRONO -- 57691", "331221": "JATIPURNO -- 57693", "331222": "GIRIMARTO -- 57683", "331223": "KARANGTENGAH -- 59561", "331224": "PARANGGUPITO -- 57678", "331225": "PUHPELEM -- 57698", "331301": "JATIPURO -- 57784", "331302": "JATIYOSO -- 57785", "331303": "JUMAPOLO -- 57783", "331304": "JUMANTONO -- 57782", "331305": "MATESIH -- 57781", "331306": "TAWANGMANGU -- 57792", "331307": "NGARGOYOSO -- 57793", "331308": "KARANGPANDAN -- 57791", "331309": "KARANGANYAR -- 59582", "331310": "TASIKMADU -- 57722", "331311": "JATEN -- 57731", "331312": "COLOMADU -- 57171", "331313": "GONDANGREJO -- 57188", "331314": "KEBAKKRAMAT -- 57762", "331315": "MOJOGEDANG -- 57752", "331316": "KERJO -- 57753", "331317": "JENAWI -- 57794", "331401": "KALIJAMBE -- 57275", "331402": "PLUPUH -- 57283", "331403": "MASARAN -- 57282", "331404": "KEDAWUNG -- 57292", "331405": "SAMBIREJO -- 57293", "331406": "GONDANG -- 53391", "331407": "SAMBUNGMACAN -- 57253", "331408": "NGRAMPAL -- 57252", "331409": "KARANGMALANG -- 57222", "331410": "SRAGEN -- 57216", "331411": "SIDOHARJO -- 57281", "331412": "TANON -- 57277", "331413": "GEMOLONG -- 57274", "331414": "MIRI -- 57276", "331415": "SUMBERLAWANG -- 57272", "331416": "MONDOKAN -- 57271", "331417": "SUKODONO -- 57263", "331418": "GESI -- 57262", "331419": "TANGEN -- 57261", "331420": "JENAR -- 57256", "331501": "KEDUNGJATI -- 58167", "331502": "KARANGRAYUNG -- 58163", "331503": "PENAWANGAN -- 58161", "331504": "TOROH -- 58171", "331505": "GEYER -- 58172", "331506": "PULOKULON -- 58181", "331507": "KRADENAN -- 58182", "331508": "GABUS -- 59173", "331509": "NGARINGAN -- 58193", "331510": "WIROSARI -- 58192", "331511": "TAWANGHARJO -- 58191", "331512": "GROBOGAN -- 58152", "331513": "PURWODADI -- 54173", "331514": "BRATI -- 58153", "331515": "KLAMBU -- 58154", "331516": "GODONG -- 58162", "331517": "GUBUG -- 58164", "331518": "TEGOWANU -- 58165", "331519": "TANGGUNGHARJO -- 58166", "331601": "JATI -- 53174", "331602": "RANDUBLATUNG -- 58382", "331603": "KRADENAN -- 58182", "331604": "KEDUNGTUBAN -- 58381", "331605": "CEPU -- 58311", "331606": "SAMBONG -- 58371", "331607": "JIKEN -- 58372", "331608": "JEPON -- 58261", "331609": "BLORA -- 58219", "331610": "TUNJUNGAN -- 58252", "331611": "BANJAREJO -- 58253", "331612": "NGAWEN -- 58254", "331613": "KUNDURAN -- 58255", "331614": "TODANAN -- 58256", "331615": "BOGOREJO -- 58262", "331616": "JAPAH -- 58257", "331701": "SUMBER -- 59253", "331702": "BULU -- 54391", "331703": "GUNEM -- 59263", "331704": "SALE -- 59265", "331705": "SARANG -- 59274", "331706": "SEDAN -- 59264", "331707": "PAMOTAN -- 59261", "331708": "SULANG -- 59254", "331709": "KALIORI -- 59252", "331710": "REMBANG -- 53356", "331711": "PANCUR -- 59262", "331712": "KRAGAN -- 59273", "331713": "SLUKE -- 59272", "331714": "LASEM -- 59271", "331801": "SUKOLILO -- 59172", "331802": "KAYEN -- 59171", "331803": "TAMBAKROMO -- 59174", "331804": "WINONG -- 59181", "331805": "PUCAKWANGI -- 59183", "331806": "JAKEN -- 59184", "331807": "BATANGAN -- 59186", "331808": "JUWANA -- 59185", "331809": "JAKENAN -- 59182", "331810": "PATI -- 59114", "331811": "GABUS -- 59173", "331812": "MARGOREJO -- 59163", "331813": "GEMBONG -- 59162", "331814": "TLOGOWUNGU -- 59161", "331815": "WEDARIJAKSA -- 59152", "331816": "MARGOYOSO -- 59154", "331817": "GUNUNGWUNGKAL -- 59156", "331818": "CLUWAK -- 59157", "331819": "TAYU -- 59155", "331820": "DUKUHSETI -- 59158", "331821": "TRANGKIL -- 59153", "331901": "KALIWUNGU -- 59332", "331902": "KOTA KUDUS -- -", "331903": "JATI -- 53174", "331904": "UNDAAN -- 59372", "331905": "MEJOBO -- 59381", "331906": "JEKULO -- 59382", "331907": "BAE -- 59325", "331908": "GEBOG -- 59333", "331909": "DAWE -- 59353", "332001": "KEDUNG -- 51173", "332002": "PECANGAAN -- 59462", "332003": "WELAHAN -- 59464", "332004": "MAYONG -- 59465", "332005": "BATEALIT -- 59461", "332006": "JEPARA -- 59432", "332007": "MLONGGO -- 59452", "332008": "BANGSRI -- 59453", "332009": "KELING -- 59454", "332010": "KARIMUN JAWA -- 59455", "332011": "TAHUNAN -- 59422", "332012": "NALUMSARI -- 59466", "332013": "KALINYAMATAN -- 59462", "332014": "KEMBANG -- 59453", "332015": "PAKIS AJI -- 59452", "332016": "DONOROJO -- 59454", "332101": "MRANGGEN -- 59567", "332102": "KARANGAWEN -- 59566", "332103": "GUNTUR -- 59565", "332104": "SAYUNG -- 59563", "332105": "KARANGTENGAH -- 59561", "332106": "WONOSALAM -- 59571", "332107": "DEMPET -- 59573", "332108": "GAJAH -- 59581", "332109": "KARANGANYAR -- 59582", "332110": "MIJEN -- 59583", "332111": "DEMAK -- 59517", "332112": "BONANG -- 59552", "332113": "WEDUNG -- 59554", "332114": "KEBONAGUNG -- 59583", "332201": "GETASAN -- 50774", "332202": "TENGARAN -- 50775", "332203": "SUSUKAN -- 50777", "332204": "SURUH -- 50776", "332205": "PABELAN -- 50771", "332206": "TUNTANG -- 50773", "332207": "BANYUBIRU -- 50664", "332208": "JAMBU -- 50663", "332209": "SUMOWONO -- 50662", "332210": "AMBARAWA -- 50614", "332211": "BAWEN -- 50661", "332212": "BRINGIN -- 50772", "332213": "BERGAS -- 50552", "332215": "PRINGAPUS -- 50214", "332216": "BANCAK -- 50182", "332217": "KALIWUNGU -- 59332", "332218": "UNGARAN BARAT -- 50517", "332219": "UNGARAN TIMUR -- 50519", "332220": "BANDUNGAN -- 50614", "332301": "BULU -- 54391", "332302": "TEMBARAK -- 56261", "332303": "TEMANGGUNG -- 56211", "332304": "PRINGSURAT -- 56272", "332305": "KALORAN -- 56282", "332306": "KANDANGAN -- 56281", "332307": "KEDU -- 51173", "332308": "PARAKAN -- 56254", "332309": "NGADIREJO -- 56255", "332310": "JUMO -- 56256", "332311": "TRETEP -- 56259", "332312": "CANDIROTO -- 56257", "332313": "KRANGGAN -- 56271", "332314": "TLOGOMULYO -- 56263", "332315": "SELOPAMPANG -- 56262", "332316": "BANSARI -- 56265", "332317": "KLEDUNG -- 56264", "332318": "BEJEN -- 56258", "332319": "WONOBOYO -- 56266", "332320": "GEMAWANG -- 56283", "332401": "PLANTUNGAN -- 51362", "332402": "PAGERUYUNG -- -", "332403": "SUKOREJO -- 51363", "332404": "PATEAN -- 51364", "332405": "SINGOROJO -- 51382", "332406": "LIMBANGAN -- 51383", "332407": "BOJA -- 51381", "332408": "KALIWUNGU -- 59332", "332409": "BRANGSONG -- 51371", "332410": "PEGANDON -- 51357", "332411": "GEMUH -- 51356", "332412": "WELERI -- 51355", "332413": "CEPIRING -- 51352", "332414": "PATEBON -- 51351", "332415": "KENDAL -- 51312", "332416": "ROWOSARI -- 51354", "332417": "KANGKUNG -- 51353", "332418": "RINGINARUM -- 51356", "332419": "NGAMPEL -- 51357", "332420": "KALIWUNGU SELATAN -- 51372", "332501": "WONOTUNGGAL -- 51253", "332502": "BANDAR -- 51254", "332503": "BLADO -- 51255", "332504": "REBAN -- 51273", "332505": "BAWANG -- 53471", "332506": "TERSONO -- 51272", "332507": "GRINGSING -- 51281", "332508": "LIMPUNG -- 51271", "332509": "SUBAH -- 51262", "332510": "TULIS -- 51261", "332511": "BATANG -- 59186", "332512": "WARUNGASEM -- 51252", "332513": "KANDEMAN -- 51261", "332514": "PECALUNGAN -- 51262", "332515": "BANYUPUTIH -- 51281", "332601": "KANDANGSERANG -- 51163", "332602": "PANINGGARAN -- 51164", "332603": "LEBAKBARANG -- 51183", "332604": "PETUNGKRIYONO -- 51193", "332605": "TALUN -- 51192", "332606": "DORO -- 51191", "332607": "KARANGANYAR -- 59582", "332608": "KAJEN -- 51161", "332609": "KESESI -- 51162", "332610": "SRAGI -- 51155", "332611": "BOJONG -- 51156", "332612": "WONOPRINGGO -- 51181", "332613": "KEDUNGWUNI -- 51173", "332614": "BUARAN -- 51171", "332615": "TIRTO -- 57672", "332616": "WIRADESA -- 51152", "332617": "SIWALAN -- 51137", "332618": "KARANGDADAP -- 51174", "332619": "WONOKERTO -- 51153", "332701": "MOGA -- 52354", "332702": "PULOSARI -- 52355", "332703": "BELIK -- 52356", "332704": "WATUKUMPUL -- 52357", "332705": "BODEH -- 52365", "332706": "BANTARBOLANG -- 52352", "332707": "RANDUDONGKAL -- 52353", "332708": "PEMALANG -- 52319", "332709": "TAMAN -- 52361", "332710": "PETARUKAN -- 52362", "332711": "AMPELGADING -- 52364", "332712": "COMAL -- 52363", "332713": "ULUJAMI -- 52371", "332714": "WARUNGPRING -- 52354", "332801": "MARGASARI -- 52463", "332802": "BUMIJAWA -- 52466", "332803": "BOJONG -- 51156", "332804": "BALAPULANG -- 52464", "332805": "PAGERBARANG -- 52462", "332806": "LEBAKSIU -- 52461", "332807": "JATINEGARA -- 52473", "332808": "KEDUNGBANTENG -- 53152", "332809": "PANGKAH -- 52471", "332810": "SLAWI -- 52419", "332811": "ADIWERNA -- 52194", "332812": "TALANG -- 52193", "332813": "DUKUHTURI -- 52192", "332814": "TARUB -- 52184", "332815": "KRAMAT -- 57762", "332816": "SURADADI -- -", "332817": "WARUREJA -- -", "332818": "DUKUHWARU -- 52451", "332901": "SALEM -- 52275", "332902": "BANTARKAWUNG -- 52274", "332903": "BUMIAYU -- 52273", "332904": "PAGUYANGAN -- 52276", "332905": "SIRAMPOG -- 52272", "332906": "TONJONG -- 52271", "332907": "JATIBARANG -- 52261", "332908": "WANASARI -- 52252", "332909": "BREBES -- 52216", "332910": "SONGGOM -- 52266", "332911": "KERSANA -- 52264", "332912": "LOSARI -- 52255", "332913": "TANJUNG -- 52254", "332914": "BULAKAMBA -- 52253", "332915": "LARANGAN -- 52262", "332916": "KETANGGUNGAN -- 52263", "332917": "BANJARHARJO -- 52265", "337101": "MAGELANG SELATAN -- 56123", "337102": "MAGELANG UTARA -- 56114", "337103": "MAGELANG TENGAH -- 56121", "337201": "LAWEYAN -- 57149", "337202": "SERENGAN -- 57156", "337203": "PASAR KLIWON -- 57144", "337204": "JEBRES -- 57122", "337205": "BANJARSARI -- 57137", "337301": "SIDOREJO -- 50715", "337302": "TINGKIR -- 50743", "337303": "ARGOMULYO -- 50736", "337304": "SIDOMUKTI -- 50722", "337401": "SEMARANG TENGAH -- 50138", "337402": "SEMARANG UTARA -- 50175", "337403": "SEMARANG TIMUR -- 50126", "337404": "GAYAMSARI -- 50248", "337405": "GENUK -- 50115", "337406": "PEDURUNGAN -- 50246", "337407": "SEMARANG SELATAN -- 50245", "337408": "CANDISARI -- 50257", "337409": "GAJAHMUNGKUR -- 50235", "337410": "TEMBALANG -- 50277", "337411": "BANYUMANIK -- 50264", "337412": "GUNUNGPATI -- 50223", "337413": "SEMARANG BARAT -- 50141", "337414": "MIJEN -- 59583", "337415": "NGALIYAN -- 50211", "337416": "TUGU -- 50151", "337501": "PEKALONGAN BARAT -- 51119", "337502": "PEKALONGAN TIMUR -- 51129", "337503": "PEKALONGAN UTARA -- 51143", "337504": "PEKALONGAN SELATAN -- 51139", "337601": "TEGAL BARAT -- 52115", "337602": "TEGAL TIMUR -- 52124", "337603": "TEGAL SELATAN -- 52137", "337604": "MARGADANA -- 52147", "340101": "TEMON -- 55654", "340102": "WATES -- 55651", "340103": "PANJATAN -- 55655", "340104": "GALUR -- 55661", "340105": "LENDAH -- 55663", "340106": "SENTOLO -- 55664", "340107": "PENGASIH -- 55652", "340108": "KOKAP -- 55653", "340109": "GIRIMULYO -- 55674", "340110": "NANGGULAN -- 55671", "340111": "SAMIGALUH -- 55673", "340112": "KALIBAWANG -- 55672", "340201": "SRANDAKAN -- 55762", "340202": "SANDEN -- 55763", "340203": "KRETEK -- 55772", "340204": "PUNDONG -- 55771", "340205": "BAMBANG LIPURO -- 55764", "340206": "PANDAK -- 55761", "340207": "PAJANGAN -- 55751", "340208": "BANTUL -- 55711", "340209": "JETIS -- 55231", "340210": "IMOGIRI -- 55782", "340211": "DLINGO -- 55783", "340212": "BANGUNTAPAN -- 55198", "340213": "PLERET -- 55791", "340214": "PIYUNGAN -- 55792", "340215": "SEWON -- 55188", "340216": "KASIHAN -- 55184", "340217": "SEDAYU -- 55752", "340301": "WONOSARI -- 55811", "340302": "NGLIPAR -- 55852", "340303": "PLAYEN -- 55861", "340304": "PATUK -- 55862", "340305": "PALIYAN -- 55871", "340306": "PANGGANG -- 55872", "340307": "TEPUS -- 55881", "340308": "SEMANU -- 55893", "340309": "KARANGMOJO -- 55891", "340310": "PONJONG -- 55892", "340311": "RONGKOP -- 55883", "340312": "SEMIN -- 55854", "340313": "NGAWEN -- 55853", "340314": "GEDANGSARI -- 55863", "340315": "SAPTOSARI -- 55871", "340316": "GIRISUBO -- 55883", "340317": "TANJUNGSARI -- 55881", "340318": "PURWOSARI -- 55872", "340401": "GAMPING -- 55294", "340402": "GODEAN -- 55264", "340403": "MOYUDAN -- 55563", "340404": "MINGGIR -- 55562", "340405": "SEYEGAN -- 55561", "340406": "MLATI -- 55285", "340407": "DEPOK -- 55281", "340408": "BERBAH -- 55573", "340409": "PRAMBANAN -- 55572", "340410": "KALASAN -- 55571", "340411": "NGEMPLAK -- 55584", "340412": "NGAGLIK -- 55581", "340413": "SLEMAN -- 55515", "340414": "TEMPEL -- 55552", "340415": "TURI -- 55551", "340416": "PAKEM -- 55582", "340417": "CANGKRINGAN -- 55583", "347101": "TEGALREJO -- 55243", "347102": "JETIS -- 55231", "347103": "GONDOKUSUMAN -- 55225", "347104": "DANUREJAN -- 55211", "347105": "GEDONGTENGEN -- 55272", "347106": "NGAMPILAN -- 55261", "347107": "WIROBRAJAN -- 55253", "347108": "MANTRIJERON -- 55142", "347109": "KRATON -- 55132", "347110": "GONDOMANAN -- 55122", "347111": "PAKUALAMAN -- 55111", "347112": "MERGANGSAN -- 55153", "347113": "UMBULHARJO -- 55163", "347114": "KOTAGEDE -- 55172", "350101": "DONOROJO -- 63554", "350102": "PRINGKUKU -- 63552", "350103": "PUNUNG -- 63553", "350104": "PACITAN -- 63516", "350105": "KEBONAGUNG -- 63561", "350106": "ARJOSARI -- 63581", "350107": "NAWANGAN -- 63584", "350108": "BANDAR -- 61462", "350109": "TEGALOMBO -- 63582", "350110": "TULAKAN -- 63571", "350111": "NGADIROJO -- 63572", "350112": "SUDIMORO -- 63573", "350201": "SLAHUNG -- 63463", "350202": "NGRAYUN -- 63464", "350203": "BUNGKAL -- 63462", "350204": "SAMBIT -- 63474", "350205": "SAWOO -- 63475", "350206": "SOOKO -- 63482", "350207": "PULUNG -- 63481", "350208": "MLARAK -- 63472", "350209": "JETIS -- 61352", "350210": "SIMAN -- 62164", "350211": "BALONG -- 61173", "350212": "KAUMAN -- 66261", "350213": "BADEGAN -- 63455", "350214": "SAMPUNG -- 63454", "350215": "SUKOREJO -- 63453", "350216": "BABADAN -- 63491", "350217": "PONOROGO -- 63419", "350218": "JENANGAN -- 63492", "350219": "NGEBEL -- 63493", "350220": "JAMBON -- 63456", "350221": "PUDAK -- 63418", "350301": "PANGGUL -- 66364", "350302": "MUNJUNGAN -- 66365", "350303": "PULE -- 66362", "350304": "DONGKO -- 66363", "350305": "TUGU -- 66318", "350306": "KARANGAN -- 63257", "350307": "KAMPAK -- 66373", "350308": "WATULIMO -- 66382", "350309": "BENDUNGAN -- 66351", "350310": "GANDUSARI -- 66187", "350311": "TRENGGALEK -- 66318", "350312": "POGALAN -- 66371", "350313": "DURENAN -- 66381", "350314": "SURUH -- 66362", "350401": "TULUNGAGUNG -- 66218", "350402": "BOYOLANGU -- 66233", "350403": "KEDUNGWARU -- 66229", "350404": "NGANTRU -- 66252", "350405": "KAUMAN -- 66261", "350406": "PAGERWOJO -- 66262", "350407": "SENDANG -- 66254", "350408": "KARANGREJO -- 66253", "350409": "GONDANG -- 67174", "350410": "SUMBERGEMPOL -- 66291", "350411": "NGUNUT -- 66292", "350412": "PUCANGLABAN -- 66284", "350413": "REJOTANGAN -- 66293", "350414": "KALIDAWIR -- 66281", "350415": "BESUKI -- 66275", "350416": "CAMPURDARAT -- 66272", "350417": "BANDUNG -- 66274", "350418": "PAKEL -- 66273", "350419": "TANGGUNGGUNUNG -- 66283", "350501": "WONODADI -- 66155", "350502": "UDANAWU -- 66154", "350503": "SRENGAT -- 66152", "350504": "KADEMANGAN -- 66161", "350505": "BAKUNG -- 66163", "350506": "PONGGOK -- 66153", "350507": "SANANKULON -- 66151", "350508": "WONOTIRTO -- 66173", "350509": "NGLEGOK -- 66181", "350510": "KANIGORO -- 66171", "350511": "GARUM -- 66182", "350512": "SUTOJAYAN -- 66172", "350513": "PANGGUNGREJO -- 66174", "350514": "TALUN -- 66183", "350515": "GANDUSARI -- 66187", "350516": "BINANGUN -- 62293", "350517": "WLINGI -- 66184", "350518": "DOKO -- 66186", "350519": "KESAMBEN -- 61484", "350520": "WATES -- 64174", "350521": "SELOREJO -- 66192", "350522": "SELOPURO -- 66184", "350601": "SEMEN -- 64161", "350602": "MOJO -- 61382", "350603": "KRAS -- 64172", "350604": "NGADILUWIH -- 64171", "350605": "KANDAT -- 64173", "350606": "WATES -- 64174", "350607": "NGANCAR -- 64291", "350608": "PUNCU -- 64292", "350609": "PLOSOKLATEN -- 64175", "350610": "GURAH -- 64181", "350611": "PAGU -- 64183", "350612": "GAMPENGREJO -- 64182", "350613": "GROGOL -- 64151", "350614": "PAPAR -- 64153", "350615": "PURWOASRI -- 64154", "350616": "PLEMAHAN -- 64155", "350617": "PARE -- 65166", "350618": "KEPUNG -- 64293", "350619": "KANDANGAN -- 64294", "350620": "TAROKAN -- 64152", "350621": "KUNJANG -- 64156", "350622": "BANYAKAN -- 64157", "350623": "RINGINREJO -- 64176", "350624": "KAYEN KIDUL -- 64183", "350625": "NGASEM -- 62154", "350626": "BADAS -- 64221", "350701": "DONOMULYO -- 65167", "350702": "PAGAK -- 65168", "350703": "BANTUR -- 65179", "350704": "SUMBERMANJING WETAN -- 65176", "350705": "DAMPIT -- 65181", "350706": "AMPELGADING -- 65183", "350707": "PONCOKUSUMO -- 65157", "350708": "WAJAK -- 65173", "350709": "TUREN -- 65175", "350710": "GONDANGLEGI -- 65174", "350711": "KALIPARE -- 65166", "350712": "SUMBERPUCUNG -- 65165", "350713": "KEPANJEN -- 65163", "350714": "BULULAWANG -- 65171", "350715": "TAJINAN -- 65172", "350716": "TUMPANG -- 65156", "350717": "JABUNG -- 65155", "350718": "PAKIS -- 65154", "350719": "PAKISAJI -- 65162", "350720": "NGAJUNG -- 65164", "350721": "WAGIR -- 65158", "350722": "DAU -- 65151", "350723": "KARANG PLOSO -- 65152", "350724": "SINGOSARI -- 65153", "350725": "LAWANG -- 65171", "350726": "PUJON -- 65391", "350727": "NGANTANG -- 65392", "350728": "KASEMBON -- 65393", "350729": "GEDANGAN -- 61254", "350730": "TIRTOYUDO -- 65183", "350731": "KROMENGAN -- 65165", "350732": "WONOSARI -- 65164", "350733": "PAGELARAN -- 65174", "350801": "TEMPURSARI -- 67375", "350802": "PRONOJIWO -- 67374", "350803": "CANDIPURO -- 67373", "350804": "PASIRIAN -- 67372", "350805": "TEMPEH -- 67371", "350806": "KUNIR -- 67292", "350807": "YOSOWILANGUN -- 67382", "350808": "ROWOKANGKUNG -- 67359", "350809": "TEKUNG -- 67381", "350810": "LUMAJANG -- 67316", "350811": "PASRUJAMBE -- 67361", "350812": "SENDURO -- 67361", "350813": "GUCIALIT -- 67353", "350814": "PADANG -- 67352", "350815": "SUKODONO -- 61258", "350816": "KEDUNGJAJANG -- 67358", "350817": "JATIROTO -- 67355", "350818": "RANDUAGUNG -- 67354", "350819": "KLAKAH -- 67356", "350820": "RANUYOSO -- 67357", "350821": "SUMBERSUKO -- 67316", "350901": "JOMBANG -- 61419", "350902": "KENCONG -- 68167", "350903": "SUMBERBARU -- 68156", "350904": "GUMUKMAS -- 68165", "350905": "UMBULSARI -- 68166", "350906": "TANGGUL -- 61272", "350907": "SEMBORO -- 68157", "350908": "PUGER -- 68164", "350909": "BANGSALSARI -- 68154", "350910": "BALUNG -- 68161", "350911": "WULUHAN -- 68162", "350912": "AMBULU -- 68172", "350913": "RAMBIPUJI -- 68152", "350914": "PANTI -- 68153", "350915": "SUKORAMBI -- 68151", "350916": "JENGGAWAH -- 68171", "350917": "AJUNG -- 68175", "350918": "TEMPUREJO -- 68173", "350919": "KALIWATES -- 68131", "350920": "PATRANG -- 68118", "350921": "SUMBERSARI -- 68125", "350922": "ARJASA -- 69491", "350923": "MUMBULSARI -- 68174", "350924": "PAKUSARI -- 68181", "350925": "JELBUK -- 68192", "350926": "MAYANG -- 62184", "350927": "KALISAT -- 68193", "350928": "LEDOKOMBO -- 68196", "350929": "SUKOWONO -- 68194", "350930": "SILO -- 68184", "350931": "SUMBERJAMBE -- 68195", "351001": "PESANGGARAN -- 68488", "351002": "BANGOREJO -- 68487", "351003": "PURWOHARJO -- 68483", "351004": "TEGALDLIMO -- 68484", "351005": "MUNCAR -- 68472", "351006": "CLURING -- 68482", "351007": "GAMBIRAN -- 68486", "351008": "SRONO -- 68471", "351009": "GENTENG -- 69482", "351010": "GLENMORE -- 68466", "351011": "KALIBARU -- 68467", "351012": "SINGOJURUH -- 68464", "351013": "ROGOJAMPI -- 68462", "351014": "KABAT -- 68461", "351015": "GLAGAH -- 68431", "351016": "BANYUWANGI -- 68419", "351017": "GIRI -- 68424", "351018": "WONGSOREJO -- 68453", "351019": "SONGGON -- 68463", "351020": "SEMPU -- 68468", "351021": "KALIPURO -- 68455", "351022": "SILIRAGUNG -- 68488", "351023": "TEGALSARI -- 68485", "351024": "LICIN -- 68454", "351101": "MAESAN -- 68262", "351102": "TAMANAN -- 68263", "351103": "TLOGOSARI -- 68272", "351104": "SUKOSARI -- 68287", "351105": "PUJER -- 68271", "351106": "GRUJUGAN -- 68261", "351107": "CURAHDAMI -- 68251", "351108": "TENGGARANG -- 68281", "351109": "WONOSARI -- 65164", "351110": "TAPEN -- 68283", "351111": "BONDOWOSO -- 68214", "351112": "WRINGIN -- 68252", "351113": "TEGALAMPEL -- 68291", "351114": "KLABANG -- 68284", "351115": "CERMEE -- 68286", "351116": "PRAJEKAN -- 68285", "351117": "PAKEM -- 68253", "351118": "SUMBERWRINGIN -- 68287", "351119": "SEMPOL -- 68288", "351120": "BINAKAL -- 68251", "351121": "TAMAN KROCOK -- 68291", "351122": "BOTOLINGGO -- 68284", "351123": "JAMBESARI DARUS SHOLAH -- 68261", "351201": "JATIBANTENG -- 68357", "351202": "BESUKI -- 66275", "351203": "SUBOH -- 68354", "351204": "MLANDINGAN -- 68353", "351205": "KENDIT -- 68352", "351206": "PANARUKAN -- 68351", "351207": "SITUBONDO -- 68311", "351208": "PANJI -- 68321", "351209": "MANGARAN -- 68363", "351210": "KAPONGAN -- 68362", "351211": "ARJASA -- 69491", "351212": "JANGKAR -- 68372", "351213": "ASEMBAGUS -- 68373", "351214": "BANYUPUTIH -- 68374", "351215": "SUMBERMALANG -- 68355", "351216": "BANYUGLUGUR -- 68359", "351217": "BUNGATAN -- 68358", "351301": "SUKAPURA -- 67254", "351302": "SUMBER -- 68355", "351303": "KURIPAN -- 67262", "351304": "BANTARAN -- 67261", "351305": "LECES -- 67273", "351306": "BANYUANYAR -- 67275", "351307": "TIRIS -- 67287", "351308": "KRUCIL -- 67288", "351309": "GADING -- 65183", "351310": "PAKUNIRAN -- 67292", "351311": "KOTAANYAR -- 67293", "351312": "PAITON -- 67291", "351313": "BESUK -- 67283", "351314": "KRAKSAAN -- 67282", "351315": "KREJENGAN -- 67284", "351316": "PEJARAKAN -- -", "351317": "MARON -- 67276", "351318": "GENDING -- 67272", "351319": "DRINGU -- 67271", "351320": "TEGALSIWALAN -- 67274", "351321": "SUMBERASIH -- 67251", "351322": "WONOMERTO -- 67253", "351323": "TONGAS -- 67252", "351324": "LUMBANG -- 67183", "351401": "PURWODADI -- 67163", "351402": "TUTUR -- 67165", "351403": "PUSPO -- 67176", "351404": "LUMBANG -- 67183", "351405": "PASREPAN -- 67175", "351406": "KEJAYAN -- 67172", "351407": "WONOREJO -- 67173", "351408": "PURWOSARI -- 67162", "351409": "SUKOREJO -- 63453", "351410": "PRIGEN -- 67157", "351411": "PANDAAN -- 67156", "351412": "GEMPOL -- 66291", "351413": "BEJI -- 67154", "351414": "BANGIL -- 62364", "351415": "REMBANG -- 60179", "351416": "KRATON -- 67151", "351417": "POHJENTREK -- 67171", "351418": "GONDANGWETAN -- 67174", "351419": "WINONGAN -- 67182", "351420": "GRATI -- 67184", "351421": "NGULING -- 67185", "351422": "LEKOK -- 67186", "351423": "REJOSO -- 67181", "351424": "TOSARI -- 67177", "351501": "TARIK -- 61265", "351502": "PRAMBON -- 64484", "351503": "KREMBUNG -- 61275", "351504": "PORONG -- 61274", "351505": "JABON -- 61276", "351506": "TANGGULANGIN -- 61272", "351507": "CANDI -- 61271", "351508": "SIDOARJO -- 61225", "351509": "TULANGAN -- 61273", "351510": "WONOAYU -- 61261", "351511": "KRIAN -- 61262", "351512": "BALONGBENDO -- 61263", "351513": "TAMAN -- 63137", "351514": "SUKODONO -- 61258", "351515": "BUDURAN -- 61252", "351516": "GEDANGAN -- 61254", "351517": "SEDATI -- 61253", "351518": "WARU -- 69353", "351601": "JATIREJO -- 61373", "351602": "GONDANG -- 67174", "351603": "PACET -- 61374", "351604": "TRAWAS -- 61375", "351605": "NGORO -- 61473", "351606": "PUNGGING -- 61384", "351607": "KUTOREJO -- 61383", "351608": "MOJOSARI -- 61382", "351609": "DLANGGU -- 61371", "351610": "BANGSAL -- 68154", "351611": "PURI -- 61363", "351612": "TROWULAN -- 61362", "351613": "SOOKO -- 63482", "351614": "GEDEG -- 61351", "351615": "KEMLAGI -- 61353", "351616": "JETIS -- 61352", "351617": "DAWARBLANDONG -- 61354", "351618": "MOJOANYAR -- 61364", "351701": "PERAK -- 61461", "351702": "GUDO -- 61463", "351703": "NGORO -- 61473", "351704": "BARENG -- 61474", "351705": "WONOSALAM -- 61476", "351706": "MOJOAGUNG -- 61482", "351707": "MOJOWARNO -- 61475", "351708": "DIWEK -- 61471", "351709": "JOMBANG -- 61419", "351710": "PETERONGAN -- 61481", "351711": "SUMOBITO -- 61483", "351712": "KESAMBEN -- 61484", "351713": "TEMBELANG -- 61452", "351714": "PLOSO -- 65152", "351715": "PLANDAAN -- 61456", "351716": "KABUH -- 61455", "351717": "KUDU -- 61454", "351718": "BANDARKEDUNGMULYO -- 61462", "351719": "JOGOROTO -- 61485", "351720": "MEGALUH -- 61457", "351721": "NGUSIKAN -- 61454", "351801": "SAWAHAN -- 63162", "351802": "NGETOS -- 64474", "351803": "BERBEK -- 64473", "351804": "LOCERET -- 64471", "351805": "PACE -- 64472", "351806": "PRAMBON -- 64484", "351807": "NGRONGGOT -- 64395", "351808": "KERTOSONO -- 64311", "351809": "PATIANROWO -- 64391", "351810": "BARON -- 64394", "351811": "TANJUNGANOM -- 64482", "351812": "SUKOMORO -- 64481", "351813": "NGANJUK -- 64419", "351814": "BAGOR -- 64461", "351815": "WILANGAN -- 64462", "351816": "REJOSO -- 67181", "351817": "GONDANG -- 67174", "351818": "NGLUYU -- 64452", "351819": "LENGKONG -- 64393", "351820": "JATIKALEN -- 64392", "351901": "KEBON SARI -- 63173", "351902": "DOLOPO -- 63174", "351903": "GEGER -- 63171", "351904": "DAGANGAN -- 63172", "351905": "KARE -- 63182", "351906": "GEMARANG -- 63156", "351907": "WUNGU -- 63181", "351908": "MADIUN -- 63151", "351909": "JIWAN -- 63161", "351910": "BALEREJO -- 63152", "351911": "MEJAYAN -- 63153", "351912": "SARADAN -- 63155", "351913": "PILANGKENCENG -- 63154", "351914": "SAWAHAN -- 63162", "351915": "WONOASRI -- 63157", "352001": "PONCOL -- 63362", "352002": "PARANG -- 63371", "352003": "LEMBEYAN -- 63372", "352004": "TAKERAN -- 63383", "352005": "KAWEDANAN -- 63382", "352006": "MAGETAN -- 63319", "352007": "PLAOSAN -- 63361", "352008": "PANEKAN -- 63352", "352009": "SUKOMORO -- 64481", "352010": "BENDO -- 61263", "352011": "MAOSPATI -- 63392", "352012": "BARAT -- 63395", "352013": "KARANGREJO -- 66253", "352014": "KARAS -- 63395", "352015": "KARTOHARJO -- 63395", "352016": "NGARIBOYO -- 63351", "352017": "NGUNTORONADI -- 63383", "352018": "SIDOREJO -- 63319", "352101": "SINE -- 63264", "352102": "NGRAMBE -- 63263", "352103": "JOGOROGO -- 63262", "352104": "KENDAL -- 63261", "352105": "GENENG -- 63271", "352106": "KWADUNGAN -- 63283", "352107": "KARANGJATI -- 63284", "352108": "PADAS -- 63281", "352109": "NGAWI -- 63218", "352110": "PARON -- 63253", "352111": "KEDUNGGALAR -- 63254", "352112": "WIDODAREN -- 63256", "352113": "MANTINGAN -- 63261", "352114": "PANGKUR -- 63282", "352115": "BRINGIN -- 63285", "352116": "PITU -- 63252", "352117": "KARANGANYAR -- 63257", "352118": "GERIH -- 63271", "352119": "KASREMAN -- 63281", "352201": "NGRAHO -- 62165", "352202": "TAMBAKREJO -- 62166", "352203": "NGAMBON -- 62167", "352204": "NGASEM -- 62154", "352205": "BUBULAN -- 62172", "352206": "DANDER -- 62171", "352207": "SUGIHWARAS -- 62183", "352208": "KEDUNGADEM -- 62195", "352209": "KEPOH BARU -- 62194", "352210": "BAURENO -- 62192", "352211": "KANOR -- 62193", "352212": "SUMBEREJO -- -", "352213": "BALEN -- 62182", "352214": "KAPAS -- 62181", "352215": "BOJONEGORO -- 62118", "352216": "KALITIDU -- 62152", "352217": "MALO -- 62153", "352218": "PURWOSARI -- 67162", "352219": "PADANGAN -- 62162", "352220": "KASIMAN -- 62164", "352221": "TEMAYANG -- 62184", "352222": "MARGOMULYO -- 62168", "352223": "TRUCUK -- 62155", "352224": "SUKOSEWU -- 62183", "352225": "KEDEWAN -- 62164", "352226": "GONDANG -- 67174", "352227": "SEKAR -- 62167", "352228": "GAYAM -- 62154", "352301": "KENDURUAN -- 62363", "352302": "JATIROGO -- 62362", "352303": "BANGILAN -- 62364", "352304": "BANCAR -- 62354", "352305": "SENORI -- 62365", "352306": "TAMBAKBOYO -- 62353", "352307": "SINGGAHAN -- 62361", "352308": "KEREK -- 62356", "352309": "PARENGAN -- 62366", "352310": "MONTONG -- 62357", "352311": "SOKO -- 62372", "352312": "JENU -- 62352", "352313": "MERAKURAK -- 62355", "352314": "RENGEL -- 62371", "352315": "SEMANDING -- 62381", "352316": "TUBAN -- 62318", "352317": "PLUMPANG -- 62382", "352318": "PALANG -- 62391", "352319": "WIDANG -- 62383", "352320": "GRABAGAN -- 62371", "352401": "SUKORAME -- 62276", "352402": "BLULUK -- 62274", "352403": "MODO -- 62275", "352404": "NGIMBANG -- 62273", "352405": "BABAT -- 62271", "352406": "KEDUNGPRING -- 62272", "352407": "BRONDONG -- 62263", "352408": "LAREN -- 62262", "352409": "SEKARAN -- 62261", "352410": "MADURAN -- 62261", "352411": "SAMBENG -- 62284", "352412": "SUGIO -- 62256", "352413": "PUCUK -- 62257", "352414": "PACIRAN -- 62264", "352415": "SOLOKURO -- 62265", "352416": "MANTUP -- 62283", "352417": "SUKODADI -- 62253", "352418": "KARANGGENENG -- 62254", "352419": "KEMBANGBAHU -- 62282", "352420": "KALITENGAH -- 62255", "352421": "TURI -- 62252", "352422": "LAMONGAN -- 62212", "352423": "TIKUNG -- 62281", "352424": "KARANGBINANGUN -- 62293", "352425": "DEKET -- 62291", "352426": "GLAGAH -- 68431", "352427": "SARIREJO -- 62281", "352501": "DUKUN -- 61155", "352502": "BALONGPANGGANG -- 61173", "352503": "PANCENG -- 61156", "352504": "BENJENG -- 61172", "352505": "DUDUKSAMPEYAN -- 61162", "352506": "WRINGINANOM -- 61176", "352507": "UJUNGPANGKAH -- 61154", "352508": "KEDAMEAN -- 61175", "352509": "SIDAYU -- 61153", "352510": "MANYAR -- 61151", "352511": "CERME -- 68286", "352512": "BUNGAH -- 61152", "352513": "MENGANTI -- 61174", "352514": "KEBOMAS -- 61124", "352515": "DRIYOREJO -- 61177", "352516": "GRESIK -- 61114", "352517": "SANGKAPURA -- 61181", "352518": "TAMBAK -- 62166", "352601": "BANGKALAN -- 69112", "352602": "SOCAH -- 69161", "352603": "BURNEH -- 69121", "352604": "KAMAL -- 69162", "352605": "AROSBAYA -- 69151", "352606": "GEGER -- 63171", "352607": "KLAMPIS -- 69153", "352608": "SEPULU -- 69154", "352609": "TANJUNG BUMI -- 69156", "352610": "KOKOP -- 69155", "352611": "KWANYAR -- 69163", "352612": "LABANG -- 69163", "352613": "TANAH MERAH -- 69172", "352614": "TRAGAH -- 69165", "352615": "BLEGA -- 69174", "352616": "MODUNG -- 69166", "352617": "KONANG -- 69175", "352618": "GALIS -- 69382", "352701": "SRESEH -- 69273", "352702": "TORJUN -- 69271", "352703": "SAMPANG -- 69216", "352704": "CAMPLONG -- 69281", "352705": "OMBEN -- 69291", "352706": "KEDUNGDUNG -- 69252", "352707": "JRENGIK -- 69272", "352708": "TAMBELANGAN -- 69253", "352709": "BANYUATES -- 69263", "352710": "ROBATAL -- 69254", "352711": "SOKOBANAH -- 69262", "352712": "KETAPANG -- 69261", "352713": "PANGARENGAN -- 69271", "352714": "KARANGPENANG -- 69254", "352801": "TLANAKAN -- 69371", "352802": "PADEMAWU -- 69323", "352803": "GALIS -- 69382", "352804": "PAMEKASAN -- 69317", "352805": "PROPPO -- 69363", "352806": "PALENGAAN -- -", "352807": "PEGANTENAN -- 69361", "352808": "LARANGAN -- 69383", "352809": "PAKONG -- 69352", "352810": "WARU -- 69353", "352811": "BATUMARMAR -- 69354", "352812": "KADUR -- 69355", "352813": "PASEAN -- 69356", "352901": "KOTA SUMENEP -- 69417", "352902": "KALIANGET -- 69471", "352903": "MANDING -- 62381", "352904": "TALANGO -- 69481", "352905": "BLUTO -- 69466", "352906": "SARONGGI -- 69467", "352907": "LENTENG -- 69461", "352908": "GILI GINTING -- 69482", "352909": "GULUK-GULUK -- -", "352910": "GANDING -- 69462", "352911": "PRAGAAN -- 69465", "352912": "AMBUNTEN -- 69455", "352913": "PASONGSONGAN -- 69457", "352914": "DASUK -- 69454", "352915": "RUBARU -- 69456", "352916": "BATANG BATANG -- 69473", "352917": "BATU PUTIH -- 69453", "352918": "DUNGKEK -- 69474", "352919": "GAPURA -- 69472", "352920": "GAYAM -- 62154", "352921": "NONGGUNONG -- 69484", "352922": "RAAS -- 69485", "352923": "MASALEMBU -- 69492", "352924": "ARJASA -- 69491", "352925": "SAPEKEN -- 69493", "352926": "BATUAN -- 69451", "352927": "KANGAYAN -- 69491", "357101": "MOJOROTO -- 64118", "357102": "KOTA -- 64129", "357103": "PESANTREN -- 64133", "357201": "KEPANJENKIDUL -- 66116", "357202": "SUKOREJO -- 63453", "357203": "SANANWETAN -- 66133", "357301": "BLIMBING -- 65126", "357302": "KLOJEN -- 65116", "357303": "KEDUNGKANDANG -- 65132", "357304": "SUKUN -- 65148", "357305": "LOWOKWARU -- 65144", "357401": "KADEMANGAN -- 66161", "357402": "WONOASIH -- 67233", "357403": "MAYANGAN -- 67217", "357404": "KANIGARAN -- 67212", "357405": "KEDOPAK -- 67229", "357501": "GADINGREJO -- 67138", "357502": "PURWOREJO -- 67116", "357503": "BUGUL KIDUL -- 67128", "357504": "PANGGUNGREJO -- 66174", "357601": "PRAJURIT KULON -- 61327", "357602": "MAGERSARI -- 61314", "357701": "KARTOHARJO -- 63395", "357702": "MANGUHARJO -- 63122", "357703": "TAMAN -- 63137", "357801": "KARANGPILANG -- 60221", "357802": "WONOCOLO -- 60239", "357803": "RUNGKUT -- 60293", "357804": "WONOKROMO -- 60241", "357805": "TEGALSARI -- 68485", "357806": "SAWAHAN -- 63162", "357807": "GENTENG -- 69482", "357808": "GUBENG -- 60286", "357809": "SUKOLILO -- 60117", "357810": "TAMBAKSARI -- 60138", "357811": "SIMOKERTO -- 60141", "357812": "PABEAN CANTIKAN -- 60161", "357813": "BUBUTAN -- 60174", "357814": "TANDES -- 60186", "357815": "KREMBANGAN -- 60179", "357816": "SEMAMPIR -- 60151", "357817": "KENJERAN -- 60127", "357818": "LAKARSANTRI -- 60214", "357819": "BENOWO -- 60199", "357820": "WIYUNG -- 60227", "357821": "DUKUHPAKIS -- 60225", "357822": "GAYUNGAN -- 60234", "357823": "JAMBANGAN -- 60232", "357824": "TENGGILIS MEJOYO -- 60292", "357825": "GUNUNG ANYAR -- 60294", "357826": "MULYOREJO -- 60113", "357827": "SUKOMANUNGGAL -- 60189", "357828": "ASEM ROWO -- 60182", "357829": "BULAK -- 60124", "357830": "PAKAL -- 60197", "357831": "SAMBIKEREP -- 60195", "357901": "BATU -- 69453", "357902": "BUMIAJI -- 65334", "357903": "JUNREJO -- 65326", "360101": "SUMUR -- 42283", "360102": "CIMANGGU -- 42284", "360103": "CIBALIUNG -- 42285", "360104": "CIKEUSIK -- 42286", "360105": "CIGEULIS -- 42282", "360106": "PANIMBANG -- 42281", "360107": "ANGSANA -- 42277", "360108": "MUNJUL -- 42276", "360109": "PAGELARAN -- 42265", "360110": "BOJONG -- 42274", "360111": "PICUNG -- 42275", "360112": "LABUAN -- 42264", "360113": "MENES -- 42262", "360114": "SAKETI -- 42273", "360115": "CIPEUCANG -- 42272", "360116": "JIPUT -- 42263", "360117": "MANDALAWANGI -- 42261", "360118": "CIMANUK -- 42271", "360119": "KADUHEJO -- 42253", "360120": "BANJAR -- 42252", "360121": "PANDEGLANG -- 42219", "360122": "CADASARI -- 42251", "360123": "CISATA -- 42273", "360124": "PATIA -- 42265", "360125": "KARANG TANJUNG -- 42251", "360126": "CIKEDAL -- 42271", "360127": "CIBITUNG -- 42285", "360128": "CARITA -- 42264", "360129": "SUKARESMI -- 42265", "360130": "MEKARJAYA -- 42271", "360131": "SINDANGRESMI -- 42276", "360132": "PULOSARI -- 42273", "360133": "KORONCONG -- 42251", "360134": "MAJASARI -- 42214", "360135": "SOBANG -- 42281", "360201": "MALINGPING -- 42391", "360202": "PANGGARANGAN -- 42392", "360203": "BAYAH -- 42393", "360204": "CIPANAS -- 42372", "360205": "MUNCANG -- 42364", "360206": "LEUWIDAMAR -- 42362", "360207": "BOJONGMANIK -- 42363", "360208": "GUNUNGKENCANA -- 42354", "360209": "BANJARSARI -- 42355", "360210": "CILELES -- 42353", "360211": "CIMARGA -- 42361", "360212": "SAJIRA -- 42371", "360213": "MAJA -- 42381", "360214": "RANGKASBITUNG -- 42317", "360215": "WARUNGGUNUNG -- 42352", "360216": "CIJAKU -- 42395", "360217": "CIKULUR -- 42356", "360218": "CIBADAK -- 42357", "360219": "CIBEBER -- 42426", "360220": "CILOGRANG -- 42393", "360221": "WANASALAM -- 42396", "360222": "SOBANG -- 42281", "360223": "CURUG BITUNG -- 42381", "360224": "KALANGANYAR -- 42312", "360225": "LEBAKGEDONG -- 42372", "360226": "CIHARA -- 42392", "360227": "CIRINTEN -- 42363", "360228": "CIGEMLONG -- -", "360301": "BALARAJA -- 15610", "360302": "JAYANTI -- 15610", "360303": "TIGARAKSA -- 15720", "360304": "JAMBE -- 15720", "360305": "CISOKA -- 15730", "360306": "KRESEK -- 15620", "360307": "KRONJO -- 15550", "360308": "MAUK -- 15530", "360309": "KEMIRI -- 15530", "360310": "SUKADIRI -- 15530", "360311": "RAJEG -- 15540", "360312": "PASAR KEMIS -- 15560", "360313": "TELUKNAGA -- 15510", "360314": "KOSAMBI -- 15212", "360315": "PAKUHAJI -- 15570", "360316": "SEPATAN -- 15520", "360317": "CURUG -- 15810", "360318": "CIKUPA -- 15710", "360319": "PANONGAN -- 15710", "360320": "LEGOK -- 15820", "360322": "PAGEDANGAN -- 15336", "360323": "CISAUK -- 15344", "360327": "SUKAMULYA -- 15610", "360328": "KELAPA DUA -- 15810", "360329": "SINDANG JAYA -- 15540", "360330": "SEPATAN TIMUR -- 15520", "360331": "SOLEAR -- 15730", "360332": "GUNUNG KALER -- 15620", "360333": "MEKAR BARU -- 15550", "360405": "KRAMATWATU -- 42161", "360406": "WARINGINKURUNG -- 42453", "360407": "BOJONEGARA -- 42454", "360408": "PULO AMPEL -- 42455", "360409": "CIRUAS -- 42182", "360411": "KRAGILAN -- 42184", "360412": "PONTANG -- 42192", "360413": "TIRTAYASA -- 42193", "360414": "TANARA -- 42194", "360415": "CIKANDE -- 42186", "360416": "KIBIN -- 42185", "360417": "CARENANG -- 42195", "360418": "BINUANG -- 42196", "360419": "PETIR -- 42172", "360420": "TUNJUNG TEJA -- 42174", "360422": "BAROS -- 42173", "360423": "CIKEUSAL -- 42175", "360424": "PAMARAYAN -- 42176", "360425": "KOPO -- 42178", "360426": "JAWILAN -- 42177", "360427": "CIOMAS -- 42164", "360428": "PABUARAN -- 42163", "360429": "PADARINCANG -- 42168", "360430": "ANYAR -- 42166", "360431": "CINANGKA -- 42167", "360432": "MANCAK -- 42165", "360433": "GUNUNG SARI -- 42163", "360434": "BANDUNG -- 42176", "367101": "TANGERANG -- 15118", "367102": "JATIUWUNG -- 15133", "367103": "BATUCEPER -- 15122", "367104": "BENDA -- 15123", "367105": "CIPONDOH -- 15148", "367106": "CILEDUG -- 15153", "367107": "KARAWACI -- 15115", "367108": "PERIUK -- 15132", "367109": "CIBODAS -- 15138", "367110": "NEGLASARI -- 15121", "367111": "PINANG -- 15142", "367112": "KARANG TENGAH -- 15157", "367113": "LARANGAN -- 15155", "367201": "CIBEBER -- 42426", "367202": "CILEGON -- 42419", "367203": "PULOMERAK -- 42431", "367204": "CIWANDAN -- 42441", "367205": "JOMBANG -- 42413", "367206": "GEROGOL -- 42438", "367207": "PURWAKARTA -- 42433", "367208": "CITANGKIL -- 42441", "367301": "SERANG -- 42111", "367302": "KASEMEN -- 42191", "367303": "WALANTAKA -- 42183", "367304": "CURUG -- 15810", "367305": "CIPOCOK JAYA -- 42122", "367306": "TAKTAKAN -- 42162", "367401": "SERPONG -- 15310", "367402": "SERPONG UTARA -- 15323", "367403": "PONDOK AREN -- 15223", "367404": "CIPUTAT -- 15412", "367405": "CIPUTAT TIMUR -- 15412", "367406": "PAMULANG -- 15415", "367407": "SETU -- 15315", "510101": "NEGARA -- 82212", "510102": "MENDOYO -- 82261", "510103": "PEKUTATAN -- 82262", "510104": "MELAYA -- 82252", "510105": "JEMBRANA -- 82218", "510201": "SELEMADEG -- 82162", "510202": "SALAMADEG TIMUR -- 82162", "510203": "SALEMADEG BARAT -- 82162", "510204": "KERAMBITAN -- 82161", "510205": "TABANAN -- 82112", "510206": "KEDIRI -- 82121", "510207": "MARGA -- 82181", "510208": "PENEBEL -- 82152", "510209": "BATURITI -- 82191", "510210": "PUPUAN -- 82163", "510301": "KUTA -- 82262", "510302": "MENGWI -- 80351", "510303": "ABIANSEMAL -- 80352", "510304": "PETANG -- 80353", "510305": "KUTA SELATAN -- 80361", "510306": "KUTA UTARA -- 80361", "510401": "SUKAWATI -- 80582", "510402": "BLAHBATUH -- 80581", "510403": "GIANYAR -- 80515", "510404": "TAMPAKSIRING -- 80552", "510405": "UBUD -- 80571", "510406": "TEGALALLANG -- -", "510407": "PAYANGAN -- 80572", "510501": "NUSA PENIDA -- 80771", "510502": "BANJARANGKAN -- 80752", "510503": "KLUNGKUNG -- 80716", "510504": "DAWAN -- 80761", "510601": "SUSUT -- 80661", "510602": "BANGLI -- 80614", "510603": "TEMBUKU -- 80671", "510604": "KINTAMANI -- 80652", "510701": "RENDANG -- 80863", "510702": "SIDEMEN -- 80864", "510703": "MANGGIS -- 80871", "510704": "KARANGASEM -- 80811", "510705": "ABANG -- 80852", "510706": "BEBANDEM -- 80861", "510707": "SELAT -- 80862", "510708": "KUBU -- 80853", "510801": "GEROKGAK -- 81155", "510802": "SERIRIT -- 81153", "510803": "BUSUNG BIU -- 81154", "510804": "BANJAR -- 80752", "510805": "SUKASADA -- 81161", "510806": "BULELENG -- 81119", "510807": "SAWAN -- 81171", "510808": "KUBUTAMBAHAN -- 81172", "510809": "TEJAKULA -- 81173", "517101": "DENPASAR SELATAN -- 80225", "517102": "DENPASAR TIMUR -- 80234", "517103": "DENPASAR BARAT -- 80112", "517104": "DENPASAR UTARA -- 80231", "520101": "GERUNG -- 83363", "520102": "KEDIRI -- 83362", "520103": "NARMADA -- 83371", "520107": "SEKOTONG -- 83365", "520108": "LABUAPI -- 83361", "520109": "GUNUNGSARI -- 83351", "520112": "LINGSAR -- 83371", "520113": "LEMBAR -- 83364", "520114": "BATU LAYAR -- 83355", "520115": "KURIPAN -- 83362", "520201": "PRAYA -- 83511", "520202": "JONGGAT -- 83561", "520203": "BATUKLIANG -- 83552", "520204": "PUJUT -- 83573", "520205": "PRAYA BARAT -- 83572", "520206": "PRAYA TIMUR -- 83581", "520207": "JANAPRIA -- 83554", "520208": "PRINGGARATA -- 83562", "520209": "KOPANG -- 83553", "520210": "PRAYA TENGAH -- 83582", "520211": "PRAYA BARAT DAYA -- 83571", "520212": "BATUKLIANG UTARA -- 83552", "520301": "KERUAK -- 83672", "520302": "SAKRA -- 83671", "520303": "TERARA -- 83663", "520304": "SIKUR -- 83662", "520305": "MASBAGIK -- 83661", "520306": "SUKAMULIA -- 83652", "520307": "SELONG -- 83618", "520308": "PRINGGABAYA -- 83654", "520309": "AIKMEL -- 83653", "520310": "SAMBELIA -- 83656", "520311": "MONTONG GADING -- 83663", "520312": "PRINGGASELA -- 83661", "520313": "SURALAGA -- 83652", "520314": "WANASABA -- 83653", "520315": "SEMBALUN -- 83656", "520316": "SUWELA -- 83654", "520317": "LABUHAN HAJI -- 83614", "520318": "SAKRA TIMUR -- 83671", "520319": "SAKRA BARAT -- 83671", "520320": "JEROWARU -- 83672", "520402": "LUNYUK -- 84373", "520405": "ALAS -- 84353", "520406": "UTAN -- 84352", "520407": "BATU LANTEH -- 84361", "520408": "SUMBAWA -- 84314", "520409": "MOYO HILIR -- 84381", "520410": "MOYO HULU -- 84371", "520411": "ROPANG -- 84372", "520412": "LAPE -- 84382", "520413": "PLAMPANG -- 84383", "520414": "EMPANG -- 84384", "520417": "ALAS BARAT -- 84353", "520418": "LABUHAN BADAS -- 84316", "520419": "LABANGKA -- 84383", "520420": "BUER -- 84353", "520421": "RHEE -- 84352", "520422": "UNTER IWES -- 84316", "520423": "MOYO UTARA -- 84381", "520424": "MARONGE -- 84383", "520425": "TARANO -- 84384", "520426": "LOPOK -- 84382", "520427": "LENANGGUAR -- 84372", "520428": "ORONG TELU -- 84373", "520429": "LANTUNG -- 84372", "520501": "DOMPU -- 84211", "520502": "KEMPO -- 84261", "520503": "HU'U -- -", "520504": "KILO -- 84252", "520505": "WOJA -- 84251", "520506": "PEKAT -- 84261", "520507": "MANGGALEWA -- -", "520508": "PAJO -- 84272", "520601": "MONTA -- 84172", "520602": "BOLO -- 84161", "520603": "WOHA -- 84171", "520604": "BELO -- 84173", "520605": "WAWO -- 84181", "520606": "SAPE -- 84182", "520607": "WERA -- 84152", "520608": "DONGGO -- 84162", "520609": "SANGGAR -- 84191", "520610": "AMBALAWI -- 84153", "520611": "LANGGUDU -- 84181", "520612": "LAMBU -- 84182", "520613": "MADAPANGGA -- 84111", "520614": "TAMBORA -- 84191", "520615": "SOROMANDI -- 84162", "520616": "PARADO -- 84172", "520617": "LAMBITU -- 84181", "520618": "PALIBELO -- 84173", "520701": "JEREWEH -- 84456", "520702": "TALIWANG -- 84455", "520703": "SETELUK -- 84454", "520704": "SEKONGKANG -- 84457", "520705": "BRANG REA -- 84458", "520706": "POTO TANO -- 84454", "520707": "BRANG ENE -- 84455", "520708": "MALUK -- 84456", "520801": "TANJUNG -- 83352", "520802": "GANGGA -- 83353", "520803": "KAYANGAN -- 83353", "520804": "BAYAN -- 83354", "520805": "PEMENANG -- 83352", "527101": "AMPENAN -- 83114", "527102": "MATARAM -- 83121", "527103": "CAKRANEGARA -- 83239", "527104": "SEKARBELA -- 83116", "527105": "SELAPRANG -- 83125", "527106": "SANDUBAYA -- 83237", "527201": "RASANAE BARAT -- 84119", "527202": "RASANAE TIMUR -- 84119", "527203": "ASAKOTA -- 84119", "527204": "RABA -- 83671", "527205": "MPUNDA -- 84119", "530104": "SEMAU -- 85353", "530105": "KUPANG BARAT -- 85351", "530106": "KUPANG TIMUR -- 85362", "530107": "SULAMU -- 85368", "530108": "KUPANG TENGAH -- 85361", "530109": "AMARASI -- 85367", "530110": "FATULEU -- 85363", "530111": "TAKARI -- 85369", "530112": "AMFOANG SELATAN -- 85364", "530113": "AMFOANG UTARA -- 85365", "530116": "NEKAMESE -- 85391", "530117": "AMARASI BARAT -- 85367", "530118": "AMARASI SELATAN -- 85367", "530119": "AMARASI TIMUR -- 85367", "530120": "AMABI OEFETO TIMUR -- 85363", "530121": "AMFOANG BARAT DAYA -- 85364", "530122": "AMFOANG BARAT LAUT -- 85364", "530123": "SEMAU SELATAN -- 85353", "530124": "TAEBENU -- 85361", "530125": "AMABI OEFETO -- 85363", "530126": "AMFOANG TIMUR -- 85364", "530127": "FATULEU BARAT -- 85223", "530128": "FATULEU TENGAH -- 85223", "530130": "AMFOANG TENGAH -- 85364", "530201": "KOTA SOE -- 85519", "530202": "MOLLO SELATAN -- 85561", "530203": "MOLLO UTARA -- 85552", "530204": "AMANUBAN TIMUR -- 85572", "530205": "AMANUBAN TENGAH -- 85571", "530206": "AMANUBAN SELATAN -- 85562", "530207": "AMANUBAN BARAT -- 85551", "530208": "AMANATUN SELATAN -- 85573", "530209": "AMANATUN UTARA -- 85574", "530210": "KI'E -- -", "530211": "KUANFATU -- 85563", "530212": "FATUMNASI -- 85561", "530213": "POLEN -- 85561", "530214": "BATU PUTIH -- 85562", "530215": "BOKING -- 85573", "530216": "TOIANAS -- 85574", "530217": "NUNKOLO -- 85573", "530218": "OENINO -- 85572", "530219": "KOLBANO -- 85563", "530220": "KOT OLIN -- 85575", "530221": "KUALIN -- 85562", "530222": "MOLLO BARAT -- 85561", "530223": "KOK BAUN -- 85574", "530224": "NOEBANA -- 85573", "530225": "SANTIAN -- 85573", "530226": "NOEBEBA -- 85562", "530227": "KUATNANA -- 85551", "530228": "FAUTMOLO -- 85572", "530229": "FATUKOPA -- 85572", "530230": "MOLLO TENGAH -- 85561", "530231": "TOBU -- 85552", "530232": "NUNBENA -- 85561", "530301": "MIOMAFO TIMUR -- -", "530302": "MIOMAFO BARAT -- -", "530303": "BIBOKI SELATAN -- 85681", "530304": "NOEMUTI -- 85661", "530305": "KOTA KEFAMENANU -- 85614", "530306": "BIBOKI UTARA -- 85682", "530307": "BIBOKI ANLEU -- 85613", "530308": "INSANA -- 85671", "530309": "INSANA UTARA -- 85671", "530310": "NOEMUTI TIMUR -- 85661", "530311": "MIOMAFFO TENGAH -- 85661", "530312": "MUSI -- 85661", "530313": "MUTIS -- 85661", "530314": "BIKOMI SELATAN -- 85651", "530315": "BIKOMI TENGAH -- 85651", "530316": "BIKOMI NILULAT -- 85651", "530317": "BIKOMI UTARA -- 85651", "530318": "NAIBENU -- 85651", "530319": "INSANA FAFINESU -- 85671", "530320": "INSANA BARAT -- 85671", "530321": "INSANA TENGAH -- 85671", "530322": "BIBOKI TAN PAH -- 85681", "530323": "BIBOKI MOENLEU -- 85681", "530324": "BIBOKI FEOTLEU -- 85682", "530401": "LAMAKNEN -- 85772", "530402": "TASIFETOTIMUR -- 85771", "530403": "RAIHAT -- 85773", "530404": "TASIFETO BARAT -- 85752", "530405": "KAKULUK MESAK -- 85752", "530412": "KOTA ATAMBUA -- -", "530413": "RAIMANUK -- 85761", "530417": "LASIOLAT -- 85771", "530418": "LAMAKNEN SELATAN -- 85772", "530421": "ATAMBUA BARAT -- 85715", "530422": "ATAMBUA SELATAN -- 85717", "530423": "NANAET DUABESI -- 85752", "530501": "TELUK MUTIARA -- 85819", "530502": "ALOR BARAT LAUT -- 85851", "530503": "ALOR BARAT DAYA -- 85861", "530504": "ALOR SELATAN -- 85871", "530505": "ALOR TIMUR -- 85872", "530506": "PANTAR -- 85881", "530507": "ALOR TENGAH UTARA -- 85871", "530508": "ALOR TIMUR LAUT -- 85872", "530509": "PANTAR BARAT -- 85881", "530510": "KABOLA -- 85851", "530511": "PULAU PURA -- 85851", "530512": "MATARU -- 85861", "530513": "PUREMAN -- 85872", "530514": "PANTAR TIMUR -- 85881", "530515": "LEMBUR -- 85871", "530516": "PANTAR TENGAH -- 85881", "530517": "PANTAR BARU LAUT -- -", "530601": "WULANGGITANG -- 86253", "530602": "TITEHENA -- 86253", "530603": "LARANTUKA -- 86219", "530604": "ILE MANDIRI -- 86211", "530605": "TANJUNG BUNGA -- 86252", "530606": "SOLOR BARAT -- 86272", "530607": "SOLOR TIMUR -- 86271", "530608": "ADONARA BARAT -- 86262", "530609": "WOTAN ULUMANDO -- -", "530610": "ADONARA TIMUR -- 86261", "530611": "KELUBAGOLIT -- 86262", "530612": "WITIHAMA -- 86262", "530613": "ILE BOLENG -- 86253", "530614": "DEMON PAGONG -- 86219", "530615": "LEWOLEMA -- 86252", "530616": "ILE BURA -- 86253", "530617": "ADONARA -- 86262", "530618": "ADONARA TENGAH -- 86262", "530619": "SOLOR SELATAN -- 86271", "530701": "PAGA -- 86153", "530702": "MEGO -- 86113", "530703": "LELA -- 86516", "530704": "NITA -- 86152", "530705": "ALOK -- 86111", "530706": "PALUE -- 86111", "530707": "NELLE -- 86116", "530708": "TALIBURA -- 86183", "530709": "WAIGETE -- 86183", "530710": "KEWAPANTE -- 86181", "530711": "BOLA -- 85851", "530712": "MAGEPANDA -- 86152", "530713": "WAIBLAMA -- 86183", "530714": "ALOK BARAT -- 86115", "530715": "ALOK TIMUR -- 86111", "530716": "KOTING -- 86116", "530717": "TANA WAWO -- 86153", "530718": "HEWOKLOANG -- 86181", "530719": "KANGAE -- 86181", "530720": "DORENG -- 86171", "530721": "MAPITARA -- 86171", "530801": "NANGAPANDA -- 86352", "530802": "PULAU ENDE -- 86362", "530803": "ENDE -- 86362", "530804": "ENDE SELATAN -- 86313", "530805": "NDONA -- 86361", "530806": "DETUSOKO -- 86371", "530807": "WEWARIA -- 86353", "530808": "WOLOWARU -- 86372", "530809": "WOLOJITA -- 86382", "530810": "MAUROLE -- 86381", "530811": "MAUKARO -- 86352", "530812": "LIO TIMUR -- 86361", "530813": "KOTA BARU -- 86111", "530814": "KELIMUTU -- 86318", "530815": "DETUKELI -- 86371", "530816": "NDONA TIMUR -- 86361", "530817": "NDORI -- 86372", "530818": "ENDE UTARA -- 86319", "530819": "ENDE TENGAH -- 86319", "530820": "ENDE TIMUR -- 86361", "530821": "LEPEMBUSU KELISOKE -- 86374", "530901": "AIMERE -- 86452", "530902": "GOLEWA -- 86461", "530906": "BAJAWA -- 86413", "530907": "SOA -- 86419", "530909": "RIUNG -- 86419", "530912": "JEREBUU -- 86452", "530914": "RIUNG BARAT -- 86419", "530915": "BAJAWA UTARA -- 86413", "530916": "WOLOMEZE -- 86419", "530918": "GOLEWA SELATAN -- 86461", "530919": "GOLEWA BARAT -- 86461", "530920": "INERIE -- 86452", "531001": "WAE RII -- 86591", "531003": "RUTENG -- 86516", "531005": "SATAR MESE -- 86561", "531006": "CIBAL -- 86591", "531011": "REOK -- 86592", "531012": "LANGKE REMBONG -- 86519", "531013": "SATAR MESE BARAT -- 86561", "531014": "RAHONG UTARA -- 86516", "531015": "LELAK -- 86516", "531016": "REOK BARAT -- 86592", "531017": "CIBAL BARAT -- 86591", "531101": "KOTA WAINGAPU -- 87112", "531102": "HAHARU -- 87153", "531103": "LEWA -- 86461", "531104": "NGGAHA ORI ANGU -- 87152", "531105": "TABUNDUNG -- 87161", "531106": "PINU PAHAR -- 87161", "531107": "PANDAWAI -- 87171", "531108": "UMALULU -- 87181", "531109": "RINDI -- 87181", "531110": "PAHUNGA LODU -- 87182", "531111": "WULLA WAIJELU -- -", "531112": "PABERIWAI -- 87171", "531113": "KARERA -- 87172", "531114": "KAHAUNGU ETI -- 87171", "531115": "MATAWAI LA PAWU -- -", "531116": "KAMBERA -- 87114", "531117": "KAMBATA MAPAMBUHANG -- 87171", "531118": "LEWA TIDAHU -- 87152", "531119": "KATALA HAMU LINGU -- 87152", "531120": "KANATANG -- 87153", "531121": "NGADU NGALA -- 87172", "531122": "MAHU -- 87171", "531204": "TANA RIGHU -- 87257", "531210": "LOLI -- 87284", "531211": "WANOKAKA -- 87272", "531212": "LAMBOYA -- 87271", "531215": "KOTA WAIKABUBAK -- 87217", "531218": "LABOYA BARAT -- -", "531301": "NAGA WUTUNG -- 86684", "531302": "ATADEI -- 86685", "531303": "ILE APE -- 86683", "531304": "LEBATUKAN -- 86681", "531305": "NUBATUKAN -- 86682", "531306": "OMESURI -- 86691", "531307": "BUYASURI -- 86692", "531308": "WULANDONI -- 86685", "531309": "ILE APE TIMUR -- 86683", "531401": "ROTE BARAT DAYA -- 85982", "531402": "ROTE BARAT LAUT -- 85981", "531403": "LOBALAIN -- 85912", "531404": "ROTE TENGAH -- 85972", "531405": "PANTAI BARU -- 85973", "531406": "ROTE TIMUR -- 85974", "531407": "ROTE BARAT -- 85982", "531408": "ROTE SELATAN -- 85972", "531409": "NDAO NUSE -- 85983", "531410": "LANDU LEKO -- 85974", "531501": "MACANG PACAR -- 86756", "531502": "KUWUS -- 86752", "531503": "LEMBOR -- 86753", "531504": "SANO NGGOANG -- 86757", "531505": "KOMODO -- 86754", "531506": "BOLENG -- 86754", "531507": "WELAK -- 86753", "531508": "NDOSO -- 86752", "531509": "LEMBOR SELATAN -- 86753", "531510": "MBELILING -- 86757", "531601": "AESESA -- 86472", "531602": "NANGARORO -- 86464", "531603": "BOAWAE -- 86462", "531604": "MAUPONGGO -- 86463", "531605": "WOLOWAE -- 86472", "531606": "KEO TENGAH -- 86464", "531607": "AESESA SELATAN -- 86472", "531701": "KATIKU TANA -- 87282", "531702": "UMBU RATU NGGAY BARAT -- 87282", "531703": "MAMBORO -- 87258", "531704": "UMBU RATU NGGAY -- 87282", "531705": "KATIKU TANA SELATAN -- 87282", "531801": "LOURA -- 87254", "531802": "WEWEWA UTARA -- 87252", "531803": "WEWEWA TIMUR -- 87252", "531804": "WEWEWA BARAT -- 87253", "531805": "WEWEWA SELATAN -- 87263", "531806": "KODI BANGEDO -- 87262", "531807": "KODI -- 87262", "531808": "KODI UTARA -- 87261", "531809": "KOTA TAMBOLAKA -- 87255", "531810": "WEWEWA TENGAH -- 87252", "531811": "KODI BALAGHAR -- 87262", "531901": "BORONG -- 86571", "531902": "POCO RANAKA -- 86583", "531903": "LAMBA LEDA -- 86582", "531904": "SAMBI RAMPAS -- 86584", "531905": "ELAR -- 86581", "531906": "KOTA KOMBA -- 86572", "531907": "RANA MESE -- 86571", "531908": "POCO RANAKA TIMUR -- 86583", "531909": "ELAR SELATAN -- 86581", "532001": "SABU BARAT -- 85391", "532002": "SABU TENGAH -- 85392", "532003": "SABU TIMUR -- 85392", "532004": "SABU LIAE -- 85391", "532005": "HAWU MEHARA -- 85391", "532006": "RAIJUA -- 85393", "532101": "MALAKA TENGAH -- 85762", "532102": "MALAKA BARAT -- 85763", "532103": "WEWIKU -- 85763", "532104": "WELIMAN -- 85763", "532105": "RINHAT -- 85764", "532106": "IO KUFEU -- 85765", "532107": "SASITAMEAN -- 85765", "532108": "LAENMANEN -- 85718", "532109": "MALAKA TIMUR -- 85761", "532110": "KOBALIMA TIMUR -- 85766", "532111": "KOBALIMA -- 85766", "532112": "BOTIN LEOBELE -- 85765", "537101": "ALAK -- 85231", "537102": "MAULAFA -- 85148", "537103": "KELAPA LIMA -- 85228", "537104": "OEBOBO -- 85116", "537105": "KOTA RAJA -- 85119", "537106": "KOTA LAMA -- 85229", "610101": "SAMBAS -- 79462", "610102": "TELUK KERAMAT -- 79465", "610103": "JAWAI -- 79454", "610104": "TEBAS -- 79461", "610105": "PEMANGKAT -- 79453", "610106": "SEJANGKUNG -- 79463", "610107": "SELAKAU -- 79452", "610108": "PALOH -- 79466", "610109": "SAJINGAN BESAR -- 79467", "610110": "SUBAH -- 79417", "610111": "GALING -- 79453", "610112": "TEKARANG -- 79465", "610113": "SEMPARUK -- 79453", "610114": "SAJAD -- 79462", "610115": "SEBAWI -- 79462", "610116": "JAWAI SELATAN -- 79154", "610117": "TANGARAN -- 79465", "610118": "SALATIGA -- 79453", "610119": "SELAKAU TIMUR -- 79452", "610201": "MEMPAWAH HILIR -- 78914", "610206": "TOHO -- 78361", "610207": "SUNGAI PINYUH -- 78353", "610208": "SIANTAN -- 78351", "610212": "SUNGAI KUNYIT -- 78371", "610215": "SEGEDONG -- 78351", "610216": "ANJONGAN -- 78353", "610217": "SADANIANG -- 78361", "610218": "MEMPAWAH TIMUR -- 78917", "610301": "KAPUAS -- 78516", "610302": "MUKOK -- 78581", "610303": "NOYAN -- 78554", "610304": "JANGKANG -- 78591", "610305": "BONTI -- 78552", "610306": "BEDUAI -- 78555", "610307": "SEKAYAM -- 78556", "610308": "KEMBAYAN -- 78553", "610309": "PARINDU -- 78561", "610310": "TAYAN HULU -- 78562", "610311": "TAYAN HILIR -- 78564", "610312": "BALAI -- 78563", "610313": "TOBA -- 78572", "610320": "MELIAU -- 78571", "610321": "ENTIKONG -- 78557", "610401": "MATAN HILIR UTARA -- 78813", "610402": "MARAU -- 78863", "610403": "MANIS MATA -- 78864", "610404": "KENDAWANGAN -- 78862", "610405": "SANDAI -- 78871", "610407": "SUNGAI LAUR -- 78872", "610408": "SIMPANG HULU -- 78854", "610411": "NANGA TAYAP -- 78873", "610412": "MATAN HILIR SELATAN -- 78822", "610413": "TUMBANG TITI -- 78874", "610414": "JELAI HULU -- 78876", "610416": "DELTA PAWAN -- 78813", "610417": "MUARA PAWAN -- 78813", "610418": "BENUA KAYONG -- 78822", "610419": "HULU SUNGAI -- 78871", "610420": "SIMPANG DUA -- 78854", "610421": "AIR UPAS -- 78863", "610422": "SINGKUP -- 78863", "610424": "PEMAHAN -- 78874", "610425": "SUNGAI MELAYU RAYAK -- 78874", "610501": "SINTANG -- 78617", "610502": "TEMPUNAK -- 78661", "610503": "SEPAUK -- 78662", "610504": "KETUNGAU HILIR -- 78652", "610505": "KETUNGAU TENGAH -- 78653", "610506": "KETUNGAU HULU -- 78654", "610507": "DEDAI -- 78691", "610508": "KAYAN HILIR -- 78693", "610509": "KAYAN HULU -- 78694", "610514": "SERAWAI -- 78683", "610515": "AMBALAU -- 78684", "610519": "KELAM PERMAI -- 78656", "610520": "SUNGAI TEBELIAN -- 78655", "610521": "BINJAI HULU -- 78663", "610601": "PUTUSSIBAU UTARA -- 78716", "610602": "BIKA -- 78753", "610603": "EMBALOH HILIR -- 78754", "610604": "EMBALOH HULU -- 78755", "610605": "BUNUT HILIR -- 78761", "610606": "BUNUT HULU -- 78762", "610607": "JONGKONG -- 78763", "610608": "HULU GURUNG -- 78764", "610609": "SELIMBAU -- 78765", "610610": "SEMITAU -- 78771", "610611": "SEBERUANG -- 78772", "610612": "BATANG LUPAR -- 78766", "610613": "EMPANANG -- 78768", "610614": "BADAU -- 78767", "610615": "SILAT HILIR -- 78773", "610616": "SILAT HULU -- 78774", "610617": "PUTUSSIBAU SELATAN -- 78714", "610618": "KALIS -- 78756", "610619": "BOYAN TANJUNG -- 78758", "610620": "MENTEBAH -- 78757", "610621": "PENGKADAN -- 78759", "610622": "SUHAID -- 78775", "610623": "PURING KENCANA -- 78769", "610701": "SUNGAI RAYA -- 78391", "610702": "SAMALANTAN -- 79281", "610703": "LEDO -- 79284", "610704": "BENGKAYANG -- 79211", "610705": "SELUAS -- 79285", "610706": "SANGGAU LEDO -- 79284", "610707": "JAGOI BABANG -- 79286", "610708": "MONTERADO -- 79181", "610709": "TERIAK -- 79214", "610710": "SUTI SEMARANG -- 79283", "610711": "CAPKALA -- 79271", "610712": "SIDING -- 79286", "610713": "LUMAR -- 79283", "610714": "SUNGAI BETUNG -- 79211", "610715": "SUNGAI RAYA KEPULAUAN -- 79271", "610716": "LEMBAH BAWANG -- 79281", "610717": "TUJUH BELAS -- 79251", "610801": "NGABANG -- 79357", "610802": "MEMPAWAH HULU -- 79363", "610803": "MENJALIN -- 79362", "610804": "MANDOR -- 79355", "610805": "AIR BESAR -- 79365", "610806": "MENYUKE -- 79364", "610807": "SENGAH TEMILA -- 79356", "610808": "MERANTI -- 79366", "610809": "KUALA BEHE -- 79367", "610810": "SEBANGKI -- 79358", "610811": "JELIMPO -- 79357", "610812": "BANYUKE HULU -- 79364", "610813": "SOMPAK -- 79363", "610901": "SEKADAU HILIR -- 79582", "610902": "SEKADAU HULU -- 79583", "610903": "NANGA TAMAN -- 79584", "610904": "NANGA MAHAP -- 79585", "610905": "BELITANG HILIR -- 79586", "610906": "BELITANG HULU -- 79587", "610907": "BELITANG -- 79587", "611001": "BELIMBING -- 79671", "611002": "NANGA PINOH -- 79672", "611003": "ELLA HILIR -- 79681", "611004": "MENUKUNG -- 79682", "611005": "SAYAN -- 79673", "611006": "TANAH PINOH -- 79674", "611007": "SOKAN -- 79675", "611008": "PINOH UTARA -- 79672", "611009": "PINOH SELATAN -- 79672", "611010": "BELIMBING HULU -- 79671", "611011": "TANAH PINOH BARAT -- 79674", "611101": "SUKADANA -- 78852", "611102": "SIMPANG HILIR -- 78853", "611103": "TELUK BATANG -- 78856", "611105": "SEPONTI -- 78857", "611106": "KEPULAUAN KARIMATA -- 78855", "611201": "SUNGAI RAYA -- 78391", "611202": "KUALA MANDOR B -- -", "611203": "SUNGAI AMBAWANG -- 78393", "611204": "TERENTANG -- 78392", "611205": "BATU AMPAR -- 78385", "611206": "KUBU -- 78384", "611207": "RASAU JAYA -- 78382", "611208": "TELUK PAKEDAI -- -", "611209": "SUNGAI KAKAP -- 78381", "617101": "PONTIANAK SELATAN -- 78121", "617102": "PONTIANAK TIMUR -- 78233", "617103": "PONTIANAK BARAT -- 78114", "617104": "PONTIANAK UTARA -- 78244", "617105": "PONTIANAK KOTA -- 78117", "617106": "PONTIANAK TENGGARA -- 78124", "617201": "SINGKAWANG TENGAH -- 79114", "617202": "SINGKAWANG BARAT -- 79124", "617203": "SINGKAWANG TIMUR -- 79251", "617204": "SINGKAWANG UTARA -- 79151", "617205": "SINGKAWANG SELATAN -- 79163", "620101": "KUMAI -- 74181", "620102": "ARUT SELATAN -- 74113", "620103": "KOTAWARINGIN LAMA -- 74161", "620104": "ARUT UTARA -- 74152", "620105": "PANGKALAN LADA -- 74184", "620106": "PANGKALAN BANTENG -- 74183", "620201": "KOTA BESI -- 74353", "620202": "CEMPAGA -- 74354", "620203": "MENTAYA HULU -- 74356", "620204": "PARENGGEAN -- 74355", "620205": "BAAMANG -- 74312", "620206": "MENTAWA BARU KETAPANG -- -", "620207": "MENTAYA HILIR UTARA -- 74361", "620208": "MENTAYA HILIR SELATAN -- 74363", "620209": "PULAU HANAUT -- 74362", "620210": "ANTANG KALANG -- 74352", "620211": "TELUK SAMPIT -- 74363", "620212": "SERANAU -- 74315", "620213": "CEMPAGA HULU -- 74354", "620214": "TELAWANG -- 74353", "620215": "BUKIT SANTUAI -- -", "620216": "TUALAN HULU -- 74355", "620217": "TELAGA ANTANG -- 74352", "620301": "SELAT -- 74113", "620302": "KAPUAS HILIR -- 73525", "620303": "KAPUAS TIMUR -- 73581", "620304": "KAPUAS KUALA -- 73583", "620305": "KAPUAS BARAT -- 73552", "620306": "PULAU PETAK -- 73592", "620307": "KAPUAS MURUNG -- 73593", "620308": "BASARANG -- 73564", "620309": "MANTANGAI -- 73553", "620310": "TIMPAH -- 73554", "620311": "KAPUAS TENGAH -- 73555", "620312": "KAPUAS HULU -- 74581", "620313": "TAMBAN CATUR -- 73583", "620314": "PASAK TALAWANG -- 73555", "620315": "MANDAU TALAWANG -- 73555", "620316": "DADAHUP -- 73593", "620317": "BATAGUH -- 73516", "620401": "JENAMAS -- 73763", "620402": "DUSUN HILIR -- 73762", "620403": "KARAU KUALA -- 73761", "620404": "DUSUN UTARA -- 73752", "620405": "GN. BINTANG AWAI -- -", "620406": "DUSUN SELATAN -- 73713", "620501": "MONTALLAT -- 73861", "620502": "GUNUNG TIMANG -- 73862", "620503": "GUNUNG PUREI -- 73871", "620504": "TEWEH TIMUR -- 73881", "620505": "TEWEH TENGAH -- 73814", "620506": "LAHEI -- 73852", "620508": "TEWEH SELATAN -- 73814", "620509": "LAHEI BARAT -- 73852", "620601": "KAMPIANG -- -", "620602": "KATINGAN HILIR -- 74413", "620603": "TEWANG SANGALANG GARING -- -", "620604": "PULAU MALAN -- 74453", "620605": "KATINGAN TENGAH -- 74454", "620606": "SANAMAN MANTIKEI -- 74455", "620607": "MARIKIT -- 74456", "620608": "KATINGAN HULU -- 74457", "620609": "MENDAWAI -- 74463", "620610": "KATINGAN KUALA -- 74463", "620611": "TASIK PAYAWAN -- 74461", "620612": "PETAK MALAI -- 74455", "620613": "BUKIT RAYA -- 74457", "620701": "SERUYAN HILIR -- 74215", "620702": "SERUYAN TENGAH -- 74281", "620703": "DANAU SEMBULUH -- 74261", "620704": "HANAU -- 74362", "620705": "SERUYAN HULU -- 74291", "620706": "SERUYAN HILIR TIMUR -- 74215", "620707": "SERUYAN RAYA -- 74261", "620708": "DANAU SELULUK -- 74271", "620709": "BATU AMPAR -- 74281", "620710": "SULING TAMBUN -- 74291", "620801": "SUKAMARA -- 74172", "620802": "JELAI -- 74171", "620803": "BALAI RIAM -- 74173", "620804": "PANTAI LUNCI -- 74171", "620805": "PERMATA KECUBUNG -- 74173", "620901": "LAMANDAU -- 74663", "620902": "DELANG -- 74664", "620903": "BULIK -- 74162", "620904": "BULIK TIMUR -- 74162", "620905": "MENTHOBI RAYA -- 74162", "620906": "SEMATU JAYA -- 74162", "620907": "BELANTIKAN RAYA -- 74663", "620908": "BATANG KAWA -- 74664", "621001": "SEPANG SIMIN -- 74571", "621002": "KURUN -- 74511", "621003": "TEWAH -- 74552", "621004": "KAHAYAN HULU UTARA -- 74553", "621005": "RUNGAN -- 74561", "621006": "MANUHING -- 74562", "621007": "MIHING RAYA -- 74571", "621008": "DAMANG BATU -- 74553", "621009": "MIRI MANASA -- 74553", "621010": "RUNGAN HULU -- 74561", "621011": "MAHUNING RAYA -- -", "621101": "PANDIH BATU -- 74871", "621102": "KAHAYAN KUALA -- 74872", "621103": "KAHAYAN TENGAH -- 74862", "621104": "BANAMA TINGANG -- 74863", "621105": "KAHAYAN HILIR -- 74813", "621106": "MALIKU -- 74873", "621107": "JABIREN -- 74816", "621108": "SEBANGAU KUALA -- 74874", "621201": "MURUNG -- 73911", "621202": "TANAH SIANG -- 73961", "621203": "LAUNG TUHUP -- 73991", "621204": "PERMATA INTAN -- 73971", "621205": "SUMBER BARITO -- 73981", "621206": "BARITO TUHUP RAYA -- 73991", "621207": "TANAH SIANG SELATAN -- 73961", "621208": "SUNGAI BABUAT -- 73971", "621209": "SERIBU RIAM -- 73981", "621210": "UUT MURUNG -- 73981", "621301": "DUSUN TIMUR -- 73618", "621302": "BANUA LIMA -- -", "621303": "PATANGKEP TUTUI -- 73671", "621304": "AWANG -- 73681", "621305": "DUSUN TENGAH -- 73652", "621306": "PEMATANG KARAU -- 73653", "621307": "PAJU EPAT -- 73617", "621308": "RAREN BATUAH -- 73652", "621309": "PAKU -- 73652", "621310": "KARUSEN JANANG -- 73652", "627101": "PAHANDUT -- 73111", "627102": "BUKIT BATU -- 73224", "627103": "JEKAN RAYA -- 73112", "627104": "SABANGAU -- -", "627105": "RAKUMPIT -- 73229", "630101": "TAKISUNG -- 70861", "630102": "JORONG -- 70881", "630103": "PELAIHARI -- 70815", "630104": "KURAU -- 70853", "630105": "BATI BATI -- -", "630106": "PANYIPATAN -- 70871", "630107": "KINTAP -- 70883", "630108": "TAMBANG ULANG -- 70854", "630109": "BATU AMPAR -- 70882", "630110": "BAJUIN -- 70815", "630111": "BUMI MAKMUR -- 70853", "630201": "PULAUSEMBILAN -- 72181", "630202": "PULAULAUT BARAT -- 72153", "630203": "PULAULAUT SELATAN -- 72154", "630204": "PULAULAUT TIMUR -- 72152", "630205": "PULAUSEBUKU -- 72155", "630206": "PULAULAUT UTARA -- 72115", "630207": "KELUMPANG SELATAN -- 72161", "630208": "KELUMPANG HULU -- 72162", "630209": "KELUMPANG TENGAH -- 72164", "630210": "KELUMPANG UTARA -- 72165", "630211": "PAMUKAN SELATAN -- 72168", "630212": "SAMPANAHAN -- 72166", "630213": "PAMUKAN UTARA -- 72169", "630214": "HAMPANG -- 72163", "630215": "SUNGAIDURIAN -- 72167", "630216": "PULAULAUT TENGAH -- 72156", "630217": "KELUMPANG HILIR -- 72161", "630218": "KELUMPANG BARAT -- 72164", "630219": "PAMUKAN BARAT -- 72169", "630220": "PULAULAUT KEPULAUAN -- 72154", "630221": "PULAULAUT TANJUNG SELAYAR -- 72153", "630301": "ALUH ALUH -- -", "630302": "KERTAK HANYAR -- 70654", "630303": "GAMBUT -- 70652", "630304": "SUNGAI TABUK -- 70653", "630305": "MARTAPURA -- 70617", "630306": "KARANG INTAN -- 70661", "630307": "ASTAMBUL -- 70671", "630308": "SIMPANG EMPAT -- 70673", "630309": "PENGAROM -- -", "630310": "SUNGAI PINANG -- 70675", "630311": "ARANIO -- 70671", "630312": "MATARAMAN -- 70672", "630313": "BERUNTUNG BARU -- 70655", "630314": "MARTAPURA BARAT -- 70618", "630315": "MARTAPURA TIMUR -- 70617", "630316": "SAMBUNG MAKMUR -- 70674", "630317": "PARAMASAN -- -", "630318": "TELAGA BAUNTUNG -- 70673", "630319": "TATAH MAKMUR -- 70654", "630401": "TABUNGANEN -- 70567", "630402": "TAMBAN -- 70854", "630403": "ANJIR PASAR -- 70565", "630404": "ANJIR MUARA -- 70564", "630405": "ALALAK -- 70582", "630406": "MANDASTANA -- 70581", "630407": "RANTAU BADAUH -- 70561", "630408": "BELAWANG -- 70563", "630409": "CERBON -- 70571", "630410": "BAKUMPAI -- 70513", "630411": "KURIPAN -- 70552", "630412": "TABUKAN -- 70553", "630413": "MEKARSARI -- 70568", "630414": "BARAMBAI -- 70562", "630415": "MARABAHAN -- 70511", "630416": "WANARAYA -- 70562", "630417": "JEJANGKIT -- 70581", "630501": "BINUANG -- 71183", "630502": "TAPIN SELATAN -- 71181", "630503": "TAPIN TENGAH -- 71161", "630504": "TAPIN UTARA -- 71114", "630505": "CANDI LARAS SELATAN -- 71162", "630506": "CANDI LARAS UTARA -- 71171", "630507": "BAKARANGAN -- 71152", "630508": "PIANI -- 71191", "630509": "BUNGUR -- 71153", "630510": "LOKPAIKAT -- 71154", "630511": "SALAM BABARIS -- 71185", "630512": "HATUNGUN -- 71184", "630601": "SUNGAI RAYA -- 71271", "630602": "PADANG BATUNG -- 71281", "630603": "TELAGA LANGSAT -- 71292", "630604": "ANGKINANG -- 71291", "630605": "KANDANGAN -- 71213", "630606": "SIMPUR -- 71261", "630607": "DAHA SELATAN -- 71252", "630608": "DAHA UTARA -- 71253", "630609": "KALUMPANG -- 71262", "630610": "LOKSADO -- 71282", "630611": "DAHA BARAT -- 71252", "630701": "HARUYAN -- 71363", "630702": "BATU BENAWA -- 71371", "630703": "LABUAN AMAS SELATAN -- 71361", "630704": "LABUAN AMAS UTARA -- 71362", "630705": "PANDAWAN -- 71352", "630706": "BARABAI -- 71315", "630707": "BATANG ALAI SELATAN -- 71381", "630708": "BATANG ALAI UTARA -- 71391", "630709": "HANTAKAN -- 71372", "630710": "BATANG ALAI TIMUR -- 71382", "630711": "LIMPASU -- 71391", "630801": "DANAU PANGGANG -- 71453", "630802": "BABIRIK -- 71454", "630803": "SUNGAI PANDAN -- 71455", "630804": "AMUNTAI SELATAN -- 71452", "630805": "AMUNTAI TENGAH -- 71419", "630806": "AMUNTAI UTARA -- 71471", "630807": "BANJANG -- 71416", "630808": "HAUR GADING -- 71471", "630809": "PAMINGGIR -- 71453", "630810": "SUNGAI TABUKAN -- 71455", "630901": "BANUA LAWAS -- 71553", "630902": "KELUA -- 71552", "630903": "TANTA -- 71561", "630904": "TANJUNG -- 71514", "630905": "HARUAI -- 71572", "630906": "MURUNG PUDAK -- 71571", "630907": "MUARA UYA -- 71573", "630908": "MUARA HARUS -- 71555", "630909": "PUGAAN -- 71554", "630910": "UPAU -- 71575", "630911": "JARO -- 71574", "630912": "BINTANG ARA -- 71572", "631001": "BATU LICIN -- 72271", "631002": "KUSAN HILIR -- 72273", "631003": "SUNGAI LOBAN -- 72274", "631004": "SATUI -- 72275", "631005": "KUSAN HULU -- 72272", "631006": "SIMPANG EMPAT -- 70673", "631007": "KARANG BINTANG -- 72211", "631008": "MANTEWE -- 72211", "631009": "ANGSANA -- 72275", "631010": "KURANJI -- 72272", "631101": "JUAI -- 71665", "631102": "HALONG -- 71666", "631103": "AWAYAN -- 71664", "631104": "BATU MANDI -- 71663", "631105": "LAMPIHONG -- 71661", "631106": "PARINGIN -- 71662", "631107": "PARINGIN SELATAN -- 71662", "631108": "TEBING TINGGI -- 71664", "637101": "BANJARMASIN SELATAN -- 70245", "637102": "BANJARMASIN TIMUR -- 70239", "637103": "BANJARMASIN BARAT -- 70245", "637104": "BANJARMASIN UTARA -- 70126", "637105": "BANJARMASIN TENGAH -- 70114", "637202": "LANDASAN ULIN -- 70724", "637203": "CEMPAKA -- 70732", "637204": "BANJARBARU UTARA -- 70714", "637205": "BANJARBARU SELATAN -- 70713", "637206": "LIANG ANGGANG -- 70722", "640101": "BATU SOPANG -- 76252", "640102": "TANJUNG HARAPAN -- 76261", "640103": "PASIR BALENGKONG -- -", "640104": "TANAH GROGOT -- 76251", "640105": "KUARO -- 76281", "640106": "LONG IKIS -- 76282", "640107": "MUARA KOMAM -- 76253", "640108": "LONG KALI -- 76283", "640109": "BATU ENGAU -- 76261", "640110": "MUARA SAMU -- 76252", "640201": "MUARA MUNTAI -- 75562", "640202": "LOA KULU -- 75571", "640203": "LOA JANAN -- 75391", "640204": "ANGGANA -- 75381", "640205": "MUARA BADAK -- 75382", "640206": "TENGGARONG -- 75572", "640207": "SEBULU -- 75552", "640208": "KOTA BANGUN -- 75561", "640209": "KENOHAN -- 75564", "640210": "KEMBANG JANGGUT -- 75557", "640211": "MUARA KAMAN -- 75553", "640212": "TABANG -- 75561", "640213": "SAMBOJA -- 75274", "640214": "MUARA JAWA -- 75265", "640215": "SANGA SANGA -- -", "640216": "TENGGARONG SEBERANG -- 75572", "640217": "MARANG KAYU -- 75385", "640218": "MUARA WIS -- 75559", "640301": "KELAY -- 77362", "640302": "TALISAYAN -- 77372", "640303": "SAMBALIUNG -- 77371", "640304": "SEGAH -- 77361", "640305": "TANJUNG REDEB -- 77312", "640306": "GUNUNG TABUR -- 77352", "640307": "PULAU DERAWAN -- 77381", "640308": "BIDUK-BIDUK -- 77373", "640309": "TELUK BAYUR -- 77352", "640310": "TABALAR -- 77372", "640311": "MARATUA -- 77381", "640312": "BATU PUTIH -- 77373", "640313": "BIATAN -- 77372", "640705": "LONG IRAM -- 75766", "640706": "MELAK -- 75765", "640707": "BARONG TONGKOK -- 75776", "640708": "DAMAI -- 75777", "640709": "MUARA LAWA -- 75775", "640710": "MUARA PAHU -- 75774", "640711": "JEMPANG -- 75773", "640712": "BONGAN -- 75772", "640713": "PENYINGGAHAN -- 75763", "640714": "BENTIAN BESAR -- 75778", "640715": "LINGGANG BIGUNG -- 75576", "640716": "NYUATAN -- 75776", "640717": "SILUQ NGURAI -- 75774", "640718": "MOOK MANAAR BULATN -- 75774", "640719": "TERING -- 75766", "640720": "SEKOLAQ DARAT -- 75765", "640801": "MUARA ANCALONG -- 75656", "640802": "MUARA WAHAU -- 75655", "640803": "MUARA BENGKAL -- 75654", "640804": "SANGATTA UTARA -- 75683", "640805": "SANGKULIRANG -- 75684", "640806": "BUSANG -- 75556", "640807": "TELEN -- 75555", "640808": "KOMBENG -- -", "640809": "BENGALON -- 75618", "640810": "KALIORANG -- 75618", "640811": "SANDARAN -- 75685", "640812": "SANGATTA SELATAN -- 75683", "640813": "TELUK PANDAN -- 75683", "640814": "RANTAU PULUNG -- 75683", "640815": "KAUBUN -- 75619", "640816": "KARANGAN -- 75684", "640817": "BATU AMPAR -- 75654", "640818": "LONG MESANGAT -- 75656", "640901": "PENAJAM -- 76141", "640902": "WARU -- 76284", "640903": "BABULU -- 76285", "640904": "SEPAKU -- 76147", "641101": "LONG BAGUN -- 75767", "641102": "LONG HUBUNG -- 75779", "641103": "LAHAM -- 75779", "641104": "LONG APARI -- 75769", "641105": "LONG PAHANGAI -- 75768", "647101": "BALIKPAPAN TIMUR -- 76117", "647102": "BALIKPAPAN BARAT -- 76131", "647103": "BALIKPAPAN UTARA -- 76136", "647104": "BALIKPAPAN TENGAH -- 76121", "647105": "BALIKPAPAN SELATAN -- 76114", "647106": "BALIKPAPAN KOTA -- 76114", "647201": "PALARAN -- 75253", "647202": "SAMARINDA SEBERANG -- 75131", "647203": "SAMARINDA ULU -- 75124", "647204": "SAMARINDA ILIR -- 75117", "647205": "SAMARINDA UTARA -- 75118", "647206": "SUNGAI KUNJANG -- 75125", "647207": "SAMBUTAN -- 75115", "647208": "SUNGAI PINANG -- 75119", "647209": "SAMARINDA KOTA -- 75121", "647210": "LOA JANAN ILIR -- 75131", "647401": "BONTANG UTARA -- 75311", "647402": "BONTANG SELATAN -- 75325", "647403": "BONTANG BARAT -- 75313", "650101": "TANJUNG PALAS -- 77211", "650102": "TANJUNG PALAS BARAT -- 77217", "650103": "TANJUNG PALAS UTARA -- 77215", "650104": "TANJUNG PALAS TIMUR -- 77215", "650105": "TANJUNG SELOR -- 77212", "650106": "TANJUNG PALAS TENGAH -- 77216", "650107": "PESO -- 77261", "650108": "PESO HILIR -- 77261", "650109": "SEKATAK -- 77263", "650110": "BUNYU -- 77281", "650201": "MENTARANG -- 77555", "650202": "MALINAU KOTA -- 77554", "650203": "PUJUNGAN -- 77562", "650204": "KAYAN HILIR -- 77571", "650205": "KAYAN HULU -- 77572", "650206": "MALINAU SELATAN -- 77554", "650207": "MALINAU UTARA -- 77554", "650208": "MALINAU BARAT -- 77554", "650209": "SUNGAI BOH -- 77573", "650210": "KAYAN SELATAN -- 77573", "650211": "BAHAU HULU -- 77562", "650212": "MENTARANG HULU -- 77155", "650213": "MALINAU SELATAN HILIR -- 77554", "650214": "MALINAU SELATAN HULU -- 77554", "650215": "SUNGAI TUBU -- 77555", "650301": "SEBATIK -- 77483", "650302": "NUNUKAN -- 77482", "650303": "SEMBAKUNG -- 77453", "650304": "LUMBIS -- 77457", "650305": "KRAYAN -- 77456", "650306": "SEBUKU -- 77482", "650307": "KRAYAN SELATAN -- 77456", "650308": "SEBATIK BARAT -- 77483", "650309": "NUNUKAN SELATAN -- 77482", "650310": "SEBATIK TIMUR -- 77483", "650311": "SEBATIK UTARA -- 77483", "650312": "SEBATIK TENGAH -- 77483", "650313": "SEI MENGGARIS -- 77482", "650314": "TULIN ONSOI -- 77482", "650315": "LUMBIS OGONG -- 77457", "650316": "SEMBAKUNG ATULAI -- -", "650401": "SESAYAP -- 77152", "650402": "SESAYAP HILIR -- 77152", "650403": "TANA LIA -- 77453", "650405": "MURUK RIAN -- -", "657101": "TARAKAN BARAT -- 77111", "657102": "TARAKAN TENGAH -- 77113", "657103": "TARAKAN TIMUR -- 77115", "657104": "TARAKAN UTARA -- 77116", "710105": "SANG TOMBOLANG -- 95762", "710109": "DUMOGA BARAT -- 95773", "710110": "DUMOGA TIMUR -- 95772", "710111": "DUMOGA UTARA -- 95772", "710112": "LOLAK -- 95761", "710113": "BOLAANG -- 95752", "710114": "LOLAYAN -- 95771", "710119": "PASSI BARAT -- 95751", "710120": "POIGAR -- 95753", "710122": "PASSI TIMUR -- 95751", "710131": "BOLAANG TIMUR -- 95752", "710132": "BILALANG -- 95751", "710133": "DUMOGA -- 95772", "710134": "DUMOGA TENGGARA -- 95772", "710135": "DUMOGA TENGAH -- 95773", "710201": "TONDANO BARAT -- 95616", "710202": "TONDANO TIMUR -- 95612", "710203": "ERIS -- 95683", "710204": "KOMBI -- 95684", "710205": "LEMBEAN TIMUR -- 95683", "710206": "KAKAS -- 95682", "710207": "TOMPASO -- 95693", "710208": "REMBOKEN -- 95681", "710209": "LANGOWAN TIMUR -- 95694", "710210": "LANGOWAN BARAT -- 95694", "710211": "SONDER -- 95691", "710212": "KAWANGKOAN -- 95692", "710213": "PINELENG -- 95661", "710214": "TOMBULU -- 95661", "710215": "TOMBARIRI -- 95651", "710216": "TONDANO UTARA -- 95614", "710217": "LANGOWAN SELATAN -- 95694", "710218": "TONDANO SELATAN -- 95618", "710219": "LANGOWAN UTARA -- 95694", "710220": "KAKAS BARAT -- 95682", "710221": "KAWANGKOAN UTARA -- 95692", "710222": "KAWANGKOAN BARAT -- 95692", "710223": "MANDOLANG -- 95661", "710224": "TOMBARIRI TIMUR -- 95651", "710225": "TOMPASO BARAT -- 95693", "710308": "TABUKAN UTARA -- 95856", "710309": "NUSA TABUKAN -- 95856", "710310": "MANGANITU SELATAN -- 95854", "710311": "TATOARENG -- 95854", "710312": "TAMAKO -- 95855", "710313": "MANGANITU -- 95853", "710314": "TABUKAN TENGAH -- 95857", "710315": "TABUKAN SELATAN -- 95858", "710316": "KENDAHE -- 95852", "710317": "TAHUNA -- 95818", "710319": "TABUKAN SELATAN TENGAH -- 95858", "710320": "TABUKAN SELATAN TENGGARA -- 95858", "710323": "TAHUNA BARAT -- 95818", "710324": "TAHUNA TIMUR -- 95814", "710325": "KEPULAUAN MARORE -- 95856", "710401": "LIRUNG -- 95871", "710402": "BEO -- 95881", "710403": "RAINIS -- 95882", "710404": "ESSANG -- 95883", "710405": "NANUSA -- 95884", "710406": "KABARUAN -- 95872", "710407": "MELONGUANE -- 95885", "710408": "GEMEH -- 95883", "710409": "DAMAU -- 95872", "710410": "TAMPAN' AMMA -- -", "710411": "SALIBABU -- 95871", "710412": "KALONGAN -- 95871", "710413": "MIANGAS -- 95884", "710414": "BEO UTARA -- 95881", "710415": "PULUTAN -- 95882", "710416": "MELONGUANE TIMUR -- 95885", "710417": "MORONGE -- 95871", "710418": "BEO SELATAN -- 95881", "710419": "ESSANG SELATAN -- 95883", "710501": "MODOINDING -- 95958", "710502": "TOMPASO BARU -- 95357", "710503": "RANOYAPO -- 95999", "710507": "MOTOLING -- 95956", "710508": "SINONSAYANG -- 95959", "710509": "TENGA -- 95775", "710510": "AMURANG -- 95954", "710512": "TUMPAAN -- 95352", "710513": "TARERAN -- 95953", "710515": "KUMELEMBUAI -- 95956", "710516": "MAESAAN -- 95357", "710517": "AMURANG BARAT -- 95955", "710518": "AMURANG TIMUR -- 95954", "710519": "TATAPAAN -- 95352", "710521": "MOTOLING BARAT -- 95956", "710522": "MOTOLING TIMUR -- 95956", "710523": "SULUUN TARERAN -- 95953", "710601": "KEMA -- 95379", "710602": "KAUDITAN -- 95372", "710603": "AIRMADIDI -- 95371", "710604": "WORI -- 95376", "710605": "DIMEMBE -- 95373", "710606": "LIKUPANG BARAT -- 95377", "710607": "LIKUPANG TIMUR -- 95375", "710608": "KALAWAT -- 95378", "710609": "TALAWAAN -- 95373", "710610": "LIKUPANG SELATAN -- 95375", "710701": "RATAHAN -- 95995", "710702": "PUSOMAEN -- 95997", "710703": "BELANG -- 95997", "710704": "RATATOTOK -- 95997", "710705": "TOMBATU -- 95996", "710706": "TOULUAAN -- 95998", "710707": "TOULUAAN SELATAN -- 95998", "710708": "SILIAN RAYA -- 95998", "710709": "TOMBATU TIMUR -- 95996", "710710": "TOMBATU UTARA -- 95996", "710711": "PASAN -- 95995", "710712": "RATAHAN TIMUR -- 95995", "710801": "SANGKUB -- 95762", "710802": "BINTAUNA -- 95763", "710803": "BOLANGITANG TIMUR -- 95764", "710804": "BOLANGITANG BARAT -- 95764", "710805": "KAIDIPANG -- 95765", "710806": "PINOGALUMAN -- 95765", "710901": "SIAU TIMUR -- 95861", "710902": "SIAU BARAT -- 95862", "710903": "TAGULANDANG -- 95863", "710904": "SIAU TIMUR SELATAN -- 95861", "710905": "SIAU BARAT SELATAN -- 95862", "710906": "TAGULANDANG UTARA -- 95863", "710907": "BIARO -- 95864", "710908": "SIAU BARAT UTARA -- 95862", "710909": "SIAU TENGAH -- 95861", "710910": "TAGULANDANG SELATAN -- 95863", "711001": "TUTUYAN -- 95782", "711002": "KOTABUNAN -- 95782", "711003": "NUANGAN -- 95775", "711004": "MODAYAG -- 95781", "711005": "MODAYAG BARAT -- 95781", "711101": "BOLAANG UKI -- 95774", "711102": "POSIGADAN -- 95774", "711103": "PINOLOSIAN -- 95775", "711104": "PINOLOSIAN TENGAH -- 95775", "711105": "PINOLOSIAN TIMUR -- 95775", "717101": "BUNAKEN -- 95231", "717102": "TUMINITING -- 95239", "717103": "SINGKIL -- 95231", "717104": "WENANG -- 95113", "717105": "TIKALA -- 95125", "717106": "SARIO -- 95116", "717107": "WANEA -- 95117", "717108": "MAPANGET -- 95251", "717109": "MALALAYANG -- 95115", "717110": "BUNAKEN KEPULAUAN -- 95231", "717111": "PAAL DUA -- 95127", "717201": "LEMBEH SELATAN -- 95552", "717202": "MADIDIR -- 95513", "717203": "RANOWULU -- 95537", "717204": "AERTEMBAGA -- 95526", "717205": "MATUARI -- 95545", "717206": "GIRIAN -- 95544", "717207": "MAESA -- 95511", "717208": "LEMBEH UTARA -- 95551", "717301": "TOMOHON SELATAN -- 95433", "717302": "TOMOHON TENGAH -- 95441", "717303": "TOMOHON UTARA -- 95416", "717304": "TOMOHON BARAT -- 95424", "717305": "TOMOHON TIMUR -- 95449", "717401": "KOTAMOBAGU UTARA -- 95713", "717402": "KOTAMOBAGU TIMUR -- 95719", "717403": "KOTAMOBAGU SELATAN -- 95717", "717404": "KOTAMOBAGU BARAT -- 95715", "720101": "BATUI -- 94762", "720102": "BUNTA -- 94753", "720103": "KINTOM -- 94761", "720104": "LUWUK -- 94711", "720105": "LAMALA -- 94771", "720106": "BALANTAK -- 94773", "720107": "PAGIMANA -- 94752", "720108": "BUALEMO -- 94752", "720109": "TOILI -- 94765", "720110": "MASAMA -- 94772", "720111": "LUWUK TIMUR -- 94723", "720112": "TOILI BARAT -- 94765", "720113": "NUHON -- 94753", "720114": "MOILONG -- 94765", "720115": "BATUI SELATAN -- 94762", "720116": "LOBU -- 94752", "720117": "SIMPANG RAYA -- 94753", "720118": "BALANTAK SELATAN -- 94773", "720119": "BALANTAK UTARA -- 94773", "720120": "LUWUK SELATAN -- 94717", "720121": "LUWUK UTARA -- 94711", "720122": "MANTOH -- 94771", "720123": "NAMBO -- 94761", "720201": "POSO KOTA -- 94616", "720202": "POSO PESISIR -- 94652", "720203": "LAGE -- 94661", "720204": "PAMONA PUSELEMBA -- 94663", "720205": "PAMONA TIMUR -- 94663", "720206": "PAMONA SELATAN -- 94664", "720207": "LORE UTARA -- 94653", "720208": "LORE TENGAH -- 94653", "720209": "LORE SELATAN -- 94654", "720218": "POSO PESISIR UTARA -- 94652", "720219": "POSO PESISIR SELATAN -- 94652", "720220": "PAMONA BARAT -- 94664", "720221": "POSO KOTA SELATAN -- 94614", "720222": "POSO KOTA UTARA -- 94616", "720223": "LORE BARAT -- 94654", "720224": "LORE TIMUR -- 94653", "720225": "LORE PIORE -- 94653", "720226": "PAMONA TENGGARA -- 94664", "720227": "PAMONA UTARA -- 94663", "720304": "RIO PAKAVA -- 94362", "720308": "BANAWA -- 94351", "720309": "LABUAN -- 94352", "720310": "SINDUE -- 94353", "720311": "SIRENJA -- 94354", "720312": "BALAESANG -- 94355", "720314": "SOJOL -- 94356", "720318": "BANAWA SELATAN -- 94351", "720319": "TANANTOVEA -- 94352", "720321": "PANEMBANI -- -", "720324": "SINDUE TOMBUSABORA -- 94353", "720325": "SINDUE TOBATA -- 94353", "720327": "BANAWA TENGAH -- 94351", "720330": "SOJOL UTARA -- 94356", "720331": "BALAESANG TANJUNG -- 94355", "720401": "DAMPAL SELATAN -- 94554", "720402": "DAMPAL UTARA -- 94553", "720403": "DONDO -- 94552", "720404": "BASIDONDO -- 94552", "720405": "OGODEIDE -- 94516", "720406": "LAMPASIO -- 94518", "720407": "BAOLAN -- 94514", "720408": "GALANG -- 94561", "720409": "TOLI-TOLI UTARA -- -", "720410": "DAKO PEMEAN -- -", "720501": "MOMUNU -- 94565", "720502": "LAKEA -- 94563", "720503": "BOKAT -- 94566", "720504": "BUNOBOGU -- 94567", "720505": "PALELEH -- 94568", "720507": "TILOAN -- 94565", "720508": "BUKAL -- 94563", "720509": "GADUNG -- 94568", "720510": "KARAMAT -- 94563", "720511": "PALELEH BARAT -- 94568", "720605": "BUNGKU TENGAH -- 94973", "720606": "BUNGKU SELATAN -- 94974", "720607": "MENUI KEPULAUAN -- 94975", "720608": "BUNGKU BARAT -- 94976", "720609": "BUMI RAYA -- 94976", "720610": "BAHODOPI -- 94974", "720612": "WITA PONDA -- 94976", "720615": "BUNGKU PESISIR -- 94974", "720618": "BUNGKU TIMUR -- 94973", "720703": "TOTIKUM -- 94884", "720704": "TINANGKUNG -- 94885", "720705": "LIANG -- 94883", "720706": "BULAGI -- 94882", "720707": "BUKO -- 94881", "720709": "BULAGI SELATAN -- 94882", "720711": "TINANGKUNG SELATAN -- 94885", "720715": "TOTIKUM SELATAN -- 94884", "720716": "PELING TENGAH -- 94883", "720717": "BULAGI UTARA -- 94882", "720718": "BUKO SELATAN -- 94881", "720719": "TINANGKUNG UTARA -- 94885", "720801": "PARIGI -- 94471", "720802": "AMPIBABO -- 94474", "720803": "TINOMBO -- 94475", "720804": "MOUTONG -- 94479", "720805": "TOMINI -- 94476", "720806": "SAUSU -- 94473", "720807": "BOLANO LAMBUNU -- 94479", "720808": "KASIMBAR -- 94474", "720809": "TORUE -- 94473", "720810": "TINOMBO SELATAN -- 94475", "720811": "PARIGI SELATAN -- 94471", "720812": "MEPANGA -- 94476", "720813": "TORIBULU -- 94474", "720814": "TAOPA -- 94479", "720815": "BALINGGI -- 94473", "720816": "PARIGI BARAT -- 94471", "720817": "SINIU -- 94474", "720818": "PALASA -- 94476", "720819": "PARIGI UTARA -- 94471", "720820": "PARIGI TENGAH -- 94471", "720821": "BOLANO -- 94479", "720822": "ONGKA MALINO -- 94479", "720823": "SIDOAN -- -", "720901": "UNA UNA -- -", "720902": "TOGEAN -- 94683", "720903": "WALEA KEPULAUAN -- 94692", "720904": "AMPANA TETE -- 94684", "720905": "AMPANA KOTA -- 94683", "720906": "ULUBONGKA -- 94682", "720907": "TOJO BARAT -- 94681", "720908": "TOJO -- 94681", "720909": "WALEA BESAR -- 94692", "720910": "RATOLINDO -- -", "720911": "BATUDAKA -- -", "720912": "TALATAKO -- -", "721001": "SIGI BIROMARU -- 94364", "721002": "PALOLO -- 94364", "721003": "NOKILALAKI -- 94364", "721004": "LINDU -- 94363", "721005": "KULAWI -- 94363", "721006": "KULAWI SELATAN -- 94363", "721007": "PIPIKORO -- 94112", "721008": "GUMBASA -- 94364", "721009": "DOLO SELATAN -- 94361", "721010": "TANAMBULAVA -- 94364", "721011": "DOLO BARAT -- 94361", "721012": "DOLO -- 94361", "721013": "KINOVARO -- -", "721014": "MARAWOLA -- 94362", "721015": "MARAWOLA BARAT -- 94362", "721101": "BANGGAI -- 94891", "721102": "BANGGAI UTARA -- 94891", "721103": "BOKAN KEPULAUAN -- 94892", "721104": "BANGKURUNG -- 94892", "721105": "LABOBO -- 94892", "721106": "BANGGAI SELATAN -- 94891", "721107": "BANGGAI TENGAH -- 94891", "721201": "PETASIA -- 94971", "721202": "PETASIA TIMUR -- 94971", "721203": "LEMBO RAYA -- 94966", "721204": "LEMBO -- 94966", "721205": "MORI ATAS -- 94965", "721206": "MORI UTARA -- 94965", "721207": "SOYO JAYA -- 94971", "721208": "BUNGKU UTARA -- 94972", "721209": "MAMOSALATO -- 94972", "727101": "PALU TIMUR -- 94111", "727102": "PALU BARAT -- 94226", "727103": "PALU SELATAN -- 94231", "727104": "PALU UTARA -- 94146", "727105": "ULUJADI -- 94228", "727106": "TATANGA -- 94221", "727107": "TAWAELI -- 94142", "727108": "MANTIKULORE -- 94233", "730101": "BENTENG -- 92812", "730102": "BONTOHARU -- 92811", "730103": "BONTOMATENE -- 92854", "730104": "BONTOMANAI -- 92851", "730105": "BONTOSIKUYU -- 92855", "730106": "PASIMASUNGGU -- 92861", "730107": "PASIMARANNU -- 92862", "730108": "TAKA BONERATE -- 92861", "730109": "PASILAMBENA -- 92863", "730110": "PASIMASUNGGU TIMUR -- 92861", "730111": "BUKI -- 92854", "730201": "GANTORANG -- 92561", "730202": "UJUNG BULU -- 92511", "730203": "BONTO BAHARI -- 92571", "730204": "BONTO TIRO -- 92572", "730205": "HERLANG -- 92573", "730206": "KAJANG -- 92574", "730207": "BULUKUMPA -- 92552", "730208": "KINDANG -- 92517", "730209": "UJUNGLOE -- 92661", "730210": "RILAUALE -- 92552", "730301": "BISSAPPU -- 92451", "730302": "BANTAENG -- 92411", "730303": "EREMERASA -- 92415", "730304": "TOMPO BULU -- 92461", "730305": "PAJUKUKANG -- 92461", "730306": "ULUERE -- 92451", "730307": "GANTARANG KEKE -- 92461", "730308": "SINOA -- 92451", "730401": "BANGKALA -- 92352", "730402": "TAMALATEA -- 92351", "730403": "BINAMU -- 92316", "730404": "BATANG -- 92361", "730405": "KELARA -- 92371", "730406": "BANGKALA BARAT -- 92352", "730407": "BONTORAMBA -- 92351", "730408": "TURATEA -- 92313", "730409": "ARUNGKEKE -- 92361", "730410": "RUMBIA -- 92371", "730411": "TAROWANG -- 92361", "730501": "MAPPAKASUNGGU -- 92232", "730502": "MANGARABOMBANG -- 92261", "730503": "POLOMBANGKENG SELATAN -- 92252", "730504": "POLOMBANGKENG UTARA -- 92221", "730505": "GALESONG SELATAN -- 92254", "730506": "GALESONG UTARA -- 92255", "730507": "PATTALLASSANG -- 92171", "730508": "SANROBONE -- 92231", "730509": "GALESONG -- 92255", "730601": "BONTONOMPO -- 92153", "730602": "BAJENG -- 92152", "730603": "TOMPOBULLU -- -", "730604": "TINGGIMONCONG -- 92174", "730605": "PARANGLOE -- 92173", "730606": "BONTOMARANNU -- 92171", "730607": "PALANGGA -- -", "730608": "SOMBA UPU -- -", "730609": "BUNGAYA -- 92176", "730610": "TOMBOLOPAO -- 92171", "730611": "BIRINGBULU -- 90244", "730612": "BAROMBONG -- 90225", "730613": "PATTALASANG -- -", "730614": "MANUJU -- 92173", "730615": "BONTOLEMPANGANG -- 92176", "730616": "BONTONOMPO SELATAN -- 92153", "730617": "PARIGI -- 92174", "730618": "BAJENG BARAT -- 92152", "730701": "SINJAI BARAT -- 92653", "730702": "SINJAI SELATAN -- 92661", "730703": "SINJAI TIMUR -- 92671", "730704": "SINJAI TENGAH -- 92652", "730705": "SINJAI UTARA -- 92616", "730706": "BULUPODDO -- 92654", "730707": "SINJAI BORONG -- 92662", "730708": "TELLU LIMPOE -- 91662", "730709": "PULAU SEMBILAN -- 92616", "730801": "BONTOCANI -- 92768", "730802": "KAHU -- 92767", "730803": "KAJUARA -- 92776", "730804": "SALOMEKKO -- 92775", "730805": "TONRA -- 92774", "730806": "LIBURENG -- 92766", "730807": "MARE -- 92773", "730808": "SIBULUE -- 92781", "730809": "BAREBBO -- 92771", "730810": "CINA -- 92772", "730811": "PONRE -- 92765", "730812": "LAPPARIAJA -- 92763", "730813": "LAMURU -- 92764", "730814": "ULAWENG -- 92762", "730815": "PALAKKA -- 92761", "730816": "AWANGPONE -- 92776", "730817": "TELLU SIATTINGE -- 92752", "730818": "AJANGALE -- 92755", "730819": "DUA BOCCOE -- 92753", "730820": "CENRANA -- 92754", "730821": "TANETE RIATTANG -- 92716", "730822": "TANETE RIATTANG BARAT -- 92735", "730823": "TANETE RIATTANG TIMUR -- 92716", "730824": "AMALI -- 92755", "730825": "TELLULIMPOE -- 91662", "730826": "BENGO -- 92763", "730827": "PATIMPENG -- 92768", "730901": "MANDAI -- 90552", "730902": "CAMBA -- 90562", "730903": "BANTIMURUNG -- 90561", "730904": "MAROS BARU -- 90516", "730905": "BONTOA -- 90554", "730906": "MALLLAWA -- -", "730907": "TANRALILI -- 90553", "730908": "MARUSU -- 90552", "730909": "SIMBANG -- 90561", "730910": "CENRANA -- 92754", "730911": "TOMPOBULU -- 92461", "730912": "LAU -- 90871", "730913": "MONCONG LOE -- 90562", "730914": "TURIKALE -- 90516", "731001": "LIUKANG TANGAYA -- 90673", "731002": "LIUKANG KALMAS -- 90672", "731003": "LIUKANG TUPABBIRING -- 90671", "731004": "PANGKAJENE -- 90612", "731005": "BALOCCI -- 90661", "731006": "BUNGORO -- 90651", "731007": "LABAKKANG -- 90653", "731008": "MARANG -- 90654", "731009": "SEGERI -- 90655", "731010": "MINASA TENE -- 90614", "731011": "MANDALLE -- 90655", "731012": "TONDONG TALLASA -- 90561", "731101": "TANETE RIAJA -- 90762", "731102": "TANETE RILAU -- 90761", "731103": "BARRU -- 90712", "731104": "SOPPENG RIAJA -- 90752", "731105": "MALLUSETASI -- 90753", "731106": "PUJANANTING -- 90762", "731107": "BALUSU -- 91855", "731201": "MARIORIWAWO -- 90862", "731202": "LILIRAJA -- 90861", "731203": "LILIRILAU -- 90871", "731204": "LALABATA -- 90814", "731205": "MARIORIAWA -- 90852", "731206": "DONRI DONRI -- -", "731207": "GANRA -- 90861", "731208": "CITTA -- 90861", "731301": "SABANGPARU -- -", "731302": "PAMMANA -- 90971", "731303": "TAKKALALLA -- 90981", "731304": "SAJOANGING -- 90982", "731305": "MAJAULENG -- 90991", "731306": "TEMPE -- 91992", "731307": "BELAWA -- 90953", "731308": "TANASITOLO -- 90951", "731309": "MANIANGPAJO -- 90952", "731310": "PITUMPANUA -- 90992", "731311": "BOLA -- 90984", "731312": "PENRANG -- 90983", "731313": "GILIRENG -- 90954", "731314": "KEERA -- 90993", "731401": "PANCA LAUTAN -- 91672", "731402": "TELLU LIMPOE -- 91662", "731403": "WATANG PULU -- 91661", "731404": "BARANTI -- 91652", "731405": "PANCA RIJANG -- 91651", "731406": "KULO -- 91653", "731407": "MARITENGNGAE -- 91611", "731408": "WT. SIDENRENG -- -", "731409": "DUA PITUE -- 91681", "731410": "PITU RIAWA -- 91683", "731411": "PITU RAISE -- 91691", "731501": "MATIRRO SOMPE -- -", "731502": "SUPPA -- 91272", "731503": "MATTIRO BULU -- 91271", "731504": "WATANG SAWITO -- -", "731505": "PATAMPANUA -- 91252", "731506": "DUAMPANUA -- 91253", "731507": "LEMBANG -- 91254", "731508": "CEMPA -- 91262", "731509": "TIROANG -- 91256", "731510": "LANSIRANG -- -", "731511": "PALETEANG -- 91215", "731512": "BATU LAPPA -- 91253", "731601": "MAIWA -- 91761", "731602": "ENREKANG -- 91711", "731603": "BARAKA -- 91753", "731604": "ANGGERAJA -- 91752", "731605": "ALLA -- 90981", "731606": "BUNGIN -- 91761", "731607": "CENDANA -- 91711", "731608": "CURIO -- 91754", "731609": "MALUA -- 91752", "731610": "BUNTU BATU -- 91753", "731611": "MASALLE -- 91754", "731612": "BAROKO -- 91754", "731701": "BASSE SANGTEMPE -- 91992", "731702": "LAROMPONG -- 91998", "731703": "SULI -- 91996", "731704": "BAJO -- 91995", "731705": "BUA PONRANG -- 91993", "731706": "WALENRANG -- 91951", "731707": "BELOPA -- 91994", "731708": "BUA -- 91993", "731709": "LAMASI -- 91952", "731710": "LAROMPONG SELATAN -- 91998", "731711": "PONRANG -- 91999", "731712": "LATIMOJONG -- 91921", "731713": "KAMANRE -- 91994", "731714": "BELOPA UTARA -- 91994", "731715": "WALENRANG BARAT -- 91951", "731716": "WALENRANG UTARA -- 91952", "731717": "WALENRANG TIMUR -- 91951", "731718": "LAMASI TIMUR -- 91951", "731719": "SULI BARAT -- 91996", "731720": "BAJO BARAT -- 91995", "731721": "PONRANG SELATAN -- 91999", "731722": "BASSE SANGTEMPE UTARA -- 91992", "731801": "SALUPUTI -- -", "731802": "BITTUANG -- 91856", "731803": "BONGGAKARADENG -- 91872", "731805": "MAKALE -- 91811", "731809": "SIMBUANG -- 91873", "731811": "RANTETAYO -- 91862", "731812": "MENGKENDEK -- 91871", "731813": "SANGALLA -- 91881", "731819": "GANDANGBATU SILLANAN -- 91871", "731820": "REMBON -- 91861", "731827": "MAKALE UTARA -- 91812", "731828": "MAPPAK -- 92232", "731829": "MAKALE SELATAN -- 91815", "731831": "MASANDA -- 91854", "731833": "SANGALLA SELATAN -- 91881", "731834": "SANGALLA UTARA -- 91881", "731835": "MALIMBONG BALEPE -- 91861", "731837": "RANO -- 91872", "731838": "KURRA -- 91862", "732201": "MALANGKE -- 92957", "732202": "BONE BONE -- -", "732203": "MASAMBA -- 92916", "732204": "SABBANG -- 92955", "732205": "LIMBONG -- 91861", "732206": "SUKAMAJU -- 92963", "732207": "SEKO -- 92956", "732208": "MALANGKE BARAT -- 92957", "732209": "RAMPI -- 92964", "732210": "MAPPEDECENG -- 92917", "732211": "BAEBUNTA -- 92965", "732212": "TANA LILI -- 91966", "732401": "MANGKUTANA -- 92973", "732402": "NUHA -- 92983", "732403": "TOWUTI -- 92982", "732404": "MALILI -- 92981", "732405": "ANGKONA -- 92985", "732406": "WOTU -- 92971", "732407": "BURAU -- 92975", "732408": "TOMONI -- 92972", "732409": "TOMONI TIMUR -- 92972", "732410": "KALAENA -- 92973", "732411": "WASUPONDA -- 92983", "732601": "RANTEPAO -- 91835", "732602": "SESEAN -- 91853", "732603": "NANGGALA -- 91855", "732604": "RINDINGALLO -- 91854", "732605": "BUNTAO -- 91853", "732606": "SA'DAN -- -", "732607": "SANGGALANGI -- 91852", "732608": "SOPAI -- 92119", "732609": "TIKALA -- 91833", "732610": "BALUSU -- 91855", "732611": "TALLUNGLIPU -- 91832", "732612": "DENDE' PIONGAN NAPO -- -", "732613": "BUNTU PEPASAN -- 91854", "732614": "BARUPPU -- 91854", "732615": "KESU -- 91852", "732616": "TONDON -- 90561", "732617": "BANGKELEKILA -- 91853", "732618": "RANTEBUA -- 91853", "732619": "SESEAN SULOARA -- 91853", "732620": "KAPALA PITU -- 91854", "732621": "AWAN RANTE KARUA -- 91854", "737101": "MARISO -- 90126", "737102": "MAMAJANG -- 90131", "737103": "MAKASAR -- -", "737104": "UJUNG PANDANG -- 90111", "737105": "WAJO -- 90173", "737106": "BONTOALA -- 90153", "737107": "TALLO -- 90212", "737108": "UJUNG TANAH -- 90167", "737109": "PANAKUKKANG -- -", "737110": "TAMALATE -- 90224", "737111": "BIRINGKANAYA -- 90243", "737112": "MANGGALA -- 90234", "737113": "RAPPOCINI -- 90222", "737114": "TAMALANREA -- 90244", "737201": "BACUKIKI -- 91121", "737202": "UJUNG -- 92661", "737203": "SOREANG -- 91131", "737204": "BACUKIKI BARAT -- 91121", "737301": "WARA -- 91922", "737302": "WARA UTARA -- 91911", "737303": "WARA SELATAN -- 91959", "737304": "TELLUWANUA -- 91958", "737305": "WARA TIMUR -- 91921", "737306": "WARA BARAT -- 91921", "737307": "SENDANA -- 91925", "737308": "MUNGKAJANG -- 91925", "737309": "BARA -- 92653", "740101": "WUNDULAKO -- 93561", "740104": "KOLAKA -- 93517", "740107": "POMALAA -- 93562", "740108": "WATUBANGGA -- -", "740110": "WOLO -- 93754", "740112": "BAULA -- 93561", "740114": "LATAMBAGA -- 93512", "740118": "TANGGETADA -- 93563", "740120": "SAMATURU -- 93915", "740124": "TOARI -- 93563", "740125": "POLINGGONA -- 93563", "740127": "IWOIMENDAA -- -", "740201": "LAMBUYA -- 93464", "740202": "UNAAHA -- 93413", "740203": "WAWOTOBI -- 93461", "740204": "PONDIDAHA -- 93463", "740205": "SAMPARA -- 93354", "740210": "ABUKI -- 93452", "740211": "SOROPIA -- 93351", "740215": "TONGAUNA -- 93461", "740216": "LATOMA -- 93461", "740217": "PURIALA -- 93464", "740218": "UEPAI -- 93464", "740219": "WONGGEDUKU -- 93463", "740220": "BESULUTU -- 93354", "740221": "BONDOALA -- 93354", "740223": "ROUTA -- 93653", "740224": "ANGGABERI -- 93419", "740225": "MELUHU -- 93461", "740228": "AMONGGEDO -- 93463", "740231": "ASINUA -- 93452", "740232": "KONAWE -- 93461", "740233": "KAPOIALA -- 93354", "740236": "LALONGGASUMEETO -- 93351", "740237": "ONEMBUTE -- 93464", "740306": "NAPABALANO -- 93654", "740307": "MALIGANO -- 93674", "740313": "WAKORUMBA SELATAN -- 93674", "740314": "LASALEPA -- 93654", "740315": "BATALAIWARU -- 93614", "740316": "KATOBU -- 93611", "740317": "DURUKA -- 93659", "740318": "LOHIA -- 93658", "740319": "WATOPUTE -- 93656", "740320": "KONTUNAGA -- 93658", "740323": "KABANGKA -- 93664", "740324": "KABAWO -- 93661", "740325": "PARIGI -- 93663", "740326": "BONE -- 93663", "740327": "TONGKUNO -- 93662", "740328": "PASIR PUTIH -- 93674", "740330": "KONTU KOWUNA -- 93661", "740331": "MAROBO -- 93663", "740332": "TONGKUNO SELATAN -- 93662", "740333": "PASI KOLAGA -- 93674", "740334": "BATUKARA -- 93674", "740337": "TOWEA -- 93654", "740411": "PASARWAJO -- 93754", "740422": "KAPONTORI -- 93755", "740423": "LASALIMU -- 93756", "740424": "LASALIMU SELATAN -- 93756", "740427": "SIOTAPINA -- -", "740428": "WOLOWA -- 93754", "740429": "WABULA -- 93754", "740501": "TINANGGEA -- 93885", "740502": "ANGATA -- 93875", "740503": "ANDOOLO -- 93819", "740504": "PALANGGA -- 93883", "740505": "LANDONO -- 93873", "740506": "LAINEA -- 93881", "740507": "KONDA -- 93874", "740508": "RANOMEETO -- 93871", "740509": "KOLONO -- 93395", "740510": "MORAMO -- 93891", "740511": "LAONTI -- 93892", "740512": "LALEMBUU -- 93885", "740513": "BENUA -- 93875", "740514": "PALANGGA SELATAN -- 93883", "740515": "MOWILA -- 93873", "740516": "MORAMO UTARA -- 93891", "740517": "BUKE -- 93815", "740518": "WOLASI -- 93874", "740519": "LAEYA -- 93881", "740520": "BAITO -- 93883", "740521": "BASALA -- 93875", "740522": "RANOMEETO BARAT -- 93871", "740601": "POLEANG -- 93773", "740602": "POLEANG TIMUR -- 93773", "740603": "RAROWATU -- 93774", "740604": "RUMBIA -- 93771", "740605": "KABAENA -- 93781", "740606": "KABAENA TIMUR -- 93783", "740607": "POLEANG BARAT -- 93772", "740608": "MATA OLEO -- 93771", "740609": "RAROWATU UTARA -- 93774", "740610": "POLEANG UTARA -- 93773", "740611": "POLEANG SELATAN -- 93773", "740612": "POLEANG TENGGARA -- 93773", "740613": "KABAENA SELATAN -- 93781", "740614": "KABAENA BARAT -- 93781", "740615": "KABAENA UTARA -- 93781", "740616": "KABAENA TENGAH -- 93783", "740617": "KEP. MASALOKA RAYA -- -", "740618": "RUMBIA TENGAH -- 93771", "740619": "POLEANG TENGAH -- 93772", "740620": "TONTONUNU -- 93772", "740621": "LANTARI JAYA -- 93774", "740622": "MATA USU -- 93774", "740701": "WANGI-WANGI -- 93795", "740702": "KALEDUPA -- 93792", "740703": "TOMIA -- 93793", "740704": "BINONGKO -- 93794", "740705": "WANGI WANGI SELATAN -- -", "740706": "KALEDUPA SELATAN -- 93792", "740707": "TOMIA TIMUR -- 93793", "740708": "TOGO BINONGKO -- 93794", "740801": "LASUSUA -- 93916", "740802": "PAKUE -- 93954", "740803": "BATU PUTIH -- 93955", "740804": "RANTE ANGIN -- 93956", "740805": "KODEOHA -- 93957", "740806": "NGAPA -- 93958", "740807": "WAWO -- 93461", "740808": "LAMBAI -- 93956", "740809": "WATUNOHU -- 93958", "740810": "PAKUE TENGAH -- 93954", "740811": "PAKUE UTARA -- 93954", "740812": "POREHU -- 93955", "740813": "TOLALA -- 93955", "740814": "TIWU -- 93957", "740815": "KATOI -- 93913", "740901": "ASERA -- 93353", "740902": "WIWIRANO -- 93353", "740903": "LANGGIKIMA -- 93352", "740904": "MOLAWE -- 93352", "740905": "LASOLO -- 93352", "740906": "LEMBO -- 93352", "740907": "SAWA -- 93352", "740908": "OHEO -- 93353", "740909": "ANDOWIA -- 93353", "740910": "MOTUI -- 93352", "741001": "KULISUSU -- 93672", "741002": "KAMBOWA -- 93673", "741003": "BONEGUNU -- 93673", "741004": "KULISUSU BARAT -- 93672", "741005": "KULISUSU UTARA -- 93672", "741006": "WAKORUMBA UTARA -- 93671", "741101": "TIRAWUTA -- 93572", "741102": "LOEA -- 93572", "741103": "LADONGI -- 93573", "741104": "POLI POLIA -- 93573", "741105": "LAMBANDIA -- 93573", "741106": "LALOLAE -- 93572", "741107": "MOWEWE -- 93571", "741108": "ULUIWOI -- 93575", "741109": "TINONDO -- 93571", "741110": "AERE -- -", "741111": "UEESI -- -", "741201": "WAWONII BARAT -- 93393", "741202": "WAWONII UTARA -- 93393", "741203": "WAWONII TIMUR LAUT -- 93393", "741204": "WAWONII TIMUR -- 93393", "741205": "WAWONII TENGGARA -- 93393", "741206": "WAWONII SELATAN -- 93393", "741207": "WAWONII TENGAH -- 93393", "741301": "SAWERIGADI -- 93657", "741302": "BARANGKA -- 93652", "741303": "LAWA -- 93753", "741304": "WADAGA -- 93652", "741305": "TIWORO SELATAN -- 93664", "741306": "MAGINTI -- 93664", "741307": "TIWORO TENGAH -- 93653", "741308": "TIWORO UTARA -- 93653", "741309": "TIWORO KEPULAUAN -- 93653", "741310": "KUSAMBI -- 93655", "741311": "NAPANO KUSAMBI -- 93655", "741401": "LAKUDO -- 93763", "741402": "MAWASANGKA TIMUR -- 93762", "741403": "MAWASANGKA TENGAH -- 93762", "741404": "MAWASANGKA -- 93762", "741405": "TALAGA RAYA -- 93781", "741406": "GU -- 93761", "741407": "SANGIA WAMBULU -- -", "741501": "BATAUGA -- 93752", "741502": "SAMPOLAWA -- 93753", "741503": "LAPANDEWA -- 93753", "741504": "BATU ATAS -- 93753", "741505": "SIOMPU BARAT -- 93752", "741506": "SIOMPU -- 93752", "741507": "KADATUA -- 93752", "747101": "MANDONGA -- 93112", "747102": "KENDARI -- 93123", "747103": "BARUGA -- 93116", "747104": "POASIA -- 93231", "747105": "KENDARI BARAT -- 93123", "747106": "ABELI -- 93234", "747107": "WUA-WUA -- 93118", "747108": "KADIA -- 93118", "747109": "PUUWATU -- 93115", "747110": "KAMBU -- 93231", "747201": "BETOAMBARI -- 93724", "747202": "WOLIO -- 93714", "747203": "SORA WALIO -- 93757", "747204": "BUNGI -- 93758", "747205": "KOKALUKUNA -- 93716", "747206": "MURHUM -- 93727", "747207": "LEA-LEA -- 93758", "747208": "BATUPOARO -- 93721", "750101": "LIMBOTO -- 96212", "750102": "TELAGA -- 96181", "750103": "BATUDAA -- 96271", "750104": "TIBAWA -- 96251", "750105": "BATUDAA PANTAI -- 96272", "750109": "BOLIYOHUTO -- 96264", "750110": "TELAGA BIRU -- 96181", "750111": "BONGOMEME -- 96271", "750113": "TOLANGOHULA -- 96214", "750114": "MOOTILANGO -- 96127", "750116": "PULUBALA -- 96127", "750117": "LIMBOTO BARAT -- 96215", "750118": "TILANGO -- 96123", "750119": "TABONGO -- 96271", "750120": "BILUHU -- 96272", "750121": "ASPARAGA -- 96214", "750122": "TALAGA JAYA -- -", "750123": "BILATO -- 96264", "750124": "DUNGALIYO -- 96271", "750201": "PAGUYAMAN -- 96261", "750202": "WONOSARI -- 96262", "750203": "DULUPI -- 96263", "750204": "TILAMUTA -- 96263", "750205": "MANANGGU -- 96265", "750206": "BOTUMOITA -- 96264", "750207": "PAGUYAMAN PANTAI -- 96261", "750301": "TAPA -- 96582", "750302": "KABILA -- 96583", "750303": "SUWAWA -- 96584", "750304": "BONEPANTAI -- 96585", "750305": "BULANGO UTARA -- 96582", "750306": "TILONGKABILA -- 96583", "750307": "BOTUPINGGE -- 96583", "750308": "KABILA BONE -- 96583", "750309": "BONE -- 96585", "750310": "BONE RAYA -- 96585", "750311": "SUWAWA TIMUR -- 96584", "750312": "SUWAWA SELATAN -- 96584", "750313": "SUWAWA TENGAH -- 96584", "750314": "BULANGO ULU -- 96582", "750315": "BULANGO SELATAN -- 96582", "750316": "BULANGO TIMUR -- 96582", "750317": "BULAWA -- 96585", "750318": "PINOGU -- 96584", "750401": "POPAYATO -- 96467", "750402": "LEMITO -- 96468", "750403": "RANDANGAN -- 96469", "750404": "MARISA -- 96266", "750405": "PAGUAT -- 96265", "750406": "PATILANGGIO -- 96266", "750407": "TALUDITI -- 96469", "750408": "DENGILO -- 96265", "750409": "BUNTULIA -- 96266", "750410": "DUHIADAA -- 96266", "750411": "WANGGARASI -- 96468", "750412": "POPAYATO TIMUR -- 96467", "750413": "POPAYATO BARAT -- 96467", "750501": "ATINGGOLA -- 96253", "750502": "KWANDANG -- 96252", "750503": "ANGGREK -- 96525", "750504": "SUMALATA -- 96254", "750505": "TOLINGGULA -- 96524", "750506": "GENTUMA RAYA -- 96253", "750507": "TOMOLITO -- 96252", "750508": "PONELO KEPULAUAN -- 96252", "750509": "MONANO -- 96525", "750510": "BIAU -- 96524", "750511": "SUMALATA TIMUR -- 96254", "757101": "KOTA BARAT -- 96136", "757102": "KOTA SELATAN -- 96111", "757103": "KOTA UTARA -- 96121", "757104": "DUNGINGI -- 96138", "757105": "KOTA TIMUR -- 96114", "757106": "KOTA TENGAH -- 96128", "757107": "SIPATANA -- 96124", "757108": "DUMBO RAYA -- 96118", "757109": "HULONTHALANGI -- 96116", "760101": "BAMBALAMOTU -- 91574", "760102": "PASANGKAYU -- 91571", "760103": "BARAS -- 91572", "760104": "SARUDU -- 91573", "760105": "DAPURANG -- 91512", "760106": "DURIPOKU -- 91573", "760107": "BULU TABA -- 91572", "760108": "TIKKE RAYA -- 91571", "760109": "PEDONGGA -- 91571", "760110": "BAMBAIRA -- 91574", "760111": "SARJO -- 91574", "760112": "LARIANG -- 91572", "760201": "MAMUJU -- 91514", "760202": "TAPALANG -- 91352", "760203": "KALUKKU -- 91561", "760204": "KALUMPANG -- 91562", "760207": "PAPALANG -- 91563", "760208": "SAMPAGA -- 91563", "760211": "TOMMO -- 91562", "760212": "SIMBORO DAN KEPULAUAN -- 91512", "760213": "TAPALANG BARAT -- 91352", "760215": "BONEHAU -- 91562", "760216": "KEP. BALA BALAKANG -- 91512", "760301": "MAMBI -- 91371", "760302": "ARALLE -- 91373", "760303": "MAMASA -- 91362", "760304": "PANA -- 91363", "760305": "TABULAHAN -- 91372", "760306": "SUMARORONG -- 91361", "760307": "MESSAWA -- 91361", "760308": "SESENAPADANG -- 91365", "760309": "TANDUK KALUA -- 91366", "760310": "TABANG -- 91364", "760311": "BAMBANG -- 91371", "760312": "BALLA -- 91366", "760313": "NOSU -- 91363", "760314": "TAWALIAN -- 91365", "760315": "RANTEBULAHAN TIMUR -- 91371", "760316": "BUNTUMALANGKA -- 91373", "760317": "MEHALAAN -- 91371", "760401": "TINAMBUNG -- 91354", "760402": "CAMPALAGIAN -- 91353", "760403": "WONOMULYO -- 91352", "760404": "POLEWALI -- 91314", "760405": "TUTAR -- 91355", "760406": "BINUANG -- 91312", "760407": "TAPANGO -- 91352", "760408": "MAPILLI -- 91353", "760409": "MATANGNGA -- 91352", "760410": "LUYO -- 91353", "760411": "LIMBORO -- 91413", "760412": "BALANIPA -- 91354", "760413": "ANREAPI -- 91315", "760414": "MATAKALI -- 91352", "760415": "ALLU -- 96365", "760416": "BULO -- 91353", "760501": "BANGGAE -- 91411", "760502": "PAMBOANG -- 91451", "760503": "SENDANA -- 91452", "760504": "MALUNDA -- 91453", "760505": "ULUMANDA -- -", "760506": "TAMMERODO SENDANA -- -", "760507": "TUBO SENDANA -- 91452", "760508": "BANGGAE TIMUR -- 91411", "760601": "TOBADAK -- 91563", "760602": "PANGALE -- 91563", "760603": "BUDONG-BUDONG -- 91563", "760604": "TOPOYO -- 91563", "760605": "KAROSSA -- 91512", "810101": "AMAHAI -- 97516", "810102": "TEON NILA SERUA -- 97558", "810106": "SERAM UTARA -- 97557", "810109": "BANDA -- 97593", "810111": "TEHORU -- 97553", "810112": "SAPARUA -- 97592", "810113": "PULAU HARUKU -- 97591", "810114": "SALAHUTU -- 97582", "810115": "LEIHITU -- 97581", "810116": "NUSA LAUT -- 97511", "810117": "KOTA MASOHI -- -", "810120": "SERAM UTARA BARAT -- 97557", "810121": "TELUK ELPAPUTIH -- 97516", "810122": "LEIHITU BARAT -- 97581", "810123": "TELUTIH -- 97553", "810124": "SERAM UTARA TIMUR SETI -- 97557", "810125": "SERAM UTARA TIMUR KOBI -- 97557", "810126": "SAPARUA TIMUR -- 97592", "810201": "KEI KECIL -- 97615", "810203": "KEI BESAR -- 97661", "810204": "KEI BESAR SELATAN -- 97661", "810205": "KEI BESAR UTARA TIMUR -- 97661", "810213": "KEI KECIL TIMUR -- 97615", "810214": "KEI KECIL BARAT -- 97615", "810215": "MANYEUW -- 97611", "810216": "HOAT SORBAY -- 97611", "810217": "KEI BESAR UTARA BARAT -- 97661", "810218": "KEI BESAR SELATAN BARAT -- 97661", "810219": "KEI KECIL TIMUR SELATAN -- 97615", "810301": "TANIMBAR SELATAN -- 97464", "810302": "SELARU -- 97453", "810303": "WER TAMRIAN -- 97464", "810304": "WER MAKTIAN -- 97464", "810305": "TANIMBAR UTARA -- 97463", "810306": "YARU -- 97463", "810307": "WUAR LABOBAR -- 97463", "810308": "KORMOMOLIN -- 97463", "810309": "NIRUNMAS -- 97463", "810318": "MOLU MARU -- 97463", "810401": "NAMLEA -- 97571", "810402": "AIR BUAYA -- 97572", "810403": "WAEAPO -- 97574", "810406": "WAPLAU -- 97571", "810410": "BATABUAL -- 97574", "810411": "LOLONG GUBA -- 97574", "810412": "WAELATA -- 97574", "810413": "FENA LEISELA -- 97572", "810414": "TELUK KAIELY -- 97574", "810415": "LILIALY -- 97571", "810501": "BULA -- 97554", "810502": "SERAM TIMUR -- 97594", "810503": "WERINAMA -- 97554", "810504": "PULAU GOROM -- -", "810505": "WAKATE -- 97595", "810506": "TUTUK TOLU -- 97594", "810507": "SIWALALAT -- 97554", "810508": "KILMURY -- 97594", "810509": "PULAU PANJANG -- 97599", "810510": "TEOR -- 97597", "810511": "GOROM TIMUR -- 97596", "810512": "BULA BARAT -- 97554", "810513": "KIAN DARAT -- 97594", "810514": "SIRITAUN WIDA TIMUR -- 97598", "810515": "TELUK WARU -- 97554", "810601": "KAIRATU -- 97566", "810602": "SERAM BARAT -- 97562", "810603": "TANIWEL -- 97561", "810604": "HUAMUAL BELAKANG -- 97567", "810605": "AMALATU -- 97566", "810606": "INAMOSOL -- 97566", "810607": "KAIRATU BARAT -- 97566", "810608": "HUAMUAL -- 97567", "810609": "KEPULAUAN MANIPA -- 97567", "810610": "TANIWEL TIMUR -- 97561", "810611": "ELPAPUTIH -- 97566", "810701": "PULAU-PULAU ARU -- 97662", "810702": "ARU SELATAN -- 97666", "810703": "ARU TENGAH -- 97665", "810704": "ARU UTARA -- 97663", "810705": "ARU UTARA TIMUR BATULEY -- 97663", "810706": "SIR-SIR -- 97664", "810707": "ARU TENGAH TIMUR -- 97665", "810708": "ARU TENGAH SELATAN -- 97665", "810709": "ARU SELATAN TIMUR -- 97666", "810710": "ARU SELATAN UTARA -- 97668", "810801": "MOA LAKOR -- 97454", "810802": "DAMER -- 97128", "810803": "MNDONA HIERA -- -", "810804": "PULAU-PULAU BABAR -- 97652", "810805": "PULAU-PULAU BABAR TIMUR -- 97652", "810806": "WETAR -- 97454", "810807": "PULAU-PULAU TERSELATAN -- -", "810808": "PULAU LETI -- -", "810809": "PULAU MASELA -- 97652", "810810": "DAWELOR DAWERA -- 97652", "810811": "PULAU WETANG -- 97452", "810812": "PULAU LAKOR -- 97454", "810813": "WETAR UTARA -- 97454", "810814": "WETAR BARAT -- 97454", "810815": "WETAR TIMUR -- 97454", "810816": "KEPULAUAN ROMANG -- 97454", "810817": "KISAR UTARA -- 97454", "810901": "NAMROLE -- 97573", "810902": "WAESAMA -- 97574", "810903": "AMBALAU -- 97512", "810904": "KEPALA MADAN -- 97572", "810905": "LEKSULA -- 97573", "810906": "FENA FAFAN -- 97573", "817101": "NUSANIWE -- 97117", "817102": "SIRIMAU -- 97127", "817103": "BAGUALA -- 97231", "817104": "TELUK AMBON -- 97234", "817105": "LEITIMUR SELATAN -- 97129", "817201": "PULAU DULLAH UTARA -- 97611", "817202": "PULAU DULLAH SELATAN -- 97611", "817203": "TAYANDO TAM -- 97611", "817204": "PULAU-PULAU KUR -- 97652", "817205": "KUR SELATAN -- 97652", "820101": "JAILOLO -- 97752", "820102": "LOLODA -- 97755", "820103": "IBU -- 97754", "820104": "SAHU -- 97753", "820105": "JAILOLO SELATAN -- 97752", "820107": "IBU UTARA -- 97754", "820108": "IBU SELATAN -- 97754", "820109": "SAHU TIMUR -- 97753", "820201": "WEDA -- 97853", "820202": "PATANI -- 97854", "820203": "PULAU GEBE -- 97854", "820204": "WEDA UTARA -- 97853", "820205": "WEDA SELATAN -- 97853", "820206": "PATANI UTARA -- 97854", "820207": "WEDA TENGAH -- 97853", "820208": "PATANI BARAT -- 97854", "820304": "GALELA -- 97761", "820305": "TOBELO -- 97762", "820306": "TOBELO SELATAN -- 97762", "820307": "KAO -- 97752", "820308": "MALIFUT -- 97764", "820309": "LOLODA UTARA -- 97755", "820310": "TOBELO UTARA -- 97762", "820311": "TOBELO TENGAH -- 97762", "820312": "TOBELO TIMUR -- 97762", "820313": "TOBELO BARAT -- 97762", "820314": "GALELA BARAT -- 97761", "820315": "GALELA UTARA -- 97761", "820316": "GALELA SELATAN -- 97761", "820319": "LOLODA KEPULAUAN -- 97755", "820320": "KAO UTARA -- 97764", "820321": "KAO BARAT -- 97764", "820322": "KAO TELUK -- 97752", "820401": "PULAU MAKIAN -- 97756", "820402": "KAYOA -- 97781", "820403": "GANE TIMUR -- 97783", "820404": "GANE BARAT -- 97782", "820405": "OBI SELATAN -- 97792", "820406": "OBI -- 97792", "820407": "BACAN TIMUR -- 97791", "820408": "BACAN -- 97791", "820409": "BACAN BARAT -- 97791", "820410": "MAKIAN BARAT -- 97756", "820411": "KAYOA BARAT -- 97781", "820412": "KAYOA SELATAN -- 97781", "820413": "KAYOA UTARA -- 97781", "820414": "BACAN BARAT UTARA -- 97791", "820415": "KASIRUTA BARAT -- 97791", "820416": "KASIRUTA TIMUR -- 97791", "820417": "BACAN SELATAN -- 97791", "820418": "KEPULAUAN BOTANGLOMANG -- 97791", "820419": "MANDIOLI SELATAN -- 97791", "820420": "MANDIOLI UTARA -- 97791", "820421": "BACAN TIMUR SELATAN -- 97791", "820422": "BACAN TIMUR TENGAH -- 97791", "820423": "GANE BARAT SELATAN -- 97782", "820424": "GANE BARAT UTARA -- 97782", "820425": "KEPULAUAN JORONGA -- 97782", "820426": "GANE TIMUR SELATAN -- 97783", "820427": "GANE TIMUR TENGAH -- 97783", "820428": "OBI BARAT -- 97792", "820429": "OBI TIMUR -- 97792", "820430": "OBI UTARA -- 97792", "820501": "MANGOLI TIMUR -- 97793", "820502": "SANANA -- 97795", "820503": "SULABESI BARAT -- 97795", "820506": "MANGOLI BARAT -- 97792", "820507": "SULABESI TENGAH -- 97795", "820508": "SULABESI TIMUR -- 97795", "820509": "SULABESI SELATAN -- 97795", "820510": "MANGOLI UTARA TIMUR -- 97793", "820511": "MANGOLI TENGAH -- 97793", "820512": "MANGOLI SELATAN -- 97793", "820513": "MANGOLI UTARA -- 97793", "820518": "SANANA UTARA -- 97795", "820601": "WASILE -- 97863", "820602": "MABA -- 97862", "820603": "MABA SELATAN -- 97862", "820604": "WASILE SELATAN -- 97863", "820605": "WASILE TENGAH -- 97863", "820606": "WASILE UTARA -- 97863", "820607": "WASILE TIMUR -- 97863", "820608": "MABA TENGAH -- 97862", "820609": "MABA UTARA -- 97862", "820610": "KOTA MABA -- 97862", "820701": "MOROTAI SELATAN -- 97771", "820702": "MOROTAI SELATAN BARAT -- 97771", "820703": "MOROTAI JAYA -- 97772", "820704": "MOROTAI UTARA -- 97772", "820705": "MOROTAI TIMUR -- 97772", "820801": "TALIABU BARAT -- 97794", "820802": "TALIABU BARAT LAUT -- 97794", "820803": "LEDE -- 97793", "820804": "TALIABU UTARA -- 97794", "820805": "TALIABU TIMUR -- 97793", "820806": "TALIABU TIMUR SELATAN -- 97793", "820807": "TALIABU SELATAN -- 97794", "820808": "TABONA -- -", "827101": "PULAU TERNATE -- 97751", "827102": "KOTA TERNATE SELATAN -- -", "827103": "KOTA TERNATE UTARA -- -", "827104": "PULAU MOTI -- 97751", "827105": "PULAU BATANG DUA -- 97751", "827106": "KOTA TERNATE TENGAH -- -", "827107": "PULAU HIRI -- 97751", "827201": "TIDORE -- 97813", "827202": "OBA UTARA -- 97852", "827203": "OBA -- 97852", "827204": "TIDORE SELATAN -- 97813", "827205": "TIDORE UTARA -- 97813", "827206": "OBA TENGAH -- 97852", "827207": "OBA SELATAN -- 97852", "827208": "TIDORE TIMUR -- 97813", "910101": "MERAUKE -- 99616", "910102": "MUTING -- 99652", "910103": "OKABA -- 99654", "910104": "KIMAAM -- 99655", "910105": "SEMANGGA -- 99651", "910106": "TANAH MIRING -- 99651", "910107": "JAGEBOB -- 99656", "910108": "SOTA -- 99656", "910109": "ULILIN -- 99652", "910110": "ELIKOBAL -- -", "910111": "KURIK -- 99656", "910112": "NAUKENJERAI -- 99616", "910113": "ANIMHA -- 99656", "910114": "MALIND -- 99656", "910115": "TUBANG -- 99654", "910116": "NGGUTI -- 99654", "910117": "KAPTEL -- 99654", "910118": "TABONJI -- 99655", "910119": "WAAN -- 99655", "910120": "ILWAYAB -- -", "910201": "WAMENA -- 99511", "910203": "KURULU -- 99552", "910204": "ASOLOGAIMA -- 99554", "910212": "HUBIKOSI -- 99566", "910215": "BOLAKME -- 99557", "910225": "WALELAGAMA -- 99511", "910227": "MUSATFAK -- 99554", "910228": "WOLO -- 99557", "910229": "ASOLOKOBAL -- 99511", "910234": "PELEBAGA -- 99566", "910235": "YALENGGA -- 99557", "910240": "TRIKORA -- 99511", "910241": "NAPUA -- 99511", "910242": "WALAIK -- 99511", "910243": "WOUMA -- 99511", "910244": "HUBIKIAK -- 99566", "910245": "IBELE -- 99566", "910246": "TAELAREK -- 99566", "910247": "ITLAY HISAGE -- 99511", "910248": "SIEPKOSI -- 99511", "910249": "USILIMO -- 99552", "910250": "WITA WAYA -- 99552", "910251": "LIBAREK -- 99552", "910252": "WADANGKU -- 99552", "910253": "PISUGI -- 99552", "910254": "KORAGI -- 99557", "910255": "TAGIME -- 99561", "910256": "MOLAGALOME -- 99557", "910257": "TAGINERI -- 99561", "910258": "SILO KARNO DOGA -- 99554", "910259": "PIRAMID -- 99554", "910260": "MULIAMA -- 99554", "910261": "BUGI -- 99557", "910262": "BPIRI -- 99557", "910263": "WELESI -- 99511", "910264": "ASOTIPO -- 99511", "910265": "MAIMA -- 99511", "910266": "POPUGOBA -- 99511", "910267": "WAME -- 99511", "910268": "WESAPUT -- 99511", "910301": "SENTANI -- 99359", "910302": "SENTANI TIMUR -- 99359", "910303": "DEPAPRE -- 99353", "910304": "SENTANI BARAT -- 99358", "910305": "KEMTUK -- 99357", "910306": "KEMTUK GRESI -- 99357", "910307": "NIMBORAN -- 99361", "910308": "NIMBOKRANG -- 99362", "910309": "UNURUM GUAY -- 99356", "910310": "DEMTA -- 99354", "910311": "KAUREH -- 99364", "910312": "EBUNGFA -- 99352", "910313": "WAIBU -- 99358", "910314": "NAMBLUONG -- 99361", "910315": "YAPSI -- 99364", "910316": "AIRU -- 99364", "910317": "RAVENI RARA -- 99353", "910318": "GRESI SELATAN -- 99357", "910319": "YOKARI -- 99354", "910401": "NABIRE -- 98856", "910402": "NAPAN -- 98861", "910403": "YAUR -- 98852", "910406": "UWAPA -- 98853", "910407": "WANGGAR -- 98856", "910410": "SIRIWO -- 98854", "910411": "MAKIMI -- 98861", "910412": "TELUK UMAR -- 98852", "910416": "TELUK KIMI -- 98818", "910417": "YARO -- 98853", "910421": "WAPOGA -- 98261", "910422": "NABIRE BARAT -- 98856", "910423": "MOORA -- 98861", "910424": "DIPA -- 98768", "910425": "MENOU -- 98853", "910501": "YAPEN SELATAN -- 98214", "910502": "YAPEN BARAT -- 98253", "910503": "YAPEN TIMUR -- 98252", "910504": "ANGKAISERA -- 98255", "910505": "POOM -- 98254", "910506": "KOSIWO -- 98215", "910507": "YAPEN UTARA -- 98252", "910508": "RAIMBAWI -- 98252", "910509": "TELUK AMPIMOI -- 98252", "910510": "KEPULAUAN AMBAI -- 98255", "910511": "WONAWA -- 98253", "910512": "WINDESI -- 98254", "910513": "PULAU KURUDU -- 98252", "910514": "PULAU YERUI -- 98253", "910601": "BIAK KOTA -- 98118", "910602": "BIAK UTARA -- 98153", "910603": "BIAK TIMUR -- 98152", "910604": "NUMFOR BARAT -- 98172", "910605": "NUMFOR TIMUR -- 98171", "910608": "BIAK BARAT -- 98154", "910609": "WARSA -- 98157", "910610": "PADAIDO -- 98158", "910611": "YENDIDORI -- 98155", "910612": "SAMOFA -- 98156", "910613": "YAWOSI -- 98153", "910614": "ANDEY -- 98153", "910615": "SWANDIWE -- 98154", "910616": "BRUYADORI -- 98171", "910617": "ORKERI -- 98172", "910618": "POIRU -- 98171", "910619": "AIMANDO PADAIDO -- 98158", "910620": "ORIDEK -- 98152", "910621": "BONDIFUAR -- 98157", "910701": "MULIA -- 98911", "910703": "ILU -- 98916", "910706": "FAWI -- 98917", "910707": "MEWOLUK -- 98918", "910708": "YAMO -- 98913", "910710": "NUME -- -", "910711": "TORERE -- 98914", "910712": "TINGGINAMBUT -- 98912", "910717": "PAGALEME -- -", "910718": "GURAGE -- -", "910719": "IRIMULI -- -", "910720": "MUARA -- 99351", "910721": "ILAMBURAWI -- -", "910722": "YAMBI -- -", "910723": "LUMO -- -", "910724": "MOLANIKIME -- -", "910725": "DOKOME -- -", "910726": "KALOME -- -", "910727": "WANWI -- -", "910728": "YAMONERI -- -", "910729": "WAEGI -- -", "910730": "NIOGA -- -", "910731": "GUBUME -- -", "910732": "TAGANOMBAK -- -", "910733": "DAGAI -- -", "910734": "KIYAGE -- -", "910801": "PANIAI TIMUR -- 98711", "910802": "PANIAI BARAT -- 98763", "910804": "ARADIDE -- 98766", "910807": "BOGABAIDA -- -", "910809": "BIBIDA -- 98782", "910812": "DUMADAMA -- 98782", "910813": "SIRIWO -- 98854", "910819": "KEBO -- 98715", "910820": "YATAMO -- 98725", "910821": "EKADIDE -- 98766", "910901": "MIMIKA BARU -- 99910", "910902": "AGIMUGA -- 99964", "910903": "MIMIKA TIMUR -- 99972", "910904": "MIMIKA BARAT -- 99974", "910905": "JITA -- 99965", "910906": "JILA -- 99966", "910907": "MIMIKA TIMUR JAUH -- 99971", "910908": "MIMIKA TENGAH -- -", "910909": "KUALA KENCANA -- 99968", "910910": "TEMBAGAPURA -- 99967", "910911": "MIMIKA BARAT JAUH -- 99974", "910912": "MIMIKA BARAT TENGAH -- 99973", "910913": "KWAMKI NARAMA -- -", "910914": "HOYA -- -", "910916": "WANIA -- -", "910917": "AMAR -- -", "910918": "ALAMA -- 99564", "911001": "SARMI -- 99373", "911002": "TOR ATAS -- 99372", "911003": "PANTAI BARAT -- 99374", "911004": "PANTAI TIMUR -- 99371", "911005": "BONGGO -- 99355", "911009": "APAWER HULU -- 99374", "911012": "SARMI SELATAN -- 99373", "911013": "SARMI TIMUR -- 99373", "911014": "PANTAI TIMUR BAGIAN BARAT -- -", "911015": "BONGGO TIMUR -- 99355", "911101": "WARIS -- 99467", "911102": "ARSO -- 99468", "911103": "SENGGI -- 99465", "911104": "WEB -- 99466", "911105": "SKANTO -- 99469", "911106": "ARSO TIMUR -- 99468", "911107": "TOWE -- 99466", "911201": "OKSIBIL -- 99573", "911202": "KIWIROK -- 99574", "911203": "OKBIBAB -- 99572", "911204": "IWUR -- 99575", "911205": "BATOM -- 99576", "911206": "BORME -- 99577", "911207": "KIWIROK TIMUR -- 99574", "911208": "ABOY -- 99572", "911209": "PEPERA -- 99573", "911210": "BIME -- 99577", "911211": "ALEMSOM -- 99573", "911212": "OKBAPE -- 99573", "911213": "KALOMDOL -- 99573", "911214": "OKSOP -- 99573", "911215": "SERAMBAKON -- 99573", "911216": "OK AOM -- 99573", "911217": "KAWOR -- 99575", "911218": "AWINBON -- 99575", "911219": "TARUP -- 99575", "911220": "OKHIKA -- 99574", "911221": "OKSAMOL -- 99574", "911222": "OKLIP -- 99574", "911223": "OKBEMTAU -- 99574", "911224": "OKSEBANG -- 99574", "911225": "OKBAB -- 99572", "911226": "BATANI -- 99576", "911227": "WEIME -- 99576", "911228": "MURKIM -- 99576", "911229": "MOFINOP -- 99576", "911230": "JETFA -- 99572", "911231": "TEIRAPLU -- 99572", "911232": "EIPUMEK -- 99577", "911233": "PAMEK -- 99577", "911234": "NONGME -- 99576", "911301": "KURIMA -- 99571", "911302": "ANGGRUK -- 99582", "911303": "NINIA -- 99578", "911306": "SILIMO -- 99552", "911307": "SAMENAGE -- 99571", "911308": "NALCA -- 99582", "911309": "DEKAI -- 99571", "911310": "OBIO -- 99571", "911311": "SURU SURU -- 99571", "911312": "WUSAMA -- -", "911313": "AMUMA -- 99571", "911314": "MUSAIK -- 99571", "911315": "PASEMA -- 99571", "911316": "HOGIO -- 99571", "911317": "MUGI -- 99564", "911318": "SOBA -- 99578", "911319": "WERIMA -- 99571", "911320": "TANGMA -- 99571", "911321": "UKHA -- 99571", "911322": "PANGGEMA -- 99582", "911323": "KOSAREK -- 99582", "911324": "NIPSAN -- 99582", "911325": "UBAHAK -- 99582", "911326": "PRONGGOLI -- 99582", "911327": "WALMA -- 99582", "911328": "YAHULIAMBUT -- 99578", "911329": "HEREAPINI -- 99582", "911330": "UBALIHI -- 99582", "911331": "TALAMBO -- 99582", "911332": "PULDAMA -- 99582", "911333": "ENDOMEN -- 99582", "911334": "KONA -- 99571", "911335": "DIRWEMNA -- 99582", "911336": "HOLUON -- 99578", "911337": "LOLAT -- 99578", "911338": "SOLOIKMA -- 99578", "911339": "SELA -- 99373", "911340": "KORUPUN -- 99578", "911341": "LANGDA -- 99578", "911342": "BOMELA -- 99578", "911343": "SUNTAMON -- 99578", "911344": "SEREDELA -- 99571", "911345": "SOBAHAM -- 99578", "911346": "KABIANGGAMA -- 99578", "911347": "KWELEMDUA -- 99578", "911348": "KWIKMA -- 99578", "911349": "HILIPUK -- 99578", "911350": "DURAM -- 99582", "911351": "YOGOSEM -- 99571", "911352": "KAYO -- 99571", "911353": "SUMO -- 99571", "911401": "KARUBAGA -- 99562", "911402": "BOKONDINI -- 99561", "911403": "KANGGIME -- 99568", "911404": "KEMBU -- 99569", "911405": "GOYAGE -- 99562", "911406": "WUNIM -- -", "911407": "WINA -- 99569", "911408": "UMAGI -- 99569", "911409": "PANAGA -- 99569", "911410": "WONIKI -- 99568", "911411": "KUBU -- 99562", "911412": "KONDA/ KONDAGA -- -", "911413": "NELAWI -- 99562", "911414": "KUARI -- 99562", "911415": "BOKONERI -- 99561", "911416": "BEWANI -- 99561", "911418": "NABUNAGE -- 99568", "911419": "GILUBANDU -- 99568", "911420": "NUNGGAWI -- 99568", "911421": "GUNDAGI -- 99569", "911422": "NUMBA -- 99562", "911423": "TIMORI -- 99569", "911424": "DUNDU -- 99569", "911425": "GEYA -- 99562", "911426": "EGIAM -- 99569", "911427": "POGANERI -- 99569", "911428": "KAMBONERI -- 99561", "911429": "AIRGARAM -- 99562", "911430": "WARI/TAIYEVE II -- -", "911431": "DOW -- 99569", "911432": "TAGINERI -- 99561", "911433": "YUNERI -- 99562", "911434": "WAKUWO -- 99568", "911435": "GIKA -- 99569", "911436": "TELENGGEME -- 99569", "911437": "ANAWI -- 99562", "911438": "WENAM -- 99562", "911439": "WUGI -- 99562", "911440": "DANIME -- 99561", "911441": "TAGIME -- 99561", "911442": "KAI -- 99562", "911443": "AWEKU -- 99568", "911444": "BOGONUK -- 99568", "911445": "LI ANOGOMMA -- 99562", "911446": "BIUK -- 99562", "911447": "YUKO -- 99569", "911501": "WAROPEN BAWAH -- 98261", "911503": "MASIREI -- 98263", "911507": "RISEI SAYATI -- 98263", "911508": "UREI FAISEI -- -", "911509": "INGGERUS -- 98261", "911510": "KIRIHI -- 98263", "911514": "WONTI -- -", "911515": "SOYOI MAMBAI -- -", "911601": "MANDOBO -- 99663", "911602": "MINDIPTANA -- 99662", "911603": "WAROPKO -- 99664", "911604": "KOUH -- 99661", "911605": "JAIR -- 99661", "911606": "BOMAKIA -- 99663", "911607": "KOMBUT -- 99662", "911608": "INIYANDIT -- 99662", "911609": "ARIMOP -- 99663", "911610": "FOFI -- 99663", "911611": "AMBATKWI -- 99664", "911612": "MANGGELUM -- 99665", "911613": "FIRIWAGE -- 99665", "911614": "YANIRUMA -- 99664", "911615": "SUBUR -- 99661", "911616": "KOMBAY -- 99664", "911617": "NINATI -- 99664", "911618": "SESNUK -- 99662", "911619": "KI -- 99663", "911620": "KAWAGIT -- 99665", "911701": "OBAA -- 99871", "911702": "MAMBIOMAN BAPAI -- -", "911703": "CITAK-MITAK -- -", "911704": "EDERA -- 99853", "911705": "HAJU -- 99881", "911706": "ASSUE -- 99874", "911707": "KAIBAR -- 99875", "911708": "PASSUE -- 99871", "911709": "MINYAMUR -- 99872", "911710": "VENAHA -- 99853", "911711": "SYAHCAME -- 99853", "911712": "YAKOMI -- 99853", "911713": "BAMGI -- 99853", "911714": "PASSUE BAWAH -- 99875", "911715": "TI ZAIN -- 99875", "911801": "AGATS -- 99777", "911802": "ATSJ -- 99776", "911803": "SAWA ERMA -- 99778", "911804": "AKAT -- 99779", "911805": "FAYIT -- 99782", "911806": "PANTAI KASUARI -- 99773", "911807": "SUATOR -- 99766", "911808": "SURU-SURU -- 99778", "911809": "KOLF BRAZA -- 99766", "911810": "UNIR SIRAU -- 99778", "911811": "JOERAT -- 99778", "911812": "PULAU TIGA -- 99778", "911813": "JETSY -- 99777", "911814": "DER KOUMUR -- 99773", "911815": "KOPAY -- 99773", "911816": "SAFAN -- 99773", "911817": "SIRETS -- 99776", "911818": "AYIP -- 99776", "911819": "BETCBAMU -- 99776", "911901": "SUPIORI SELATAN -- 98161", "911902": "SUPIORI UTARA -- 98162", "911903": "SUPIORI TIMUR -- 98161", "911904": "KEPULAUAN ARURI -- 98161", "911905": "SUPIORI BARAT -- 98162", "912001": "MAMBERAMO TENGAH -- 99376", "912002": "MAMBERAMO HULU -- 99377", "912003": "RUFAER -- 99377", "912004": "MAMBERAMO TENGAH TIMUR -- 99376", "912005": "MAMBERAMO HILIR -- 99375", "912006": "WAROPEN ATAS -- 98262", "912007": "BENUKI -- 98262", "912008": "SAWAI -- 98262", "912101": "KOBAGMA -- -", "912102": "KELILA -- 99553", "912103": "ERAGAYAM -- 99553", "912104": "MEGAMBILIS -- 99558", "912105": "ILUGWA -- 99557", "912201": "ELELIM -- 99584", "912202": "APALAPSILI -- 99586", "912203": "ABENAHO -- 99587", "912204": "BENAWA -- 99583", "912205": "WELAREK -- 99585", "912301": "TIOM -- 99563", "912302": "PIRIME -- 99567", "912303": "MAKKI -- 99555", "912304": "GAMELIA -- 99556", "912305": "DIMBA -- 99567", "912306": "MELAGINERI -- -", "912307": "BALINGGA -- 99567", "912308": "TIOMNERI -- 99563", "912309": "KUYAWAGE -- 99563", "912310": "POGA -- 99556", "912311": "NINAME -- -", "912312": "NOGI -- -", "912313": "YIGINUA -- -", "912314": "TIOM OLLO -- -", "912315": "YUGUNGWI -- -", "912316": "MOKONI -- -", "912317": "WEREKA -- -", "912318": "MILIMBO -- -", "912319": "WIRINGGAMBUT -- -", "912320": "GOLLO -- -", "912321": "AWINA -- -", "912322": "AYUMNATI -- -", "912323": "WANO BARAT -- -", "912324": "GOA BALIM -- -", "912325": "BRUWA -- -", "912326": "BALINGGA BARAT -- -", "912327": "GUPURA -- -", "912328": "KOLAWA -- -", "912329": "GELOK BEAM -- -", "912330": "KULY LANNY -- -", "912331": "LANNYNA -- -", "912332": "KARU -- 99562", "912333": "YILUK -- -", "912334": "GUNA -- -", "912335": "KELULOME -- -", "912336": "NIKOGWE -- -", "912337": "MUARA -- 99351", "912338": "BUGUK GONA -- -", "912339": "MELAGI -- -", "912401": "KENYAM -- 99565", "912402": "MAPENDUMA -- 99564", "912403": "YIGI -- 99564", "912404": "WOSAK -- 99565", "912405": "GESELMA -- 99564", "912406": "MUGI -- 99564", "912407": "MBUWA -- -", "912408": "GEAREK -- 99565", "912409": "KOROPTAK -- 99564", "912410": "KEGAYEM -- 99564", "912411": "PARO -- 99564", "912412": "MEBAROK -- 99564", "912413": "YENGGELO -- 99564", "912414": "KILMID -- 99564", "912415": "ALAMA -- 99564", "912416": "YAL -- 99557", "912417": "MAM -- 99872", "912418": "DAL -- 99571", "912419": "NIRKURI -- 99564", "912420": "INIKGAL -- 99564", "912421": "INIYE -- 99564", "912422": "MBULMU YALMA -- 99564", "912423": "MBUA TENGAH -- 99565", "912424": "EMBETPEN -- 99565", "912425": "KORA -- 99511", "912426": "WUSI -- 99565", "912427": "PIJA -- 99565", "912428": "MOBA -- 99565", "912429": "WUTPAGA -- 99564", "912430": "NENGGEAGIN -- 99564", "912431": "KREPKURI -- 99565", "912432": "PASIR PUTIH -- 99565", "912501": "ILAGA -- 98972", "912502": "WANGBE -- 98971", "912503": "BEOGA -- 98971", "912504": "DOUFO -- -", "912505": "POGOMA -- 98973", "912506": "SINAK -- 98973", "912507": "AGANDUGUME -- -", "912508": "GOME -- 98972", "912601": "KAMU -- 98863", "912602": "MAPIA -- 98854", "912603": "PIYAIYE -- 98857", "912604": "KAMU UTARA -- 98863", "912605": "SUKIKAI SELATAN -- 98857", "912606": "MAPIA BARAT -- 98854", "912607": "KAMU SELATAN -- 98862", "912608": "KAMU TIMUR -- 98863", "912609": "MAPIA TENGAH -- 98854", "912610": "DOGIYAI -- 98862", "912701": "SUGAPA -- 98768", "912702": "HOMEYO -- 98767", "912703": "WANDAI -- 98784", "912704": "BIANDOGA -- 98784", "912705": "AGISIGA -- 98783", "912706": "HITADIPA -- 98768", "912707": "UGIMBA -- -", "912708": "TOMOSIGA -- -", "912801": "TIGI -- 98764", "912802": "TIGI TIMUR -- 98781", "912803": "BOWOBADO -- 98781", "912804": "TIGI BARAT -- 98764", "912805": "KAPIRAYA -- 98727", "917101": "JAYAPURA UTARA -- 99113", "917102": "JAYAPURA SELATAN -- 99223", "917103": "ABEPURA -- 99351", "917104": "MUARA TAMI -- 99351", "917105": "HERAM -- 99351", "920101": "MAKBON -- 98471", "920104": "BERAUR -- 98453", "920105": "SALAWATI -- 98452", "920106": "SEGET -- 98452", "920107": "AIMAS -- 98457", "920108": "KLAMONO -- 98456", "920110": "SAYOSA -- 98471", "920112": "SEGUN -- 98452", "920113": "MAYAMUK -- 98451", "920114": "SALAWATI SELATAN -- 98452", "920117": "KLABOT -- 98453", "920118": "KLAWAK -- 98453", "920120": "MAUDUS -- 98472", "920139": "MARIAT -- 98457", "920140": "KLAILI -- -", "920141": "KLASO -- 98472", "920142": "MOISEGEN -- 98451", "920203": "WARMARE -- 98352", "920204": "PRAFI -- 98356", "920205": "MASNI -- 98357", "920212": "MANOKWARI BARAT -- 98314", "920213": "MANOKWARI TIMUR -- 98311", "920214": "MANOKWARI UTARA -- 98315", "920215": "MANOKWARI SELATAN -- 98315", "920217": "TANAH RUBUH -- 98315", "920221": "SIDEY -- 98357", "920301": "FAK-FAK -- -", "920302": "FAK-FAK BARAT -- -", "920303": "FAK-FAK TIMUR -- -", "920304": "KOKAS -- 98652", "920305": "FAK-FAK TENGAH -- -", "920306": "KARAS -- 98662", "920307": "BOMBERAY -- 98662", "920308": "KRAMONGMONGGA -- 98652", "920309": "TELUK PATIPI -- 98661", "920310": "PARIWARI -- -", "920311": "WARTUTIN -- -", "920312": "FAKFAK TIMUR TENGAH -- -", "920313": "ARGUNI -- 98653", "920314": "MBAHAMDANDARA -- -", "920315": "KAYAUNI -- -", "920316": "FURWAGI -- -", "920317": "TOMAGE -- -", "920401": "TEMINABUAN -- 98454", "920404": "INANWATAN -- 98455", "920406": "SAWIAT -- 98456", "920409": "KOKODA -- 98455", "920410": "MOSWAREN -- 98454", "920411": "SEREMUK -- 98454", "920412": "WAYER -- 98454", "920414": "KAIS -- 98455", "920415": "KONDA -- 98454", "920420": "MATEMANI -- 98455", "920421": "KOKODA UTARA -- 98455", "920422": "SAIFI -- 98454", "920424": "FOKOUR -- 98456", "920501": "MISOOL (MISOOL UTARA) -- 98483", "920502": "WAIGEO UTARA -- 98481", "920503": "WAIGEO SELATAN -- 98482", "920504": "SALAWATI UTARA -- 98484", "920505": "KEPULAUAN AYAU -- 98481", "920506": "MISOOL TIMUR -- 98483", "920507": "WAIGEO BARAT -- 98481", "920508": "WAIGEO TIMUR -- 98482", "920509": "TELUK MAYALIBIT -- 98482", "920510": "KOFIAU -- 98483", "920511": "MEOS MANSAR -- 98482", "920513": "MISOOL SELATAN -- 98483", "920514": "WARWARBOMI -- -", "920515": "WAIGEO BARAT KEPULAUAN -- 98481", "920516": "MISOOL BARAT -- 98483", "920517": "KEPULAUAN SEMBILAN -- 98483", "920518": "KOTA WAISAI -- 98482", "920519": "TIPLOL MAYALIBIT -- 98482", "920520": "BATANTA UTARA -- 98484", "920521": "SALAWATI BARAT -- 98484", "920522": "SALAWATI TENGAH -- 98484", "920523": "SUPNIN -- 98481", "920524": "AYAU -- 98481", "920525": "BATANTA SELATAN -- 98484", "920601": "BINTUNI -- 98364", "920602": "MERDEY -- 98373", "920603": "BABO -- 98363", "920604": "ARANDAY -- 98365", "920605": "MOSKONA SELATAN -- 98365", "920606": "MOSKONA UTARA -- 98373", "920607": "WAMESA -- 98361", "920608": "FAFURWAR -- 98363", "920609": "TEMBUNI -- 98364", "920610": "KURI -- 98362", "920611": "MANIMERI -- 98364", "920612": "TUHIBA -- 98364", "920613": "DATARAN BEIMES -- 98364", "920614": "SUMURI -- 98363", "920615": "KAITARO -- 98363", "920616": "AROBA -- 98363", "920617": "MASYETA -- 98373", "920618": "BISCOOP -- 98373", "920619": "TOMU -- 98365", "920620": "KAMUNDAN -- 98365", "920621": "WERIAGAR -- 98365", "920622": "MOSKONA BARAT -- 98365", "920623": "MEYADO -- -", "920624": "MOSKONA TIMUR -- 98373", "920701": "WASIOR -- 98362", "920702": "WINDESI -- 98361", "920703": "TELUK DUAIRI -- 98362", "920704": "WONDIBOY -- 98362", "920705": "WAMESA -- 98361", "920706": "RUMBERPON -- 98361", "920707": "NAIKERE -- 98362", "920708": "RASIEI -- 98362", "920709": "KURI WAMESA -- 98362", "920710": "ROON -- 98362", "920711": "ROSWAR -- 98361", "920712": "NIKIWAR -- 98361", "920713": "SOUG JAYA -- 98361", "920801": "KAIMANA -- 98654", "920802": "BURUWAY -- 98656", "920803": "TELUK ARGUNI ATAS -- 98653", "920804": "TELUK ETNA -- 98655", "920805": "KAMBRAU -- -", "920806": "TELUK ARGUNI BAWAH -- 98653", "920807": "YAMOR -- 98655", "920901": "FEF -- 98473", "920902": "MIYAH -- 98473", "920903": "YEMBUN -- 98474", "920904": "KWOOR -- 98473", "920905": "SAUSAPOR -- 98473", "920906": "ABUN -- 98473", "920907": "SYUJAK -- 98473", "920913": "BIKAR -- -", "920914": "BAMUSBAMA -- -", "920916": "MIYAH SELATAN -- -", "920917": "IRERES -- -", "920918": "TOBOUW -- -", "920919": "WILHEM ROUMBOUTS -- -", "920920": "TINGGOUW -- -", "920921": "KWESEFO -- -", "920922": "MAWABUAN -- -", "920923": "KEBAR TIMUR -- -", "920924": "KEBAR SELATAN -- -", "920925": "MANEKAR -- -", "920926": "MPUR -- -", "920927": "AMBERBAKEN BARAT -- -", "920928": "KASI -- -", "920929": "SELEMKAI -- -", "921001": "AIFAT -- 98463", "921002": "AIFAT UTARA -- 98463", "921003": "AIFAT TIMUR -- 98463", "921004": "AIFAT SELATAN -- 98463", "921005": "AITINYO BARAT -- 98462", "921006": "AITINYO -- 98462", "921007": "AITINYO UTARA -- 98462", "921008": "AYAMARU -- 98461", "921009": "AYAMARU UTARA -- 98461", "921010": "AYAMARU TIMUR -- 98461", "921011": "MARE -- 98461", "921101": "RANSIKI -- 98355", "921102": "ORANSBARI -- 98353", "921103": "NENEY -- 98355", "921104": "DATARAN ISIM -- 98359", "921105": "MOMI WAREN -- 98355", "921106": "TAHOTA -- 98355", "921201": "ANGGI -- 98354", "921202": "ANGGI GIDA -- 98354", "921203": "MEMBEY -- 98354", "921204": "SURUREY -- 98359", "921205": "DIDOHU -- 98359", "921206": "TAIGE -- 98354", "921207": "CATUBOUW -- 98358", "921208": "TESTEGA -- 98357", "921209": "MINYAMBAOUW -- -", "921210": "HINGK -- 98357", "927101": "SORONG -- 98413", "927102": "SORONG TIMUR -- 98418", "927103": "SORONG BARAT -- 98412", "927104": "SORONG KEPULAUAN -- 98413", "927105": "SORONG UTARA -- 98416", "927106": "SORONG MANOI -- 98414", "927107": "SORONG KOTA -- -", "927108": "KLAURUNG -- -", "927109": "MALAIMSIMSA -- -", "927110": "MALADUM MES -- -" } };

    // Output NIK tidak valid
    let res = {
        status: "error",
        pesan: "NIK tidak valid"
    };

    // validasi NIK
    if (16 == (nik = nik.toString()).length && null != U.provinsi[nik.substring(0, 2)] && U.kabkot[nik.substring(0, 4)] && U.kecamatan[nik.substring(0, 6)]) {
        const N = (new Date).getFullYear().toString().substr(-2), // tahun sekarang
            E = nik.substring(10, 12), // tahun NIK
            O = nik.substring(6, 8), // tanggal NIK
            K = U.kecamatan[nik.substring(0, 6)].toUpperCase().split(" -- "); // kecamatan & kodepos

        // Kecamatan
        const L = K[0];

        // Kode POS
        const B = K[1];

        // Jenis kelamin
        let M = "LAKI-LAKI";
        O > 40 && (M = "PEREMPUAN");

        // tanggal lahir
        let S = O;
        O > 40 && (S = (O - 40).toString().length > 1 ? (O - 40).toString() : `0${(O - 40).toString()}`);

        // bulan lahir
        const P = nik.substring(8, 10);

        // tahun lahir
        let D = `19${E}`;
        E < N && (D = `20${E}`);

        // Menerjemahkan tanggal lahir ke pasaran, usia, zodiak & ulang tahun
        const H = function (A) {
            const N = new Date,
                U = N.getFullYear(),
                I = N.getMonth(),
                E = A.split("-"),
                O = I < E[1] ? U : U + 1;

            // Ulang tahun counter
            const K = function (A) {
                const N = new Date,
                    U = function (A) {
                        const N = A.split(/\D/),
                            U = new Date(N[2], --N[1], N[0]);
                        //return U && U.getMonth() == N[1] ? U : new Date(NaN)
                        return U && U.getMonth() == N[1] || U.getMonth() == ++N[1] ? U : new Date(NaN)
                    }(A) - N,
                    I = Math.floor(U / 2592e6),
                    G = Math.floor(U % 2592e6 / 864e5);
                return `${I} Bulan ${G} Hari`
            }(`${parseInt(E[0]) + 1}/${E[1]}/${O}`);

            const L = T(E[0]), // int tanggal lahir
                B = T(E[1]), // int bulan lahir
                M = E[2]; // int tahun lahir

            // Pasaran
            const S = new Date(70, 0, 2),
                P = new Date(M, B - 1, L),
                V = (P.getTime() - S.getTime() + 864e5) / 432e6,
                D = Math.round(10 * (V - Math.floor(V))) / 2,
                H = ["Wage", "Kliwon", "Legi", "Pahing", "Pon"][D],
                Z = `${["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"][R("w", G(0, 0, 0, B, L, M))]} ${H}, ${L} ${["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember"][B - 1]} ${M}`;

            // Usia				
            utahun = R("Y") - M, ubulan = R("m") - B, uhari = R("j") - L, uhari < 0 && (uhari = R("t", G(0, 0, 0, B - 1, R("m"), R("Y"))) - Math.abs(uhari), ubulan -= 1);
            ubulan < 0 && (ubulan = 12 - Math.abs(ubulan), utahun -= 1);
            const X = `${utahun} Tahun ${ubulan} Bulan ${uhari} Hari`;

            // Zodiak
            let W = "";
            (1 == B && L >= 20 || 2 == B && L < 19) && (W = "Aquarius");
            (2 == B && L >= 19 || 3 == B && L < 21) && (W = "Pisces");
            (3 == B && L >= 21 || 4 == B && L < 20) && (W = "Aries");
            (4 == B && L >= 20 || 5 == B && L < 21) && (W = "Taurus");
            (5 == B && L >= 21 || 6 == B && L < 22) && (W = "Gemini");
            (6 == B && L >= 21 || 7 == B && L < 23) && (W = "Cancer");
            (7 == B && L >= 23 || 8 == B && L < 23) && (W = "Leo");
            (8 == B && L >= 23 || 9 == B && L < 23) && (W = "Virgo");
            (9 == B && L >= 23 || 10 == B && L < 24) && (W = "Libra");
            (10 == B && L >= 24 || 11 == B && L < 23) && (W = "Scorpio");
            (11 == B && L >= 23 || 12 == B && L < 22) && (W = "Sagitarius");
            (12 == B && L >= 22 || 1 == B && L < 20) && (W = "Capricorn");

            return {
                pasaran: Z,
                usia: X,
                ultah: K,
                zodiak: W
            }
        }(`${S}-${P}-${D}`);

        // Output NIK valid
        res = {
            status: "success",
            pesan: "NIK valid",
            data: {
                nik: nik,
                kelamin: M,
                lahir: `${S}/${P}/${D}`,
                provinsi: U.provinsi[nik.substring(0, 2)],
                kotakab: U.kabkot[nik.substring(0, 4)],
                kecamatan: L,
                uniqcode: nik.substring(12, 16),
                tambahan: {
                    kodepos: B,
                    pasaran: H.pasaran,
                    usia: H.usia,
                    ultah: `${H.ultah} Lagi`,
                    zodiak: H.zodiak
                }
            }
        }
    }

    return res;

}

// get Time
function G(...e) { const t = new Date, n = e; let r = 0; const s = ["Hours", "Minutes", "Seconds", "Month", "Date", "FullYear"]; for (r = 0; r < s.length; r++)if (void 0 === n[r]) n[r] = t[`get${s[r]}`](), n[r] += 3 === r; else if (n[r] = parseInt(n[r], 10), isNaN(n[r])) return !1; return n[5] += n[5] >= 0 ? n[5] <= 69 ? 2e3 : n[5] <= 100 ? 1900 : 0 : 0, t.setFullYear(n[5], n[3] - 1, n[4]), t.setHours(n[0], n[1], n[2]), (t.getTime() / 1e3 >> 0) - (t.getTime() < 0) }

// get Date
function R(e, t) { let n, r, s = this; const o = ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Satur", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], a = /\\?(.?)/gi, u = (e, t) => r[e] ? r[e]() : t, i = (e, t) => { for (e = String(e); e.length < t;)e = `0${e}`; return e }; return r = { d: () => i(r.j(), 2), D: () => r.l().slice(0, 3), j: () => n.getDate(), l: () => `${o[r.w()]}day`, N: () => r.w() || 7, S() { const e = r.j(); let t = e % 10; return t <= 3 && 1 == parseInt(e % 100 / 10, 10) && (t = 0), ["st", "nd", "rd"][t - 1] || "th" }, w: () => n.getDay(), z() { const e = new Date(r.Y(), r.n() - 1, r.j()), t = new Date(r.Y(), 0, 1); return Math.round((e - t) / 864e5) }, W() { const e = new Date(r.Y(), r.n() - 1, r.j() - r.N() + 3), t = new Date(e.getFullYear(), 0, 4); return i(1 + Math.round((e - t) / 864e5 / 7), 2) }, F: () => o[6 + r.n()], m: () => i(r.n(), 2), M: () => r.F().slice(0, 3), n: () => n.getMonth() + 1, t: () => new Date(r.Y(), r.n(), 0).getDate(), L() { const e = r.Y(); return e % 4 == 0 & e % 100 != 0 | e % 400 == 0 }, o() { const e = r.n(), t = r.W(); return r.Y() + (12 === e && t < 9 ? 1 : 1 === e && t > 9 ? -1 : 0) }, Y: () => n.getFullYear(), y: () => r.Y().toString().slice(-2), a: () => n.getHours() > 11 ? "pm" : "am", A: () => r.a().toUpperCase(), B() { const e = 3600 * n.getUTCHours(), t = 60 * n.getUTCMinutes(), r = n.getUTCSeconds(); return i(Math.floor((e + t + r + 3600) / 86.4) % 1e3, 3) }, g: () => r.G() % 12 || 12, G: () => n.getHours(), h: () => i(r.g(), 2), H: () => i(r.G(), 2), i: () => i(n.getMinutes(), 2), s: () => i(n.getSeconds(), 2), u: () => i(1e3 * n.getMilliseconds(), 6), e() { throw "Not supported (see source code of date() for timezone on how to add support)" }, I: () => new Date(r.Y(), 0) - Date.UTC(r.Y(), 0) != new Date(r.Y(), 6) - Date.UTC(r.Y(), 6) ? 1 : 0, O() { const e = n.getTimezoneOffset(), t = Math.abs(e); return (e > 0 ? "-" : "+") + i(100 * Math.floor(t / 60) + t % 60, 4) }, P() { const e = r.O(); return `${e.substr(0, 3)}:${e.substr(3, 2)}` }, T: () => "UTC", Z: () => 60 * -n.getTimezoneOffset(), c: () => "Y-m-d\\TH:i:sP".replace(a, u), r: () => "D, d M Y H:i:s O".replace(a, u), U: () => n / 1e3 | 0 }, this.date = function (e, t) { return s = this, n = void 0 === t ? new Date : t instanceof Date ? new Date(t) : new Date(1e3 * t), e.replace(a, u) }, this.date(e, t) }

// String to Integer
function T(e, t) { let n; const r = typeof e; return "boolean" === r ? +e : "string" === r ? (n = parseInt(e, t || 10), isNaN(n) || !isFinite(n) ? 0 : n) : "number" === r && isFinite(e) ? 0 | e : 0 }

async function Likee(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.request("https://likeedownloader.com/process", {
                method: "POST",
                data: new URLSearchParams(Object.entries({ id: url })),
                headers: {
                    "cookie": "_ga=GA1.2.553951407.1656223884; _gid=GA1.2.1157362698.1656223884; __gads=ID=0fc4d44a6b01b1bc-22880a0efed2008c:T=1656223884:RT=1656223884:S=ALNI_MYp2ZXD2vQmWnXc2WprkU_p6ynfug; __gpi=UID=0000069517bf965e:T=1656223884:RT=1656223884:S=ALNI_Map47wQbMbbf7TaZLm3TvZ1eI3hZw; PHPSESSID=e3oenugljjabut9egf1gsji7re; _gat_UA-3524196-10=1",
                    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
                },
            });
            const $ = cheerio.load(data.template)
            const result = {
                status: 200,
                title: $('div.quote-box p.infotext').text().trim(),
                thumbnail: $('div.quote-box div.img_thumb img').attr('src'),
                watermark: $('.result-links-item:first-child a.with_watermark').attr('href'),
                no_watermark: $('.result-links-item:last-child a.without_watermark').attr('href')
            };
            console.log(result)
            resolve(result)
        } catch (error) {
            reject(error)
        }
    });
}

async function cocofun(url) {
  return new Promise((resolve, reject) => {
    axios({url, method: "get",
      headers: {
        "Cookie": "client_id=1a5afdcd-5574-4cfd-b43b-b30ad14c230e",
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
      }
    }).then(data => {
      $ = cheerio.load(data.data)
      let json
      const res = $('script#appState').get()
      for(let i of res){
        if(i.children && i.children[0] && i.children[0].data){
          ress = i.children[0].data.split('window.APP_INITIAL_STATE=')[1]
          json = JSON.parse(ress)
        }
        const result = {
          status: 200,
          author: author,
          topic: json.share.post.post.content ? json.share.post.post.content : json.share.post.post.topic.topic,
          caption: $("meta[property='og:description']").attr('content'),
          play: json.share.post.post.playCount,
          like: json.share.post.post.likes,
          share: json.share.post.post.share,
          duration: json.share.post.post.videos[json.share.post.post.imgs[0].id].dur,
          thumbnail: json.share.post.post.videos[json.share.post.post.imgs[0].id].coverUrls[0],
          watermark: json.share.post.post.videos[json.share.post.post.imgs[0].id].urlwm,
          no_watermark: json.share.post.post.videos[json.share.post.post.imgs[0].id].url
        }
        resolve(result)
      }
    }).catch(reject)
  })
}

module.exports = {
    joox,
    jooxdl,
    rexdl,
    nomorhoki,
    blackbox,
    tiktokslide,
    capcut,
    photo2anime,
    tiktoks,
    aivvm,
    cai,
    aiodl,
    bard,
    gptpic,
    aigpt,
    WattPad,
    kodepos,
    anichinSearch,
    anichinEps,
    mediafire,
    soundcloud,
    tiktok,
    twitter,
    facebook,
    igdl,
    sfilemobi,
    ytmp3,
	ytmp4,
	play,
	playaudio,
	playvideo,
    search,
    terabox,
    screenshotWebsite,
    styleText,
    base64Encode,
    base64Decode,
    base32Encode,
    base32Decode,
    ttStory,
    tiktokv2,
    soviets,
    rekening,
    ChatGpt,
    ChatGpt2,
    fbdl,
    igdl2,
    wiki,
    tiktok2,
    herodetail,
    herolist,
    shopee,
    otakudesu,
    film,
    playstore,
    lirik,
    tebakgambar,
    komiku,
    linkwa,
    WattPad2,
    CekNik,
    Likee,
    cocofun
};